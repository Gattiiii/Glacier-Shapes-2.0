# -*- coding: utf-8 -*-
"""
MAPA DE FASES (estilo Super Mario World) - visao de cima (top-down)
Tudo e desenhado por codigo: tiles de 16x16 px e pinguim de 16x16 px.
O mapa tem 20x10 tiles = 320x160 px logicos (a tela do jogo amplia 4x, sem suavizar).

Este arquivo NAO depende do pygame para criar a arte (so usa pygame em OverWorld.draw).
"""
import math

TS = 16                       # tamanho do tile / personagem (px)
MAP_COLS, MAP_ROWS = 20, 10
MAP_W, MAP_H = MAP_COLS * TS, MAP_ROWS * TS      # 320 x 160

# ---------------------------------------------------------------- paleta
OUT = (16, 28, 64)
SNOW_L = (244, 250, 255)
SNOW = (222, 238, 252)
SNOW_D = (184, 212, 240)
SNOW_DD = (140, 178, 224)
WATER = (34, 96, 196)
WATER_M = (52, 120, 214)
WATER_L = (104, 172, 240)
FOAM = (226, 244, 255)
ICE = (172, 228, 248)
ICE_L = (226, 248, 255)
ICE_D = (110, 186, 232)
ROCK = (72, 86, 146)
ROCK_D = (44, 54, 104)
ROCK_L = (118, 134, 188)
CLIFF = (74, 88, 150)
CLIFF_D = (46, 58, 112)
CLIFF_L = (110, 126, 182)
PATH = (238, 216, 170)
PATH_L = (250, 236, 200)
PATH_D = (198, 168, 120)
TREE = (44, 100, 124)
TREE_D = (26, 62, 92)
TRUNK = (112, 72, 52)
BODY = (44, 56, 118)
BODY_L = (78, 98, 170)
BODY_D = (26, 34, 84)
WHITE = (248, 252, 255)
ORANGE = (244, 156, 44)
RED = (214, 52, 72)
RED_D = (150, 32, 52)


# ---------------------------------------------------------------- mini "canvas" de pixels
class Px(object):
    """Imagem de pixels (RGB ou None = transparente)."""

    def __init__(self, w, h, fill=None):
        self.w, self.h = w, h
        self.p = [fill] * (w * h)

    def get(self, x, y):
        if 0 <= x < self.w and 0 <= y < self.h:
            return self.p[y * self.w + x]
        return None

    def set(self, x, y, c):
        if 0 <= x < self.w and 0 <= y < self.h:
            self.p[y * self.w + x] = c

    def blit(self, o, ox, oy):
        for y in range(o.h):
            for x in range(o.w):
                c = o.p[y * o.w + x]
                if c is not None:
                    self.set(ox + x, oy + y, c)

    def copy(self):
        n = Px(self.w, self.h)
        n.p = list(self.p)
        return n

    def flip_h(self):
        n = Px(self.w, self.h)
        for y in range(self.h):
            for x in range(self.w):
                n.p[y * self.w + (self.w - 1 - x)] = self.p[y * self.w + x]
        return n

    def shifted(self, dx, dy):
        n = Px(self.w, self.h)
        for y in range(self.h):
            for x in range(self.w):
                c = self.p[y * self.w + x]
                if c is not None:
                    n.set(x + dx, y + dy, c)
        return n

    def rgb_bytes(self, bg=(0, 0, 0)):
        out = bytearray()
        for c in self.p:
            out.extend(c if c is not None else bg)
        return bytes(out)

    def rgba_bytes(self):
        out = bytearray()
        for c in self.p:
            if c is None:
                out.extend((0, 0, 0, 0))
            else:
                out.extend((c[0], c[1], c[2], 255))
        return bytes(out)


def outline(px, color=OUT):
    """Contorno de 1 px em volta de tudo que e opaco (estilo pixel art classico)."""
    n = px.copy()
    for y in range(px.h):
        for x in range(px.w):
            if px.get(x, y) is None:
                for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    if px.get(x + dx, y + dy) is not None:
                        n.set(x, y, color)
                        break
    return n


def from_rows(rows, pal):
    h = len(rows)
    w = len(rows[0])
    px = Px(w, h)
    for y, r in enumerate(rows):
        assert len(r) == w, "linha %d com %d colunas (esperado %d): %r" % (y, len(r), w, r)
        for x, ch in enumerate(r):
            if ch != ".":
                px.set(x, y, pal[ch])
    return px


def dim(px, k=0.55):
    """Versao 'bloqueada' (cinza azulado) de um sprite."""
    n = Px(px.w, px.h)
    for i, c in enumerate(px.p):
        if c is None:
            continue
        g = (c[0] * 0.3 + c[1] * 0.5 + c[2] * 0.2)
        n.p[i] = (int(g * k + 60 * (1 - k)), int(g * k + 70 * (1 - k)), int(g * k + 100 * (1 - k)))
    return n


# ---------------------------------------------------------------- pinguim 16x16 (4 direcoes x passos)
_PAL = {"n": BODY, "N": BODY_L, "d": BODY_D, "w": WHITE, "o": ORANGE, "r": RED, "R": RED_D,
        "e": OUT}

_FRONT = [
    "................",
    "......nnnn......",
    "....nnnnnnnn....",
    "...nnnnnnnnnn...",
    "..nnnwennewnnn..",
    "..nnnnnoonnnnn..",
    "..nnnnnnnnnnnn..",
    ".rrrrrrrrrrrrrr.",
    ".RRRRRRRRRRRRRR.",
    ".nnnwwwwwwrrnnn.",
    ".nnnwwwwwwrrnnn.",
    ".nnnwwwwwwRRnnn.",
    "..nnwwwwwwwwnn..",
    "...nnwwwwwwnn...",
    "................",
    "................",
]

_BACK = [
    "................",
    "......nnnn......",
    "....nnnnnnnn....",
    "...nnnnnnnnnn...",
    "..nnnnnnnnnnnn..",
    "..nnnnnnnnnnnn..",
    "..nnnnnnnnnnnn..",
    ".rrrrrrrrrrrrrr.",
    ".RRRRRRRRRRRRRR.",
    ".nnnnnnnnnnnnnn.",
    ".ndnnnnnnnnnndn.",
    ".ndnnnnnnnnnndn.",
    "..nnnnnnnnnnnn..",
    "...nnnnnnnnnn...",
    "................",
    "................",
]

_SIDE = [
    "................",
    ".....nnnn.......",
    "....nnnnnn......",
    "...nnnnnnnn.....",
    "...nnnnnnwenn...",
    "...nnnnnnnnnnoo.",
    "...nnnnnnnnnn...",
    "..rrrrrrrrrrr...",
    "rrRRRRRRRRRR....",
    ".rrnnnnnwwwwnn..",
    "..nndddnwwwwnn..",
    "..nndddnwwwwnn..",
    "..nnnddnwwwwnn..",
    "...nnnnnwwwnn...",
    "................",
    "................",
]


def _feet(px, lx, rx, y=14, side=False):
    for dx in (0, 1, 2):
        px.set(lx + dx, y, ORANGE)
        px.set(rx + dx, y, ORANGE)


def make_penguin(direction, step):
    """direction: 'down' | 'up' | 'right' | 'left'; step 0 = parado, 1..4 = ciclo de caminhada."""
    rows = {"down": _FRONT, "up": _BACK, "right": _SIDE, "left": _SIDE}[direction]
    base = from_rows(rows, _PAL)
    # brilho na cabeca
    if direction in ("down", "up"):
        for (x, y) in ((5, 2), (4, 3), (5, 3)):
            base.set(x, y, BODY_L)
    else:
        for (x, y) in ((5, 2), (4, 3), (5, 3)):
            base.set(x, y, BODY_L)
    bob = 0
    lx, rx = 4, 9
    if direction in ("right", "left"):
        lx, rx = 4, 8
    if step in (1, 3):
        bob = -1
    if step == 1:
        lx, rx = lx - 1, rx + 1
    elif step == 3:
        lx, rx = lx + 1, rx - 1
    px = Px(16, 16)
    px.blit(base.shifted(0, bob), 0, 0)
    _feet(px, lx, rx)
    px = outline(px)
    if direction == "left":
        px = px.flip_h()
    return px


# ---------------------------------------------------------------- tiles e decoracoes
def _hash(x, y, s=0):
    h = (x * 73856093) ^ (y * 19349663) ^ (s * 83492791)
    h = (h ^ (h >> 13)) * 1274126177
    return (h ^ (h >> 16)) & 0xFFFF


def make_pine():
    px = Px(16, 16)
    hw = {1: 1, 2: 2, 3: 3, 4: 2, 5: 3, 6: 4, 7: 5, 8: 3, 9: 4, 10: 5, 11: 6}
    tops = (1, 2, 4, 5, 8, 9)
    for y, w in hw.items():
        for x in range(8 - w, 8 + w):
            left = x < 8
            if y in tops:
                c = SNOW_L if left else SNOW_D
            else:
                c = TREE if left else TREE_D
            px.set(x, y, c)
    for y in (12, 13):
        for x in (7, 8):
            px.set(x, y, TRUNK)
    return outline(px)


def make_mountain():
    px = Px(16, 16)
    # silhueta triangular
    for y in range(2, 14):
        half = 1 + (y - 2) * 6 // 11 + (1 if y > 6 else 0)
        half = min(half, 7)
        for x in range(8 - half, 8 + half):
            left = x < 8
            snow = y <= 5 + (1 if x % 3 == 0 else 0)
            if snow:
                c = SNOW_L if left else SNOW_D
            else:
                c = ROCK_L if left else ROCK
                if y >= 12:
                    c = ROCK if left else ROCK_D
            px.set(x, y, c)
    return outline(px)


def make_dot(color, rim, digit=None, digit_color=(110, 60, 20), lift=0):
    px = Px(16, 16)
    cx, cy, r = 7.5, 8.0, 5.6
    for y in range(16):
        for x in range(16):
            d = math.hypot(x - cx, y - cy)
            if d <= r:
                c = color if y < 9 else rim
                if d > r - 1.0 and y >= 9:
                    c = rim
                px.set(x, y, c)
    if digit is not None:
        font = {
            "1": ("010", "110", "010", "010", "111"),
            "2": ("111", "001", "111", "100", "111"),
            "3": ("111", "001", "111", "001", "111"),
            "4": ("101", "101", "111", "001", "001"),
        }[str(digit)]
        for dy, row in enumerate(font):
            for dx, ch in enumerate(row):
                if ch == "1":
                    px.set(6 + dx, 5 + dy, digit_color)
    return outline(px)


def make_flag_dot():
    """Fase concluida: bolinha azul-gelo com uma bandeirinha vermelha."""
    px = Px(16, 16)
    cx, cy, r = 7.5, 11.0, 4.4
    for y in range(16):
        for x in range(16):
            if math.hypot(x - cx, y - cy) <= r:
                px.set(x, y, (120, 208, 255) if y < 12 else (70, 160, 230))
    for y in range(2, 11):
        px.set(8, y, (230, 236, 250))
    for y, w in ((2, 4), (3, 3), (4, 2), (5, 1)):
        for x in range(9, 9 + w):
            px.set(x, y, RED)
    return outline(px)


def make_igloo(locked=False, done=False):
    """No do chefe final: iglu de 16x16."""
    px = Px(16, 16)
    cx, cy, r = 7.5, 13.5, 7.2
    for y in range(4, 15):
        for x in range(16):
            d = math.hypot(x - cx, (y - cy) * 1.1)
            if d <= r:
                c = ICE_L if (y // 3 + (x // 4 if (y // 3) % 2 == 0 else (x + 2) // 4)) % 2 == 0 else SNOW
                if (y % 3) == 2:
                    c = SNOW_D
                px.set(x, y, c)
    for y in range(9, 15):          # porta
        w = 2 if y > 9 else 1
        for x in range(8 - w, 8 + w):
            px.set(x, y, OUT)
    if done:
        for y in range(0, 5):
            px.set(8, y, (230, 236, 250))
        for y, w in ((0, 4), (1, 3), (2, 2)):
            for x in range(9, 9 + w):
                px.set(x, y, RED)
    px = outline(px)
    return dim(px, 0.7) if locked else px


def make_tile(kind, x, y):
    """Tile 16x16 de base ('s' neve, 'w' agua, 'i' gelo) - sem efeitos de borda."""
    px = Px(16, 16)
    for j in range(16):
        for i in range(16):
            gx, gy = x * 16 + i, y * 16 + j
            if kind == "s":
                c = SNOW
                h = _hash(gx, gy)
                if h % 23 == 0:
                    c = SNOW_L
                elif h % 29 == 0:
                    c = SNOW_D
            elif kind == "i":
                c = ICE
                if (gx + gy) % 9 in (0, 1) and (gx // 3 + gy // 5) % 2 == 0:
                    c = ICE_L
                elif _hash(gx, gy, 5) % 31 == 0:
                    c = ICE_D
            else:
                c = WATER
            px.set(i, j, c)
    return px


# ---------------------------------------------------------------- layout do mapa
def _build_layout():
    g = [["s"] * MAP_COLS for _ in range(MAP_ROWS)]
    for c in range(MAP_COLS):
        g[0][c] = "w"
        g[MAP_ROWS - 1][c] = "w"
    for r in range(MAP_ROWS):
        g[r][0] = "w"
        g[r][MAP_COLS - 1] = "w"
    # cantos arredondados da ilha
    for (c, r) in ((1, 1), (18, 1), (1, 8), (18, 8)):
        g[r][c] = "w"
    # lago
    lake = {5: range(9, 14), 6: range(9, 15), 7: range(9, 15), 8: range(10, 14)}
    for r, cols in lake.items():
        for c in cols:
            g[r][c] = "w"
    # blocos de gelo flutuando no lago e uma plataforma de gelo na margem
    for (c, r) in ((11, 6), (12, 7), (14, 5), (15, 5), (15, 6)):
        g[r][c] = "i"
    for (c, r) in ((3, 7), (4, 7), (4, 6)):
        g[r][c] = "i"
    return g


LAYOUT = _build_layout()

# nos (fases): (coluna, linha) em tiles
NODES = [
    {"tile": (2, 8), "nome": "GELEIRA INICIAL", "boss": False},
    {"tile": (7, 6), "nome": "LAGO CONGELADO", "boss": False},
    {"tile": (12, 3), "nome": "PICOS GELADOS", "boss": False},
    {"tile": (17, 6), "nome": "TOCA DO CRIO-GOLEM", "boss": True},
]

# caminhos entre nos (lista de tiles, do no i ao no i+1, inclusive pontas)
EDGES = [
    [(2, 8), (3, 8), (4, 8), (5, 8), (6, 8), (7, 8), (7, 7), (7, 6)],
    [(7, 6), (7, 5), (7, 4), (7, 3), (8, 3), (9, 3), (10, 3), (11, 3), (12, 3)],
    [(12, 3), (13, 3), (14, 3), (15, 3), (16, 3), (17, 3), (17, 4), (17, 5), (17, 6)],
]

TREES = [(1, 2), (3, 1), (4, 1), (2, 3), (3, 4), (10, 1), (14, 1), (15, 1), (18, 2), (9, 2),
         (15, 2), (4, 3), (13, 2), (16, 1), (6, 1), (8, 7), (8, 8), (15, 8), (16, 8),
         (18, 4), (18, 5), (16, 5), (5, 7), (1, 6), (1, 7), (14, 4), (9, 4), (6, 3)]
MOUNTAINS = [(5, 2), (11, 2), (2, 5), (5, 4), (13, 4), (17, 1), (8, 1), (16, 7), (14, 8)]


def _path_cells():
    s = set()
    for e in EDGES:
        for t in e:
            s.add(t)
    return s


PATH_CELLS = _path_cells()


# ---------------------------------------------------------------- render do cenario fixo
def _dist(mask, w, h, cap=6):
    """Distancia (Manhattan) ate o pixel mais proximo onde mask[y][x] e True."""
    INF = cap + 1
    d = [[0 if mask[y][x] else INF for x in range(w)] for y in range(h)]
    for y in range(h):
        for x in range(w):
            v = d[y][x]
            if x > 0 and d[y][x - 1] + 1 < v:
                v = d[y][x - 1] + 1
            if y > 0 and d[y - 1][x] + 1 < v:
                v = d[y - 1][x] + 1
            d[y][x] = v
    for y in range(h - 1, -1, -1):
        for x in range(w - 1, -1, -1):
            v = d[y][x]
            if x < w - 1 and d[y][x + 1] + 1 < v:
                v = d[y][x + 1] + 1
            if y < h - 1 and d[y + 1][x] + 1 < v:
                v = d[y + 1][x] + 1
            d[y][x] = v
    return d


def build_scenery():
    """Devolve 2 imagens (2 quadros de agua) do mapa 320x160 sem nos nem pinguim."""
    W, H = MAP_W, MAP_H
    base = Px(W, H)
    kind = [[None] * W for _ in range(H)]
    for r in range(MAP_ROWS):
        for c in range(MAP_COLS):
            k = LAYOUT[r][c]
            t = make_tile(k, c, r)
            base.blit(t, c * TS, r * TS)
            for j in range(TS):
                for i in range(TS):
                    kind[r * TS + j][c * TS + i] = k

    # falesia: agua logo abaixo de terra vira parede de rocha (4 px)
    cliff = [[False] * W for _ in range(H)]
    for x in range(W):
        for y in range(H - 1):
            if kind[y][x] in ("s", "i") and kind[y + 1][x] == "w":
                for k in range(1, 6):
                    yy = y + k
                    if yy >= H or kind[yy][x] != "w":
                        break
                    cliff[yy][x] = True
                    if k == 1:
                        c = CLIFF_L
                    elif k == 5:
                        c = CLIFF_D
                    else:
                        c = CLIFF if (x // 2 + k) % 4 else CLIFF_D
                    base.set(x, yy, c)
    water = [[kind[y][x] == "w" and not cliff[y][x] for x in range(W)] for y in range(H)]
    land = [[not water[y][x] for x in range(W)] for y in range(H)]
    d_water = _dist(water, W, H, 4)
    d_land = _dist(land, W, H, 4)

    for y in range(H):
        for x in range(W):
            k = kind[y][x]
            if k == "s" and not cliff[y][x]:
                d = d_water[y][x]
                if d == 1:
                    base.set(x, y, SNOW_DD)
                elif d == 2:
                    base.set(x, y, SNOW_D)
            elif k == "i" and not cliff[y][x]:
                d = d_water[y][x]
                if d == 1:
                    base.set(x, y, ICE_D)
                elif d == 2 and (x + y) % 2 == 0:
                    base.set(x, y, ICE)

    # trilhas (areia), com borda mais escura
    pmask = [[(x // TS, y // TS) in PATH_CELLS for x in range(W)] for y in range(H)]
    for y in range(H):
        for x in range(W):
            if pmask[y][x]:
                c = PATH
                edge = False
                for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    xx, yy = x + dx, y + dy
                    if 0 <= xx < W and 0 <= yy < H and not pmask[yy][xx]:
                        edge = True
                if edge:
                    c = PATH_D
                elif _hash(x, y, 9) % 17 == 0:
                    c = PATH_L
                base.set(x, y, c)

    # decoracoes (de cima para baixo, para as de baixo cobrirem as de cima)
    deco = []
    for (c, r) in MOUNTAINS:
        deco.append((r, c, "m"))
    for (c, r) in TREES:
        deco.append((r, c, "t"))
    pine, mount = make_pine(), make_mountain()
    for (r, c, k) in sorted(deco):
        if (c, r) in PATH_CELLS or LAYOUT[r][c] != "s":
            continue
        base.blit(pine if k == "t" else mount, c * TS, r * TS)

    # dois quadros de agua (ondinhas) + espuma na borda
    frames = []
    for f in range(2):
        img = base.copy()
        sh = f * 4
        for y in range(H):
            for x in range(W):
                if not water[y][x]:
                    continue
                dl = d_land[y][x]
                c = WATER
                wy = y % 8
                if wy in (2, 6) and ((x + sh + (4 if wy == 6 else 0)) % 8) < 3:
                    c = WATER_L
                if dl == 1:
                    c = FOAM if ((x + y + f * 2) % 5) != 0 else WATER_L
                elif dl == 2:
                    c = WATER_M if c == WATER else c
                img.set(x, y, c)
        frames.append(img)
    return frames


# ================================================================ MUNDO 2: GELEIRAS DERRETENDO + RADIOATIVO
OUT2 = (22, 30, 26)
TOX = (52, 206, 52)
TOX_M = (92, 230, 58)
TOX_L = (176, 255, 84)
TOX_D = (30, 140, 44)
FOAM2 = (226, 255, 150)
GR = (122, 110, 96)
GR_L = (148, 136, 116)
GR_D = (98, 88, 80)
GR_DD = (72, 64, 62)
CLF2 = (96, 70, 72)
CLF2_D = (58, 40, 52)
CLF2_L = (134, 100, 98)
PATH2 = (214, 196, 132)
PATH2_L = (236, 220, 160)
PATH2_D = (160, 134, 92)
MELT = (122, 216, 160)          # poca de degelo contaminada sobre o gelo
R2L, R2, R2D = (126, 106, 102), (96, 78, 80), (62, 50, 58)
CONC, CONC_D, CONC_L = (190, 196, 210), (138, 146, 170), (226, 230, 240)
YEL, YEL_D, YEL_L = (244, 204, 44), (190, 140, 22), (255, 236, 110)


def make_tile2(kind, x, y):
    px = Px(16, 16)
    for j in range(16):
        for i in range(16):
            gx, gy = x * 16 + i, y * 16 + j
            if kind == "s":
                c = GR
                h = _hash(gx, gy, 2)
                if h % 23 == 0:
                    c = GR_L
                elif h % 29 == 0:
                    c = GR_D
                elif h % 61 == 0:
                    c = SNOW_D            # restinho de neve suja
            elif kind == "i":
                c = ICE
                if (gx + gy) % 9 in (0, 1) and (gx // 3 + gy // 5) % 2 == 0:
                    c = ICE_L
                elif _hash(gx, gy, 5) % 31 == 0:
                    c = ICE_D
                # pocas de degelo (agua verde-clara) em cima do gelo
                if _hash(gx // 5, gy // 4, 3) % 4 == 0 and _hash(gx, gy, 8) % 5 != 0:
                    c = MELT
            else:
                c = TOX
            px.set(i, j, c)
    return px


def make_dead_tree():
    px = Px(16, 16)
    tr, trd = (104, 74, 58), (70, 50, 42)
    for y in range(6, 14):
        px.set(7, y, tr)
        px.set(8, y, trd)
    for (x, y) in ((6, 7), (5, 6), (4, 5), (3, 4), (6, 10), (5, 9), (4, 9),
                   (9, 6), (10, 5), (11, 4), (12, 3), (9, 9), (10, 8), (11, 8), (7, 5), (8, 4), (8, 3)):
        px.set(x, y, tr if x < 8 else trd)
    for (x, y) in ((3, 3), (4, 4), (12, 2), (11, 3), (3, 5)):
        px.set(x, y, (156, 172, 52))
    for (x, y) in ((4, 8), (11, 7), (8, 2)):
        px.set(x, y, (112, 132, 42))
    px.set(6, 13, tr)
    px.set(9, 13, trd)
    return outline(px, OUT2)


def make_melt_mountain():
    """Montanha de neve derretendo: pingos escorrendo e poca verde na base."""
    px = Px(16, 16)
    for y in range(2, 14):
        half = min(7, 1 + (y - 2) * 6 // 11 + (1 if y > 6 else 0))
        for x in range(8 - half, 8 + half):
            left = x < 8
            snow = y <= 4 + (1 if x % 3 == 0 else 0)
            if snow:
                c = SNOW_L if left else ICE_D
            else:
                c = R2L if left else R2
                if y >= 12:
                    c = R2 if left else R2D
            px.set(x, y, c)
    for x in (5, 8, 10):                       # pingos de degelo
        for k in range(3):
            if px.get(x, 5 + k) is not None:
                px.set(x, 5 + k, ICE_L if k < 2 else MELT)
    for x in range(2, 14):                     # poca toxica na base
        px.set(x, 13, TOX_M)
        if 4 <= x <= 11:
            px.set(x, 14, TOX)
    px.set(5, 13, TOX_L)
    px.set(9, 13, TOX_L)
    return outline(px, OUT2)


def make_barrel():
    """Barril radioativo vazando (simbolo de radiacao em preto no amarelo)."""
    px = Px(16, 16)
    for y in range(4, 14):
        for x in range(3, 13):
            if (x in (3, 12)) and y in (4, 13):
                continue                       # cantos arredondados
            c = YEL
            if x <= 4:
                c = YEL_L
            elif x >= 11:
                c = YEL_D
            if y in (4, 13):
                c = YEL_D
            px.set(x, y, c)
    cx, cy = 7.5, 8.6
    for y in range(5, 13):
        for x in range(4, 12):
            dx, dy = x - cx, y - cy
            r = math.hypot(dx, dy)
            if r <= 1.1:
                px.set(x, y, (30, 30, 30))
            elif 1.7 <= r <= 3.9:
                ang = math.degrees(math.atan2(dy, dx)) % 360
                for a0 in (90, 210, 330):
                    d = abs((ang - a0 + 180) % 360 - 180)
                    if d <= 30:
                        px.set(x, y, (30, 30, 30))
    for y in range(8, 14):                     # gosma verde escorrendo
        px.set(12, y, TOX_L)
    for x in range(5, 15):
        px.set(x, 14, TOX_M if x % 3 else TOX_L)
    return outline(px, OUT2)


def make_reactor(locked=False, done=False):
    """No do chefe do mundo 2: torre de resfriamento do reator, soltando vapor verde."""
    px = Px(16, 16)
    for y in range(2, 15):
        half = 3 + abs(y - 7) * 3 // 5
        for x in range(8 - half, 8 + half):
            c = CONC_L if x < 6 else (CONC if x < 8 else CONC_D)
            if y % 4 == 3:
                c = CONC_D if x < 8 else (110, 118, 146)
            px.set(x, y, c)
    for (x, y) in ((6, 1), (7, 0), (9, 1), (8, 1)):
        px.set(x, y, TOX_L)
    for y in range(11, 15):                    # porta com brilho radioativo
        px.set(7, y, (24, 28, 24))
        px.set(8, y, TOX_L if y == 12 else (24, 28, 24))
    px.set(5, 5, TOX_M)
    px.set(10, 9, TOX_M)
    if done:
        for y in range(0, 5):
            px.set(14, y, (230, 236, 250))
        for y, w in ((0, 2), (1, 1)):
            for x in range(15, 15 + w):
                px.set(x, y, RED)
    px = outline(px, OUT2)
    return dim(px, 0.7) if locked else px


def _build_layout2():
    g = [["s"] * MAP_COLS for _ in range(MAP_ROWS)]
    for c in range(MAP_COLS):
        g[0][c] = "w"
        g[MAP_ROWS - 1][c] = "w"
    for r in range(MAP_ROWS):
        g[r][0] = "w"
        g[r][MAP_COLS - 1] = "w"
    for (c, r) in ((1, 1), (18, 1), (1, 8), (18, 8)):
        g[r][c] = "w"
    lake = {3: range(9, 14), 4: range(9, 14), 5: range(10, 13)}          # lago toxico
    for r, cols in lake.items():
        for c in cols:
            g[r][c] = "w"
    for r in (7, 8):                                                      # baia no canto de baixo
        for c in range(13, 18):
            g[r][c] = "w"
    for (c, r) in ((4, 8), (5, 8), (5, 7), (6, 8)):                       # poca toxica
        g[r][c] = "w"
    # geleiras derretendo (gelo) + blocos flutuando no lago
    for (c, r) in ((3, 2), (4, 2), (5, 2), (4, 3), (5, 3), (18, 5), (18, 6), (17, 5), (17, 6),
                   (8, 8), (9, 8), (9, 7), (10, 4), (12, 4), (11, 3)):
        g[r][c] = "i"
    return g


LAYOUT2 = _build_layout2()
NODES2 = [
    {"tile": (2, 7), "nome": "GELEIRA DERRETENDO", "boss": False},
    {"tile": (6, 4), "nome": "LAGO RADIOATIVO", "boss": False},
    {"tile": (11, 6), "nome": "PICOS CONTAMINADOS", "boss": False},
    {"tile": (17, 3), "nome": "REATOR DO CHEFE", "boss": True},
]
EDGES2 = [
    [(2, 7), (2, 6), (2, 5), (2, 4), (3, 4), (4, 4), (5, 4), (6, 4)],
    [(6, 4), (6, 5), (6, 6), (7, 6), (8, 6), (9, 6), (10, 6), (11, 6)],
    [(11, 6), (12, 6), (13, 6), (14, 6), (15, 6), (15, 5), (15, 4), (15, 3), (16, 3), (17, 3)],
]
DEAD_TREES = [(1, 2), (1, 3), (2, 2), (1, 5), (1, 6), (3, 6), (4, 6), (8, 2), (9, 1), (6, 2),
              (14, 1), (15, 1), (12, 1), (8, 4), (14, 4), (13, 8), (10, 8), (7, 8), (16, 5), (18, 3)]
MELT_MOUNTS = [(7, 2), (14, 2), (16, 1), (3, 5), (11, 8), (12, 7), (17, 8)]
BARRELS = [(7, 5), (10, 7), (14, 5), (4, 5), (12, 2), (3, 7), (8, 7), (16, 4), (5, 6), (13, 5)]
PATH_CELLS2 = set(t for e in EDGES2 for t in e)


def build_scenery2():
    """Mapa do mundo 2 (320x160): 2 quadros de agua toxica."""
    W, H = MAP_W, MAP_H
    base = Px(W, H)
    kind = [[None] * W for _ in range(H)]
    for r in range(MAP_ROWS):
        for c in range(MAP_COLS):
            k = LAYOUT2[r][c]
            base.blit(make_tile2(k, c, r), c * TS, r * TS)
            for j in range(TS):
                for i in range(TS):
                    kind[r * TS + j][c * TS + i] = k
    cliff = [[False] * W for _ in range(H)]
    for x in range(W):
        for y in range(H - 1):
            if kind[y][x] in ("s", "i") and kind[y + 1][x] == "w":
                for k in range(1, 6):
                    yy = y + k
                    if yy >= H or kind[yy][x] != "w":
                        break
                    cliff[yy][x] = True
                    if k == 1:
                        c = CLF2_L
                    elif k == 5:
                        c = CLF2_D
                    else:
                        c = CLF2 if (x // 2 + k) % 4 else CLF2_D
                    base.set(x, yy, c)
    water = [[kind[y][x] == "w" and not cliff[y][x] for x in range(W)] for y in range(H)]
    land = [[not water[y][x] for x in range(W)] for y in range(H)]
    d_water = _dist(water, W, H, 4)
    d_land = _dist(land, W, H, 4)
    for y in range(H):
        for x in range(W):
            k = kind[y][x]
            if cliff[y][x]:
                continue
            d = d_water[y][x]
            if k == "s":
                if d == 1:
                    base.set(x, y, GR_DD)
                elif d == 2:
                    base.set(x, y, GR_D)
            elif k == "i":
                if d == 1:
                    base.set(x, y, MELT)
                elif d == 2 and (x + y) % 2 == 0:
                    base.set(x, y, ICE_D)
    # trilhas
    pmask = [[(x // TS, y // TS) in PATH_CELLS2 for x in range(W)] for y in range(H)]
    for y in range(H):
        for x in range(W):
            if pmask[y][x]:
                c = PATH2
                edge = False
                for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    xx, yy = x + dx, y + dy
                    if 0 <= xx < W and 0 <= yy < H and not pmask[yy][xx]:
                        edge = True
                if edge:
                    c = PATH2_D
                elif _hash(x, y, 9) % 17 == 0:
                    c = PATH2_L
                base.set(x, y, c)
    # decoracoes
    deco = [(r, c, "m") for (c, r) in MELT_MOUNTS] + [(r, c, "t") for (c, r) in DEAD_TREES] \
        + [(r, c, "b") for (c, r) in BARRELS]
    spr = {"t": make_dead_tree(), "m": make_melt_mountain(), "b": make_barrel()}
    used = set()
    for (r, c, k) in sorted(deco):
        if (c, r) in PATH_CELLS2 or (c, r) in used or LAYOUT2[r][c] != "s":
            continue
        used.add((c, r))
        base.blit(spr[k], c * TS, r * TS)
    # 2 quadros de agua toxica (ondas + espuma + bolhas)
    frames = []
    for f in range(2):
        img = base.copy()
        sh = f * 4
        for y in range(H):
            for x in range(W):
                if not water[y][x]:
                    continue
                dl = d_land[y][x]
                c = TOX
                wy = y % 8
                if wy in (2, 6) and ((x + sh + (4 if wy == 6 else 0)) % 8) < 3:
                    c = TOX_L
                if dl == 1:
                    c = FOAM2 if ((x + y + f * 2) % 5) != 0 else TOX_L
                elif dl == 2:
                    c = TOX_M if c == TOX else c
                elif dl > 3 and _hash(x // 5, y // 5, 11 + f) % 37 == 0 and (x + y) % 3 == 0:
                    c = FOAM2                 # bolhas estourando
                img.set(x, y, c)
        frames.append(img)
    return frames


# ================================================================ MUNDO 3: GELEIRAS NOTURNAS + FORTALEZA
OUT3 = (12, 12, 40)
SNOW3, SNOW3_L, SNOW3_D, SNOW3_DD = (178, 198, 244), (218, 232, 255), (136, 156, 218), (98, 114, 186)
WATER3, WATER3_M, WATER3_L, FOAM3 = (18, 30, 104), (30, 50, 138), (70, 104, 204), (176, 206, 255)
ICE3, ICE3_L, ICE3_D = (120, 186, 236), (190, 232, 255), (80, 130, 210)
CLF3, CLF3_D, CLF3_L = (40, 46, 108), (26, 30, 78), (66, 76, 148)
PATH3, PATH3_L, PATH3_D = (160, 136, 140), (190, 166, 168), (112, 92, 106)
MET, MET_L, MET_D = (52, 60, 104), (84, 96, 150), (30, 34, 70)
RED3, RED3_L = (255, 52, 72), (255, 170, 176)
TOX3 = (84, 240, 90)


def _moon(px):
    """Escurece e puxa para o azul-violeta (luar) um sprite do mundo 1."""
    n = Px(px.w, px.h)
    for y in range(px.h):
        for x in range(px.w):
            c = px.get(x, y)
            if c is not None:
                n.set(x, y, (int(c[0] * 0.72), int(c[1] * 0.78), min(255, int(c[2] * 0.95) + 14)))
    return n


def make_tile3(kind, x, y):
    px = Px(16, 16)
    for j in range(16):
        for i in range(16):
            gx, gy = x * 16 + i, y * 16 + j
            if kind == "s":
                c = SNOW3
                h = _hash(gx, gy, 3)
                if h % 23 == 0:
                    c = SNOW3_L
                elif h % 29 == 0:
                    c = SNOW3_D
            elif kind == "i":
                c = ICE3
                if (gx + gy) % 9 in (0, 1) and (gx // 3 + gy // 5) % 2 == 0:
                    c = ICE3_L
                elif _hash(gx, gy, 5) % 31 == 0:
                    c = ICE3_D
            else:
                c = WATER3
            px.set(i, j, c)
    return px


def make_fortress(locked=False, done=False):
    """No do chefe do mundo 3: fortaleza escura com luzes vermelhas e a caveira."""
    px = Px(16, 16)
    for y in range(6, 15):                       # corpo
        for x in range(2, 14):
            px.set(x, y, MET_L if x < 4 else (MET if x < 10 else MET_D))
    for y in range(2, 15):                       # torres laterais
        for x in list(range(2, 5)) + list(range(11, 14)):
            px.set(x, y, MET_L if x in (2, 11) else (MET if x in (3, 12) else MET_D))
    for x in range(1, 6):                        # neve no topo das torres
        px.set(x, 2, SNOW3_L)
        px.set(x + 10 if x + 10 < 16 else 15, 2, SNOW3_L)
    for x in range(5, 11):
        px.set(x, 6, SNOW3_L if x % 2 else SNOW3)
    for (x, y) in ((3, 0), (3, 1), (12, 0), (12, 1)):      # antenas + luzes
        px.set(x, y, RED3 if y == 0 else MET_D)
    for (x, y) in ((6, 4), (9, 4)):
        px.set(x, y, MET_D)
    px.set(6, 3, RED3)
    px.set(9, 3, RED3)
    # caveira vermelha
    for (x, y) in ((7, 8), (8, 8), (6, 9), (7, 9), (8, 9), (9, 9), (7, 10), (8, 10)):
        px.set(x, y, RED3)
    px.set(7, 9, MET_D)
    px.set(8, 9, MET_D)
    # porta
    for y in range(11, 15):
        px.set(7, y, (10, 10, 24))
        px.set(8, y, TOX3 if y == 12 else (10, 10, 24))
    if done:
        for y in range(0, 5):
            px.set(15, y, (230, 236, 250))
    px = outline(px, OUT3)
    return dim(px, 0.7) if locked else px


RUST, RUST_D, ASH, ASH_D = (150, 78, 44), (92, 46, 30), (70, 72, 110), (44, 46, 82)
FIRE1, FIRE2, FIRE3 = (255, 120, 30), (255, 200, 60), (255, 244, 170)


def make_stump():
    """Tronco de pinheiro quebrado e queimado, com farpas e neve em cima."""
    px = Px(16, 16)
    for y in range(8, 15):
        for x in range(6, 10):
            px.set(x, y, (86, 58, 56) if x < 8 else (56, 38, 44))
    for (x, y) in ((6, 7), (7, 6), (9, 7), (8, 8), (10, 8), (5, 9)):
        px.set(x, y, (86, 58, 56))
    px.set(7, 5, (56, 38, 44))
    for x in range(5, 11):
        px.set(x, 7 if x in (6, 9) else 8, SNOW3_L)
    for x in range(4, 12):
        px.set(x, 14, ASH_D)
    px.set(3, 13, ASH)
    px.set(12, 13, ASH)
    return outline(px, OUT3)


def make_ruin_wall():
    """Pedaco de muro/placa de metal rachado com ferros tortos e ferrugem."""
    px = Px(16, 16)
    prof = (5, 3, 7, 4, 8, 6, 3, 5, 9, 4, 6, 3)
    for i, top in enumerate(prof):
        x = 2 + i
        for y in range(top + 4, 15):
            c = MET_L if i < 3 else (MET if i < 8 else MET_D)
            if (i + y) % 5 == 0:
                c = RUST
            elif (i * 3 + y) % 7 == 0:
                c = RUST_D
            px.set(x, y, c)
        px.set(x, top + 3, SNOW3_L if i % 2 == 0 else SNOW3)
    for y in range(2, 8):                       # ferro torto saindo da ruina
        px.set(5 + (y // 3), y, RUST_D)
    for y in range(3, 9):
        px.set(11 - (y // 4), y, MET_D)
    return outline(px, OUT3)


def make_rubble():
    px = Px(16, 16)
    for (x, y, w, h, c) in ((3, 11, 4, 3, MET), (7, 10, 3, 4, MET_D), (9, 12, 4, 2, ASH), (5, 9, 2, 2, RUST),
                            (11, 10, 2, 2, MET_L), (2, 13, 2, 1, ASH_D)):
        for j in range(h):
            for i in range(w):
                px.set(x + i, y + j, c)
    px.set(4, 10, SNOW3_L)
    px.set(8, 9, SNOW3_L)
    return outline(px, OUT3)


FIRES3 = [(3, 2), (8, 2), (10, 5), (13, 4), (5, 6), (12, 7), (16, 2), (4, 5)]       # fogueiras/escombros em chamas (tiles)
CRATERS3 = [(5, 3), (10, 2), (3, 6), (9, 5), (13, 5), (16, 1), (12, 1), (6, 6)]     # (coluna, linha) do centro
STUMPS3 = [(1, 2), (2, 2), (4, 1), (9, 2), (13, 2), (16, 1), (1, 6), (12, 3), (5, 5), (13, 4), (18, 4)]
RUINS3 = [(4, 2), (8, 5), (11, 2), (15, 4), (3, 5), (10, 4), (13, 7), (6, 3), (16, 6)]
RUBBLE3 = [(5, 4), (9, 3), (12, 4), (2, 3), (14, 2), (7, 5), (4, 7), (11, 5), (15, 1), (8, 1), (13, 3), (3, 4)]


FORT_W, FORT_H = 64, 56
FORT_LIGHTS = ((7, 1), (3, 11), (60, 21), (21, 5), (41, 9), (46, 12), (55, 7))      # luzes vermelhas (x, y no sprite)


def make_fortress_big(locked=False, done=False):
    """Complexo industrial gigante (64x56 px): torres, chamines, domo, ponte, galpao com a caveira.
    Parte dele esta destruida (topo quebrado, buracos, ferrugem), combinando com o mapa."""
    px = Px(FORT_W, FORT_H)

    def rect(x, y, w, h, c):
        for j in range(h):
            for i in range(w):
                px.set(x + i, y + j, c)

    def metal(x, y, w, h, seed):
        for j in range(h):
            for i in range(w):
                c = MET_L if i < 2 else (MET if i < w - 3 else MET_D)
                if j % 6 == 5:
                    c = MET_D if i < w - 3 else (22, 24, 52)         # emendas horizontais
                elif _hash(x + i, y + j, seed) % 41 == 0:
                    c = RUST if i < w // 2 else RUST_D              # ferrugem
                px.set(x + i, y + j, c)

    # ponte/tubulacao entre as torres (atras do galpao)
    rect(12, 14, 40, 3, MET_D)
    for i in range(12, 52, 3):
        px.set(i, 14, MET_L)
        px.set(i + 1, 16, (22, 24, 52))
    rect(12, 13, 40, 1, SNOW3)
    # chamines com faixas vermelhas
    for (cx, top) in ((19, 5), (40, 9)):
        for j in range(top, 22):
            for i in range(4):
                c = MET_L if i == 0 else (MET if i < 3 else MET_D)
                if (j // 3) % 2 == 0 and j < top + 9:
                    c = RED3 if i < 3 else (170, 30, 50)
                px.set(cx + i, j, c)
        rect(cx - 1, top - 1, 6, 2, SNOW3_L)
    # torre esquerda (topo quebrado)
    metal(2, 10, 12, 44, 5)
    for i in range(12):
        top = 10 + (3 if i in (3, 4, 8) else 0) + (2 if i == 5 else 0)
        for j in range(10, top):
            px.set(2 + i, j, None)
        px.set(2 + i, top, SNOW3_L if i % 2 else SNOW3)
    for y in (18, 26, 34):                      # janelas com luz vermelha
        rect(5, y, 2, 3, (150, 24, 44))
        rect(9, y, 2, 3, (150, 24, 44) if y != 26 else (24, 20, 44))
    rect(7, 2, 1, 9, MET_D)                     # antena
    px.set(7, 1, (170, 30, 50))
    # torre direita + domo de vidro
    metal(50, 20, 12, 34, 9)
    for y in (26, 34, 42):
        rect(53, y, 2, 3, (150, 24, 44))
        rect(58, y, 2, 3, (150, 24, 44))
    cx, cy = 55.5, 17.0
    for y in range(8, 21):
        for x in range(48, 64):
            d = math.hypot(x - cx, (y - cy) * 1.05)
            if d <= 6.8:
                c = (120, 104, 214) if x > cx else (150, 134, 236)
                if d > 5.4:
                    c = (86, 76, 168)
                if (x - 53) ** 2 + (y - 13) ** 2 <= 3:
                    c = (230, 226, 255)               # brilho do vidro
                px.set(x, y, c)
    px.set(55, 7, (170, 30, 50))
    # galpao principal
    metal(14, 19, 36, 35, 13)
    rect(14, 19, 36, 2, SNOW3_L)
    for x in range(14, 50):
        if _hash(x, 3, 17) % 3 == 0:
            px.set(x, 21, SNOW3)                   # neve escorrendo pelo telhado
    for (x, y, w, h) in ((22, 24, 4, 3), (40, 38, 3, 4), (16, 44, 3, 3)):       # buracos de bombardeio
        rect(x, y, w, h, (14, 14, 34))
        px.set(x - 1, y + h, RUST_D)
    # painel da caveira
    rect(25, 22, 14, 13, (52, 10, 28))
    rect(25, 22, 14, 1, (110, 22, 44))
    rect(25, 34, 14, 1, (24, 6, 20))
    skull = ("..XXXXXX..", ".XXXXXXXX.", "XXXXXXXXXX", "XX..XX..XX", "XX..XX..XX",
             "XXXX..XXXX", ".XXXXXXXX.", "..X.XX.X..", "..XXXXXX..")
    for j, row in enumerate(skull):
        for i, ch in enumerate(row):
            if ch == "X":
                px.set(27 + i, 24 + j, RED3 if j < 6 else (214, 40, 62))
    # porta com brilho toxico + escada
    rect(29, 46, 6, 8, (10, 10, 24))
    rect(29, 52, 6, 1, TOX3)
    px.set(30, 51, (40, 170, 60))
    px.set(33, 51, (40, 170, 60))
    rect(27, 53, 10, 1, MET_L)
    for y in range(36, 53):                    # gosma toxica escorrendo do lado direito
        if y % 7 != 0:
            px.set(46, y, (40, 170, 60) if y % 2 else TOX3)
    # bandeira de aviso no telhado
    rect(44, 11, 1, 8, (230, 236, 250))
    rect(45, 11, 4, 3, RED3)
    # lampadas (apagadas; o mapa pisca por cima)
    for (lx, ly) in FORT_LIGHTS:
        px.set(lx, ly, (120, 20, 40))
    # chao com neve e escombros
    for x in range(0, FORT_W):
        h = _hash(x, 5, 23) % 3
        for j in range(54 - 0, 56):
            px.set(x, j, SNOW3_L if (x + j) % 3 else SNOW3)
        if h == 0:
            px.set(x, 53, SNOW3)
    px = outline(px, OUT3)
    if done:
        for y in range(0, 6):                   # bandeira de fase concluida no alto da antena
            px.set(8, y, (230, 236, 250))
        for y, w in ((0, 4), (1, 3), (2, 2)):
            for x in range(9, 9 + w):
                px.set(x, y, RED3)
    return dim(px, 0.7) if locked else px


def _build_layout3():
    g = [["s"] * MAP_COLS for _ in range(MAP_ROWS)]
    for c in range(MAP_COLS):
        g[0][c] = "w"
        g[MAP_ROWS - 1][c] = "w"
    for r in range(MAP_ROWS):
        g[r][0] = "w"
        g[r][MAP_COLS - 1] = "w"
    for (c, r) in ((1, 1), (18, 1), (1, 8), (18, 8)):
        g[r][c] = "w"
    lake = {7: range(4, 12), 8: range(3, 13)}                               # lago do meio
    for r, cols in lake.items():
        for c in cols:
            g[r][c] = "w"
    for r, cols in {5: range(15, 18), 4: range(16, 18), 6: range(16, 19)}.items():   # fosso da fortaleza
        for c in cols:
            g[r][c] = "w"
    for (c, r) in ((9, 7), (10, 8), (5, 7), (16, 5), (17, 4), (5, 2), (6, 2), (4, 2),
                   (10, 3), (11, 3), (3, 6), (13, 8)):                     # blocos de gelo
        g[r][c] = "i"
    return g


LAYOUT3 = _build_layout3()
NODES3 = [
    {"tile": (2, 7), "nome": "GELEIRA DA LUA", "boss": False},
    {"tile": (7, 4), "nome": "CACHOEIRAS CONGELADAS", "boss": False},
    {"tile": (12, 6), "nome": "PONTE DOS ANDAIMES", "boss": False},
    {"tile": (17, 3), "nome": "FORTALEZA CAVEIRA", "boss": True},
]
EDGES3 = [
    [(2, 7), (2, 6), (2, 5), (2, 4), (3, 4), (4, 4), (5, 4), (6, 4), (7, 4)],
    [(7, 4), (7, 5), (7, 6), (8, 6), (9, 6), (10, 6), (11, 6), (12, 6)],
    [(12, 6), (13, 6), (14, 6), (14, 5), (14, 4), (14, 3), (15, 3), (16, 3), (17, 3)],
]
PINES3 = [(1, 2), (1, 3), (2, 2), (3, 1), (4, 1), (8, 1), (9, 2), (12, 1), (13, 2), (15, 1), (16, 1),
          (1, 5), (1, 6), (3, 7), (6, 7), (12, 3), (11, 5), (9, 4), (5, 5), (4, 6), (13, 4), (18, 4), (18, 5)]
MOUNTS3 = [(6, 1), (10, 1), (3, 3), (11, 4), (8, 3), (17, 1), (15, 7), (14, 8)]
PATH_CELLS3 = set(t for e in EDGES3 for t in e)


def build_scenery3():
    """Mapa do mundo 3 (320x160), de noite: 2 quadros de agua escura com reflexo da lua."""
    W, H = MAP_W, MAP_H
    base = Px(W, H)
    kind = [[None] * W for _ in range(H)]
    for r in range(MAP_ROWS):
        for c in range(MAP_COLS):
            k = LAYOUT3[r][c]
            base.blit(make_tile3(k, c, r), c * TS, r * TS)
            for j in range(TS):
                for i in range(TS):
                    kind[r * TS + j][c * TS + i] = k
    cliff = [[False] * W for _ in range(H)]
    for x in range(W):
        for y in range(H - 1):
            if kind[y][x] in ("s", "i") and kind[y + 1][x] == "w":
                for k in range(1, 6):
                    yy = y + k
                    if yy >= H or kind[yy][x] != "w":
                        break
                    cliff[yy][x] = True
                    base.set(x, yy, CLF3_L if k == 1 else (CLF3_D if k == 5 else (CLF3 if (x // 2 + k) % 4 else CLF3_D)))
    water = [[kind[y][x] == "w" and not cliff[y][x] for x in range(W)] for y in range(H)]
    land = [[not water[y][x] for x in range(W)] for y in range(H)]
    d_water = _dist(water, W, H, 4)
    d_land = _dist(land, W, H, 4)
    for y in range(H):
        for x in range(W):
            if cliff[y][x]:
                continue
            k = kind[y][x]
            d = d_water[y][x]
            if k == "s":
                if d == 1:
                    base.set(x, y, SNOW3_DD)
                elif d == 2:
                    base.set(x, y, SNOW3_D)
            elif k == "i":
                if d == 1:
                    base.set(x, y, ICE3_D)
                elif d == 2 and (x + y) % 2 == 0:
                    base.set(x, y, ICE3)
    pmask = [[(x // TS, y // TS) in PATH_CELLS3 for x in range(W)] for y in range(H)]
    for y in range(H):
        for x in range(W):
            if pmask[y][x]:
                edge = False
                for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    xx, yy = x + dx, y + dy
                    if 0 <= xx < W and 0 <= yy < H and not pmask[yy][xx]:
                        edge = True
                c = PATH3_D if edge else (PATH3_L if _hash(x, y, 9) % 17 == 0 else PATH3)
                base.set(x, y, c)
    deco = [(r, c, "m") for (c, r) in MOUNTS3] + [(r, c, "t") for (c, r) in PINES3]
    spr = {"t": _moon(make_pine()), "m": _moon(make_mountain()), "s": make_stump(),
           "w": make_ruin_wall(), "u": make_rubble()}
    stump_set = set(STUMPS3)
    deco = [(r, c, "s" if (c, r) in stump_set or (c + r) % 3 == 0 else "t") if k == "t" else (r, c, k)
            for (r, c, k) in deco]
    deco += [(r, c, "w") for (c, r) in RUINS3] + [(r, c, "u") for (c, r) in RUBBLE3]
    used3 = set()
    for (r, c, k) in sorted(deco):
        if (c, r) in PATH_CELLS3 or (c, r) in used3 or LAYOUT3[r][c] != "s":
            continue
        used3.add((c, r))
        base.blit(spr[k], c * TS, r * TS)

    def is_land(x, y):
        return 0 <= x < W and 0 <= y < H and kind[y][x] in ("s", "i") and not cliff[y][x]

    # manchas de queimado (tudo ao redor dos incendios e crateras fica escuro)
    for (c, r) in FIRES3 + CRATERS3:
        cx, cy = c * TS + 8, r * TS + 8
        rad = 14 + _hash(c, r, 21) % 6
        for y in range(cy - rad, cy + rad):
            for x in range(cx - rad, cx + rad):
                if not is_land(x, y):
                    continue
                d = math.hypot(x - cx, (y - cy) * 1.2)
                if d < rad and _hash(x, y, 31) % 100 < int(100 * (1 - d / rad) ** 0.7):
                    cur = base.get(x, y)
                    if cur is not None and cur not in (OUT3,):
                        base.set(x, y, ASH_D if d < rad * 0.55 else ASH)
    # crateras: buraco escuro com borda levantada
    for (c, r) in CRATERS3:
        cx, cy = c * TS + 8, r * TS + 9
        for y in range(cy - 7, cy + 8):
            for x in range(cx - 10, cx + 11):
                if not is_land(x, y):
                    continue
                d = math.hypot((x - cx) / 10.0, (y - cy) / 6.5)
                if d < 0.62:
                    base.set(x, y, (20, 22, 52))
                elif d < 0.85:
                    base.set(x, y, (36, 40, 86) if y > cy else (28, 30, 66))
                elif d < 1.0:
                    base.set(x, y, SNOW3_L if (x + y) % 3 == 0 else SNOW3_D)
    # rachaduras no chao e no gelo (caminhada aleatoria fixa)
    for n in range(46):
        x = 6 + _hash(n, 3, 41) % (W - 12)
        y = 6 + _hash(n, 5, 43) % (H - 12)
        if not is_land(x, y):
            continue
        for st in range(10 + _hash(n, 7, 47) % 22):
            if is_land(x, y):
                on_path = pmask[y][x]
                base.set(x, y, PATH3_D if on_path and st % 2 else (30, 34, 84))
            h = _hash(x + st, y, 51 + n) % 4
            x += (1, 0, -1, 1)[h] if h != 2 else -1
            y += (0, 1, 1, 1)[h] if st % 3 else 0
    # gelo quebrado: lascas escuras no gelo
    for y in range(H):
        for x in range(W):
            if kind[y][x] == "i" and not cliff[y][x] and _hash(x // 2, y // 2, 61) % 11 == 0:
                base.set(x, y, ICE3_D)
    # poças toxicas perto da fortaleza
    for (cx, cy, rr) in ((17 * TS + 6, 2 * TS + 12, 6), (15 * TS + 12, 1 * TS + 10, 4), (13 * TS + 4, 5 * TS + 6, 4)):
        for y in range(cy - rr, cy + rr):
            for x in range(cx - rr * 2, cx + rr * 2):
                if is_land(x, y) and not pmask[y][x] and math.hypot((x - cx) / 2.0, y - cy) < rr:
                    base.set(x, y, TOX3 if (x + y) % 4 else (40, 170, 60))
    # entulho boiando na agua (blocos de gelo/metal quebrados)
    for n in range(26):
        x = 4 + _hash(n, 9, 71) % (W - 10)
        y = 4 + _hash(n, 11, 73) % (H - 8)
        if all(water[y + j][x + i] for j in range(3) for i in range(5) if y + j < H and x + i < W):
            c = ICE3_L if n % 3 else MET
            for i in range(4):
                base.set(x + i, y, c)
                base.set(x + i + 1, y + 1, ICE3 if c == ICE3_L else MET_D)
    frames = []
    moon_x, moon_y = 6 * TS + 8, 8 * TS + 6          # reflexo da lua no lago
    for f in range(2):
        img = base.copy()
        sh = f * 4
        for y in range(H):
            for x in range(W):
                if not water[y][x]:
                    continue
                dl = d_land[y][x]
                c = WATER3
                wy = y % 8
                if wy in (2, 6) and ((x + sh + (4 if wy == 6 else 0)) % 8) < 3:
                    c = WATER3_L
                if dl == 1:
                    c = FOAM3 if ((x + y + f * 2) % 5) != 0 else WATER3_L
                elif dl == 2:
                    c = WATER3_M if c == WATER3 else c
                if abs(x - moon_x) < 7 - (y - moon_y) % 2 * 2 and abs(y - moon_y) < 5 and (y + f) % 2 == 0 and kind[y][x] == "w":
                    c = FOAM3
                img.set(x, y, c)
        for (c, r) in FIRES3:                       # chamas tremulas + fumaca
            bx, by = c * TS + 8, r * TS + 12
            for k, (dx, dy, col) in enumerate(((0, 0, FIRE1), (1, 0, FIRE1), (-1, 0, FIRE1), (0, -1, FIRE2), (0, -2, FIRE3 if f else FIRE2),
                                              (1, -1, FIRE2), (-1, -1, FIRE1 if f else FIRE2), (f * 2 - 1, -3, FIRE1),
                                              (2, 0, FIRE1), (-2, 0, FIRE1), (0, 1, FIRE1), (1, 1, FIRE1), (-1, 1, FIRE1), (0, -4 + f, FIRE2))):
                img.set(bx + dx, by + dy, col)
            img.set(bx + (1 if f else -1), by - 5, ASH)
            img.set(bx + (0 if f else 1), by - 7, ASH_D)
        for (x, y) in ((cx0, cy0) for (cx0, cy0) in ((6 * TS + 4, 2 * TS + 4), (15 * TS + 3, 6 * TS + 2))):
            img.set(x, y - f, RED3)
        frames.append(img)
    return frames


def _boss_sprites1():
    return {"locked": make_igloo(locked=True), "open": make_igloo(), "done": make_igloo(done=True)}


def _boss_sprites2():
    return {"locked": make_reactor(locked=True), "open": make_reactor(), "done": make_reactor(done=True)}


def _boss_sprites3():
    return {"locked": make_fortress_big(locked=True), "open": make_fortress_big(), "done": make_fortress_big(done=True)}


WORLDS = [
    {"nome": "MUNDO 1  -  GELEIRAS", "nodes": NODES, "edges": EDGES, "build": build_scenery,
     "boss": _boss_sprites1, "head": (12, 28, 78), "line": (96, 150, 230)},
    {"nome": "MUNDO 2  -  ZONA RADIOATIVA", "nodes": NODES2, "edges": EDGES2, "build": build_scenery2,
     "boss": _boss_sprites2, "head": (14, 38, 24), "line": (130, 230, 90)},
    {"nome": "MUNDO 3  -  GELEIRAS NOTURNAS", "nodes": NODES3, "edges": EDGES3, "build": build_scenery3,
     "boss": _boss_sprites3, "head": (14, 12, 52), "line": (150, 110, 255)},
]


# ---------------------------------------------------------------- logica do mapa
DIRS = {"left": (-1, 0), "right": (1, 0), "up": (0, -1), "down": (0, 1)}


def _vec_name(dx, dy):
    if abs(dx) >= abs(dy):
        return "right" if dx > 0 else "left"
    return "down" if dy > 0 else "up"


class OverWorld(object):
    SPEED = 5.5          # tiles por segundo

    def __init__(self, done=(), world=0):
        self.wi = world
        self.wd = WORLDS[world]
        self.nodes_def = self.wd["nodes"]
        self.edges = self.wd["edges"]
        self.done = set(done)
        self.cur = 0
        self.walk = None            # dict(path, s, dst)
        self.facing = "down"
        self.anim = 0.0
        self.msg = ""
        self.msg_t = 0.0
        self.auto_t = 0.0           # >0: espera e depois anda sozinho ate a proxima fase
        self.auto_dst = None
        self.t = 0.0
        self._pg = None

    # --- regras
    def unlocked(self, i):
        return i == 0 or (i - 1) in self.done

    def first_open(self):
        for i in range(len(self.nodes_def)):
            if i not in self.done and self.unlocked(i):
                return i
        return len(self.nodes_def) - 1

    def edge_path(self, a, b):
        if b == a + 1:
            return list(self.edges[a])
        if b == a - 1:
            return list(reversed(self.edges[b]))
        return None

    def key(self, name):
        """name: 'left' | 'right' | 'up' | 'down'. Anda para o no vizinho naquela direcao."""
        if self.walk is not None or self.auto_t > 0:
            return
        dx, dy = DIRS[name]
        best = None
        for b in (self.cur + 1, self.cur - 1):
            if not (0 <= b < len(self.nodes_def)):
                continue
            path = self.edge_path(self.cur, b)
            step = (path[1][0] - path[0][0], path[1][1] - path[0][1])
            if step == (dx, dy):
                best = b
                break
            # alternativa: direcao geral do deslocamento
            tot = (path[-1][0] - path[0][0], path[-1][1] - path[0][1])
            if _vec_name(*tot) == name and best is None:
                best = b
        if best is None:
            return
        if not self.unlocked(best):
            self.msg, self.msg_t = "TERMINE ESTA FASE PRIMEIRO!", 1.6
            return
        self.start_walk(best)

    def start_walk(self, dst):
        path = self.edge_path(self.cur, dst)
        if path is None:
            self.cur = dst
            return
        self.walk = {"path": path, "s": 0.0, "dst": dst}

    def complete(self, i, auto=True):
        """Marca a fase como concluida; o pinguim vai sozinho para a proxima (como no SMW)."""
        self.done.add(i)
        self.cur = i
        self.walk = None
        if auto and i + 1 < len(self.nodes_def):
            self.auto_t = 0.9
            self.auto_dst = i + 1

    def update(self, dt):
        self.t += dt
        if self.msg_t > 0:
            self.msg_t -= dt
        if self.auto_t > 0:
            self.auto_t -= dt
            if self.auto_t <= 0 and self.auto_dst is not None:
                self.start_walk(self.auto_dst)
                self.auto_dst = None
        if self.walk is not None:
            w = self.walk
            w["s"] += self.SPEED * dt
            self.anim += dt * 9.0
            last = len(w["path"]) - 1
            i = min(int(w["s"]), last)
            if i < last:
                a, b = w["path"][i], w["path"][i + 1]
                self.facing = _vec_name(b[0] - a[0], b[1] - a[1])
            if w["s"] >= last:
                self.cur = w["dst"]
                self.walk = None
                self.anim = 0.0
                self.facing = "down"

    def pos_px(self):
        """Posicao (px logicos) do canto superior-esquerdo do sprite do pinguim."""
        if self.walk is None:
            c, r = self.nodes_def[self.cur]["tile"]
            return c * TS, r * TS - 5
        w = self.walk
        path = w["path"]
        last = len(path) - 1
        s = min(w["s"], last)
        i = min(int(s), last - 1)
        f = s - i
        a, b = path[i], path[i + 1]
        x = (a[0] + (b[0] - a[0]) * f) * TS
        y = (a[1] + (b[1] - a[1]) * f) * TS - 5
        return int(round(x)), int(round(y))

    # --- desenho
    def _surf(self, px, alpha):
        pg = self._pg
        if alpha:
            return pg.image.frombuffer(px.rgba_bytes(), (px.w, px.h), "RGBA").convert_alpha()
        return pg.image.frombuffer(px.rgb_bytes(), (px.w, px.h), "RGB").convert()

    def init_surfaces(self, pg):
        self._pg = pg
        self.bg = [self._surf(f, False) for f in self.wd["build"]()]
        self.pen = {}
        for d in ("down", "up", "right", "left"):
            self.pen[d] = [self._surf(make_penguin(d, s), True) for s in range(5)]
        self.nodes = []
        for i, n in enumerate(self.nodes_def):
            if n["boss"]:
                bs = self.wd["boss"]()
                self.nodes.append({k: self._surf(v, True) for k, v in bs.items()})
            else:
                num = i + 1
                self.nodes.append({
                    "locked": self._surf(make_dot((120, 132, 168), (84, 96, 136), num, (64, 74, 112)), True),
                    "open": self._surf(make_dot((255, 214, 64), (226, 150, 30), num), True),
                    "open2": self._surf(make_dot((255, 240, 150), (240, 180, 50), num), True),
                    "done": self._surf(make_flag_dot(), True),
                })
        self.icon = self.pen["down"][0]

    def draw(self, canvas):
        """Desenha o mapa em 'canvas' (superficie logica) com origem em (0, 0)."""
        canvas.blit(self.bg[int(self.t * 2.2) % 2], (0, 0))
        for i, n in enumerate(self.nodes_def):
            c, r = n["tile"]
            if i in self.done:
                s = self.nodes[i]["done"]
            elif self.unlocked(i):
                blink = int(self.t * 4) % 2
                s = self.nodes[i].get("open2" if blink else "open", self.nodes[i]["open"])
            else:
                s = self.nodes[i]["locked"]
            sw_, sh_ = s.get_size()                 # sprites maiores que 1 tile (fortaleza): centrados e com a base no tile
            bx_ = c * TS + TS // 2 - sw_ // 2 if sw_ > TS else c * TS
            by_ = r * TS + TS - sh_ if sh_ > TS else r * TS
            canvas.blit(s, (bx_, by_))
        x, y = self.pos_px()
        step = 0
        if self.walk is not None:
            step = 1 + int(self.anim) % 4
        elif self.msg_t <= 0:
            step = 0
        bob = 0
        canvas.blit(self.pen[self.facing][step], (x, y + bob))
        if self.wi == 2:                       # luzes vermelhas da fortaleza piscando
            pg = self._pg
            bc, br = self.nodes_def[-1]["tile"]
            ox_, oy_ = bc * TS + TS // 2 - FORT_W // 2, br * TS + TS - FORT_H
            for k, (lx, ly) in enumerate(FORT_LIGHTS):
                if int(self.t * 2.4 + k * 0.7) % 2 == 0:
                    pg.draw.rect(canvas, (255, 70, 90), (ox_ + lx, oy_ + ly, 1, 1))
                    pg.draw.rect(canvas, (190, 40, 66), (ox_ + lx - 1, oy_ + ly, 3, 1))
                    pg.draw.rect(canvas, (190, 40, 66), (ox_ + lx, oy_ + ly - 1, 1, 3))
        if self.wi == 1:                       # vapor verde do reator + brilho radioativo
            pg = self._pg
            bc, br = self.nodes_def[-1]["tile"]
            for k in range(5):
                ph = (self.t * 0.9 + k * 0.2) % 1.0
                sx = bc * TS + 7 + int(math.sin(self.t * 2 + k * 1.7) * 2) + (k % 2) * 2
                sy = br * TS - int(ph * 16)
                sz = 1 + int(ph * 2)
                col = (132, 242, 96) if ph < 0.7 else (200, 250, 170)
                pg.draw.rect(canvas, col, (sx, sy, sz, sz))
