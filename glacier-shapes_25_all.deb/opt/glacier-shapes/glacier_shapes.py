#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
GLACIER SHAPES  -  platformer rapido de dash (estilo Monbo's Quest)

Requisitos:  pip install pygame
Executar:    python glacier_shapes.py

Controles
  <- -> / A D ........ mover
  ESPACO / W / ^ / K . pular (segure para pular mais alto, funciona como pulo na parede)
  J .................. DASH (SO NO CHAO): o pinguim escorrega de barriga
  PULO durante o dash . LANCAMENTO: o pinguim e atirado pra frente, voando deitado
  J + ESPACO juntos ... SUPER DASH: dash e lancamento no mesmo instante (precisa estar no chao e com o dash carregado)
  P .................. pausar          R .... reiniciar fase        ESC .... sair

O dash quebra blocos de gelo e e a forma de machucar os chefes (recarga de 1s).
"""
import os
import sys
import math
import random

import pygame

BASE = os.path.dirname(os.path.abspath(__file__))
ASSETS = os.path.join(BASE, "assets")
sys.path.insert(0, BASE)
from mapa_fases import OverWorld, NODES, WORLDS, MAP_W, MAP_H      # mapa de selecao de fases (16x16)
SAVE_FILE = os.path.join(os.path.expanduser("~"), ".glacier_shapes_save.json")

W, H = 1280, 720
T = 48
GROUND_MARGIN = 6   # sobra lateral da neve do chao (px)
PLAT_MARGIN = 4     # sobra lateral das ilhas (px)
FPS = 60

# ---------------------------------------------------------------- fisica
GRAV = 2300.0
MAX_FALL = 1100.0
RUN_SPEED = 450.0
GROUND_ACC = 4200.0
GROUND_FRIC = 3600.0
AIR_ACC = 2600.0
JUMP_V = 860.0
DASH_SPEED = 1000.0
DASH_TIME = 0.26
DASH_COOLDOWN = 1.0     # recarga (s) contada a partir do FIM do dash
DASH_RECOVER = 0.16     # tempo da pose de recuperacao depois do dash
LAUNCH_VY = 0.78        # forca vertical do lancamento (pulo durante o dash) em relacao ao pulo normal
LAUNCH_VX = 1.10        # velocidade horizontal do lancamento em relacao ao DASH_SPEED
COYOTE = 0.10
JUMP_BUFFER = 0.12

# ---------------------------------------------------------------- fase
NUM_PARTS = 4              # numero de fases (cada uma e uma fase separada)
PART_START_COLS = [0, 0, 0, 0]        # (cada fase agora usa colunas proprias, comecando em 0)
STAGE_COLS = [152, 182, 166, 211]     # largura de cada fase (em tiles)
PHASE_TIME = 60.0          # segundos para passar de cada fase
STAGE_SPAWNS = [
    (3 * T, H - 3 * T),
    (2 * T, H - 4 * T),
    (2 * T, H - 5 * T),
    (2 * T, H - 4 * T),
]
STAGE_BOSS = {1: "drone", 3: "golem"}       # fase 2 = CRIO-DRONE, fase 4 = CRIO-GOLEM (final)
STAGE_ARENA_COL = {1: 154, 3: 178}          # coluna onde comeca a arena do chefe
STAGE_GOAL = {0: 142.5, 2: 155.5}           # coluna do iglu de chegada (fases sem chefe)
STAGE_GOAL_N = {0: 142.5, 1: 160.0, 2: 155.5}   # Mundo 3: so tem UM chefe (FILIPE, fase 4) -> a fase 2 termina no iglu


def stage_boss(stage, world_idx):
    """Chefe do fim da fase neste mundo (None = a fase termina no iglu)."""
    if world_idx == 2:                       # Mundo 3: um unico chefe, o FILIPE (com o GOLEM NEGRO)
        return "filipe" if stage == 3 else None
    k = STAGE_BOSS.get(stage)
    if world_idx == 1 and k == "golem":
        return "cara"                        # Mundo 2: o chefe final e o DIOGO
    if world_idx == 1 and k == "drone":
        return "slime"                       # Mundo 2: o chefe da fase 2 e a GELEIA
    return k
GOAL_W, GOAL_H = 224, 144                   # iglu 56x36 ampliado 4x
CLEAR_TIME = 8.2                            # duracao do final de fase (painel de resultado)
CLEAR_SKIP = 5.0                            # a partir daqui ENTER pula o final (placar ja terminou)
STAGE_LIVES = 5                             # vidas GLOBAIS (valem para todos os mundos; 0 vidas = GAME OVER e volta para a fase 1)
CONF_COLORS = [(255, 240, 130), (150, 230, 255), (255, 255, 255),
               (255, 120, 140), (130, 255, 190), (190, 150, 255)]

# ---------------------------------------------------------------- quiz (depois de cada chefe)
# (pergunta, [opcoes], indice da correta). As opcoes sao embaralhadas a cada vez.
QUIZ_POR_CHEFE = 1            # quantas perguntas cada chefe faz (sorteadas do banco dele)
QUIZ_BANCO = {
    # CRIO-DRONE (Mundo 1, fase 2)
    "drone": [
        ("O que é o aquecimento global?",
         ["O aumento da temperatura média da Terra.", "O resfriamento dos oceanos.",
          "O aumento da quantidade de animais.", "A diminuição da luz solar."], 0),
        ("Qual destes gases contribui para o aquecimento global?",
         ["Oxigênio.", "Gás carbônico (CO2).", "Hélio.", "Nitrogênio."], 1),
        ("Qual é uma das principais causas do aquecimento global?",
         ["Plantar árvores.", "Reciclar materiais.", "Queimar combustíveis fósseis.", "Economizar água."], 2),
    ],
    # CRIO-GOLEM (Mundo 1, fase 4)
    "golem": [
        ("Como o aquecimento global afeta os pinguins?",
         ["Aumenta o tamanho das geleiras.", "Derrete o gelo e prejudica seu habitat.",
          "Faz os oceanos ficarem mais frios.", "Aumenta a quantidade de alimento."], 1),
        ("O que acontece quando grandes quantidades de gelo polar derretem?",
         ["O nível do mar pode subir.", "O nível do mar diminui.", "Os oceanos desaparecem.",
          "A temperatura da Terra diminui."], 0),
        ("Por que o gelo claro das geleiras ajuda a esfriar o planeta?",
         ["Porque reflete a luz do Sol de volta ao espaço.", "Porque produz oxigênio.",
          "Porque absorve todo o calor.", "Porque libera gás carbônico."], 0),
    ],
    # GELEIA (Mundo 2, fase 2)
    "slime": [
        ("Qual atitude ajuda a combater o aquecimento global?",
         ["Desmatar florestas.", "Desperdiçar energia.", "Queimar lixo.", "Utilizar energias renováveis."], 3),
        ("Qual destas é uma fonte de energia renovável?",
         ["Carvão mineral.", "Energia solar.", "Petróleo.", "Gás natural."], 1),
        ("O que as florestas fazem pelo clima?",
         ["Produzem gás carbônico em excesso.", "Aquecem o ar ao redor.",
          "Absorvem gás carbônico da atmosfera.", "Impedem a chuva."], 2),
    ],
    # FILIPE (Mundo 3, fase 4, chefe final)
    "filipe": [
        ("O que é a pegada de carbono?",
         ["A marca que os pés deixam na neve.", "A quantidade de gases de efeito estufa que uma pessoa ou empresa emite.",
          "Um tipo de combustível limpo.", "O peso total do carvão no mundo."], 1),
        ("Qual atitude de uma empresa ajuda a reduzir a poluição?",
         ["Despejar resíduos nos rios.", "Tratar o lixo e usar energia limpa.", "Queimar mais combustível.",
          "Cortar florestas inteiras."], 1),
        ("Por que reciclar ajuda o planeta?",
         ["Porque gasta mais energia para fabricar tudo de novo.", "Porque reduz o lixo e a extração de recursos naturais.",
          "Porque aumenta a quantidade de lixo nos oceanos.", "Porque derrete o gelo mais rápido."], 1),
    ],
    # DIOGO (Mundo 2, fase 4, chefe final)
    "cara": [
        ("O que é o efeito estufa?",
         ["Um gás que só existe nas fábricas.", "Uma camada de gases que retém parte do calor do Sol perto da Terra.",
          "Uma estufa de plantas gigante.", "A falta de gases na atmosfera."], 1),
        ("Qual atitude do dia a dia ajuda o planeta?",
         ["Deixar luzes acesas à toa.", "Jogar lixo na rua.", "Usar mais o transporte coletivo ou a bicicleta.",
          "Usar o carro para qualquer distância."], 2),
        ("Qual é o principal gás emitido ao queimar petróleo e carvão?",
         ["Gás carbônico (CO2).", "Hélio.", "Oxigênio puro.", "Vapor de leite."], 0),
    ],
}
QUIZ = []                     # perguntas do chefe atual (montadas em start_quiz)
QUIZ_KEYS = {pygame.K_1: 0, pygame.K_2: 1, pygame.K_3: 2, pygame.K_4: 3,
             pygame.K_KP1: 0, pygame.K_KP2: 1, pygame.K_KP3: 2, pygame.K_KP4: 3}

JUMP_KEYS = (pygame.K_SPACE, pygame.K_UP, pygame.K_w, pygame.K_k)


# ---------------------------------------------------------------- utilidades
def clamp(v, a, b):
    return max(a, min(b, v))


def lerp(a, b, t):
    return a + (b - a) * t


def sign(v):
    return (v > 0) - (v < 0)


def approach(v, target, delta):
    if v < target:
        return min(v + delta, target)
    return max(v - delta, target)


def draw_text(surf, font, text, x, y, color=(255, 255, 255),
              shadow=(12, 22, 70), center=False, alpha=255):
    img = font.render(text, True, color)
    sh = font.render(text, True, shadow)
    if alpha < 255:
        img.set_alpha(alpha)
        sh.set_alpha(alpha)
    if center:
        x = x - img.get_width() // 2
    surf.blit(sh, (x + 3, y + 3))
    surf.blit(img, (x, y))


def add_flash(surf, amount=(150, 150, 150)):
    s = surf.copy()
    s.fill(amount + (0,), special_flags=pygame.BLEND_RGB_ADD)
    return s


# ---- efeitos compartilhados dos chefes: brilho aditivo, rastros e mola (squash & stretch)
_GLOW = {}


def glow_sprite(r, color):
    """Bolinha de luz (radial) para soma aditiva. Fica em cache por (raio, cor)."""
    key = (int(r), color)
    sp = _GLOW.get(key)
    if sp is None:
        r = int(r)
        sp = pygame.Surface((2 * r, 2 * r))
        sp.fill((0, 0, 0))
        steps = max(4, r // 2)
        for i in range(steps):
            f = ((i + 1) / float(steps)) ** 2
            rad = max(1, int(r * (1.0 - i / float(steps))))
            pygame.draw.circle(sp, (int(color[0] * f), int(color[1] * f), int(color[2] * f)), (r, r), rad)
        _GLOW[key] = sp
    return sp


def draw_glow(surf, x, y, r, color, k=1.0):
    """Luz suave (soma de cor). k = intensidade 0..1."""
    r = max(4, int(r) // 2 * 2)
    q = max(0, min(8, int(k * 8 + 0.5)))
    if q <= 0:
        return
    c = (color[0] * q // 8, color[1] * q // 8, color[2] * q // 8)
    surf.blit(glow_sprite(r, c), (int(x - r), int(y - r)), special_flags=pygame.BLEND_RGB_ADD)


_SHADOW = {}


def draw_shadow(surf, x, y, w, k=1.0):
    """Sombra oval macia no chao (x, y em tela). k = escurecimento 0..1."""
    w = max(8, int(w) // 4 * 4)
    q = max(1, min(6, int(k * 6 + 0.5)))
    sp = _SHADOW.get((w, q))
    if sp is None:
        h = max(4, w // 5)
        sp = pygame.Surface((w, h), pygame.SRCALPHA)
        for i in range(4):
            f = i / 4.0
            pygame.draw.ellipse(sp, (8, 14, 40, int(18 * q * (0.4 + f))),
                                (int(w * f * 0.18), int(h * f * 0.18), int(w * (1 - f * 0.36)), int(h * (1 - f * 0.36))))
        _SHADOW[(w, q)] = sp
    surf.blit(sp, (int(x - w / 2), int(y - sp.get_height() / 2)))


def trail_push(tr, x, y, n=10):
    tr.append((x, y))
    if len(tr) > n:
        del tr[0]


def draw_trail(surf, tr, cam, camy, color, r0, k=1.0):
    """Rastro luminoso que some aos poucos (do mais velho ao mais novo)."""
    n = len(tr)
    for i, (x, y) in enumerate(tr):
        f = (i + 1) / float(n)
        draw_glow(surf, x - cam, y - camy, r0 * (0.35 + 0.65 * f), color, f * 0.75 * k)


def spring(q, v, target, dt, k=240.0, c=17.0):
    """Mola amortecida: devolve (q, v). Da o efeito de borracha (squash & stretch)."""
    dt = min(dt, 0.033)
    v += ((target - q) * k - v * c) * dt
    return q + v * dt, v


def draw_ice_wave(surf, cam, camy, floor_y, w, t, pal=None):
    """Onda de choque de gelo: fileira de cristais que vao ficando menores atras da frente."""
    d = w[1]
    y = int(floor_y - camy)
    x0 = w[0] - cam
    # pal = (brilho1, brilho2, escuro, medio, claro, lateral); None = onda de gelo azul
    g1, g2, c0, c1, c2, c3 = pal or ((90, 170, 255), (70, 140, 240), (88, 150, 236),
                                     (150, 205, 255), (240, 250, 255), (190, 228, 255))
    draw_glow(surf, x0, y - 14, 64, g1, 0.8)
    draw_glow(surf, x0 - d * 60, y - 8, 56, g2, 0.45)
    for j in range(6):
        x = int(x0 - d * j * 24)
        k = 1.0 - j * 0.15
        hgt = int((36 + 7 * math.sin(t * 22 + j * 1.7)) * k)
        wd = max(4, int(22 * k))
        pygame.draw.polygon(surf, c0, [(x - wd, y), (x - 4, y - hgt), (x + wd, y)])
        pygame.draw.polygon(surf, c1, [(x - wd // 2, y), (x - 2, y - int(hgt * 0.86)), (x + wd // 3, y)])
        pygame.draw.polygon(surf, c2, [(x - wd // 4, y), (x - 2, y - int(hgt * 0.7)), (x + 2, y)])
        sx = x + int(d * 14 * k)                           # cristalzinho ao lado
        pygame.draw.polygon(surf, c3, [(sx - 5, y), (sx, y - int(hgt * 0.5)), (sx + 5, y)])


def ease_out_back(t):
    t = clamp(t, 0.0, 1.0)
    c1 = 1.70158
    c3 = c1 + 1.0
    return 1.0 + c3 * (t - 1.0) ** 3 + c1 * (t - 1.0) ** 2


def ease_out_bounce(t):
    t = clamp(t, 0.0, 1.0)
    n1, d1 = 7.5625, 2.75
    if t < 1 / d1:
        return n1 * t * t
    if t < 2 / d1:
        t -= 1.5 / d1
        return n1 * t * t + 0.75
    if t < 2.5 / d1:
        t -= 2.25 / d1
        return n1 * t * t + 0.9375
    t -= 2.625 / d1
    return n1 * t * t + 0.984375


def smoothstep(t):
    t = clamp(t, 0.0, 1.0)
    return t * t * (3.0 - 2.0 * t)


def draw_star(surf, cx, cy, R, fill, edge, inner=None):
    """Estrela de 5 pontas centrada em (cx, cy)."""
    def pts(r):
        out = []
        for i in range(10):
            ang = -math.pi / 2 + i * math.pi / 5
            rr = r if i % 2 == 0 else r * 0.46
            out.append((cx + math.cos(ang) * rr, cy + math.sin(ang) * rr))
        return out
    pygame.draw.polygon(surf, edge, pts(R))
    pygame.draw.polygon(surf, fill, pts(R * 0.82))
    if inner:
        pygame.draw.polygon(surf, inner, pts(R * 0.45))


def outlined_text(font, text, color, low_sub=(0, 0, 0), outline=(12, 22, 70), r=5):
    """Texto grande com contorno escuro e a metade de baixo mais escura (volume)."""
    base = font.render(text, True, color)
    w, h = base.get_size()
    if low_sub != (0, 0, 0):
        base.subsurface(pygame.Rect(0, h // 2, w, h - h // 2)).fill(
            low_sub + (0,), special_flags=pygame.BLEND_RGB_SUB)
    pad = r + 8
    out = pygame.Surface((w + pad * 2, h + pad * 2), pygame.SRCALPHA)
    dark = font.render(text, True, outline)
    for i in range(14):
        ang = i / 14.0 * math.tau
        out.blit(dark, (pad + int(math.cos(ang) * r), pad + int(math.sin(ang) * r) + 3))
    out.blit(base, (pad, pad))
    return out


# ---------------------------------------------------------------- assets
def load_img(name, alpha=True):
    """Carrega assets/<name>.raw (RGBA cru) sem depender do decodificador PNG do pygame."""
    with open(os.path.join(ASSETS, name + ".raw"), "rb") as f:
        data = f.read()
    w = int.from_bytes(data[0:4], "little")
    h = int.from_bytes(data[4:8], "little")
    surf = pygame.image.frombuffer(data[8:], (w, h), "RGBA").copy()
    return surf.convert_alpha() if alpha else surf.convert()


class Assets:
    def __init__(self):
        bg = load_img("cenario", False)
        if bg.get_size() != (W, H):
            bg = pygame.transform.smoothscale(bg, (W, H))
        self.bg = bg
        self.bg_flip = pygame.transform.flip(bg, True, False)
        # fundo do Mundo 2 (zona radioativa), gerado por ferramentas/gerar_toxico.py
        self.theme = 0                  # 0 = gelo (Mundo 1) | 1 = toxico (Mundo 2) | 2 = noite (Mundo 3)
        self.bg_t, self.bg_t_flip = bg, self.bg_flip
        if os.path.exists(os.path.join(ASSETS, "t_cenario.raw")):
            bgt = load_img("t_cenario", False)
            if bgt.get_size() != (W, H):
                bgt = pygame.transform.smoothscale(bgt, (W, H))
            self.bg_t = bgt
            self.bg_t_flip = pygame.transform.flip(bgt, True, False)
        # fundo do Mundo 3 (geleiras noturnas), gerado por ferramentas/gerar_noturno.py
        self.bg_n, self.bg_n_flip = bg, self.bg_flip
        if os.path.exists(os.path.join(ASSETS, "n_cenario.raw")):
            bgn = load_img("n_cenario", False)
            if bgn.get_size() != (W, H):
                bgn = pygame.transform.smoothscale(bgn, (W, H))
            self.bg_n = bgn
            self.bg_n_flip = pygame.transform.flip(bgn, True, False)

        self.font_s = pygame.font.Font(None, 30)
        self.font_xs = pygame.font.Font(None, 24)
        self.font_m = pygame.font.Font(None, 44)
        self.font_l = pygame.font.Font(None, 84)
        self.font_xl = pygame.font.Font(None, 140)

        # logo do menu (pixel art, ampliada sem suavizar)
        logo = load_img("titulo")
        self.logo = pygame.transform.scale(logo, (logo.get_width() * 5, logo.get_height() * 5))

        self.build_penguin()
        self.build_boss()
        self.cache = {}

    # ---- pinguim: partes separadas para animar a corrida por codigo
    def build_penguin(self):
        src = load_img("pinguim")
        sw, sh = src.get_size()
        FY, SPLIT = 33, 24
        body = src.copy()
        foot_l = pygame.Surface((sw, sh), pygame.SRCALPHA)
        foot_r = pygame.Surface((sw, sh), pygame.SRCALPHA)
        for y in range(FY, sh):
            for x in range(sw):
                r, g, b, a = body.get_at((x, y))
                if a > 0 and r > 150 and b < 130 and g > 60:
                    (foot_l if x < SPLIT else foot_r).set_at((x, y), (r, g, b, a))
                    body.set_at((x, y), (0, 0, 0, 0))
        self.p_body, self.p_fl, self.p_fr = body, foot_l, foot_r

        # ---- BRACOS (nadadeiras): saem do corpo e viram pecas que giram nos ombros.
        # nadadeira de tras = recorte do proprio sprite; a da frente e redesenhada aqui
        # (o sprite so mostrava uma pontinha dela) com as mesmas cores do pinguim.
        BACK_R = pygame.Rect(5, 22, 11, 11)
        arm_b = pygame.Surface((BACK_R.w, BACK_R.h), pygame.SRCALPHA)
        arm_b.blit(body, (0, 0), BACK_R)
        body.fill((0, 0, 0, 0), BACK_R)
        body.fill((0, 0, 0, 0), pygame.Rect(32, 21, 4, 12))      # pontinha da nadadeira da frente
        K_, B_, H_ = (42, 50, 71, 255), (61, 74, 108, 255), (92, 108, 150, 255)
        FRONT = ["KKKK.",
                 "KBHBK",
                 "KBBBK",
                 "KBBBK",
                 ".KBBK",
                 ".KBBK",
                 ".KBBK",
                 "..KBK",
                 "..KBK",
                 "...KK"]
        arm_f = pygame.Surface((5, len(FRONT)), pygame.SRCALPHA)
        for yy, row in enumerate(FRONT):
            for xx, ch in enumerate(row):
                if ch != ".":
                    arm_f.set_at((xx, yy), {"K": K_, "B": B_, "H": H_}[ch])
        PIV_B, PIV_F = (8, 1), (2, 1)             # ombro dentro de cada peca
        SH_B, SH_F = (13, 22), (30, 22)           # ombro no sprite do corpo

        REACH = 14                                  # alcance maximo de uma nadadeira (px)

        def arm_pixels(piece):
            pw, ph = piece.get_size()
            return [[(piece.get_at((x, y)) if piece.get_at((x, y))[3] > 0 else None) for x in range(pw)]
                    for y in range(ph)], pw, ph

        arm_b_px, arm_f_px = arm_pixels(arm_b), arm_pixels(arm_f)
        SUB = (-0.33, 0.0, 0.33)

        def put_arm(cv, arm, pivot, pos, ang):
            """Gira a nadadeira em volta do ombro (pivot) por amostragem 3x3: as bordas ficam
            conectadas e nitidas (sem os pixels soltos do rotate comum). ang em graus, anti-horario."""
            px, pw, ph = arm
            a = math.radians(ang)
            ca, sa = math.cos(a), math.sin(a)
            n = 2 * REACH + 1
            out = pygame.Surface((n, n), pygame.SRCALPHA)
            for oy in range(n):
                for ox_ in range(n):
                    cnt, mid, anyc = 0, None, None
                    for dy in SUB:
                        for dx in SUB:
                            u, v = ox_ - REACH + dx, oy - REACH + dy
                            sx = int(math.floor(u * ca - v * sa + pivot[0] + 0.5))
                            sy = int(math.floor(u * sa + v * ca + pivot[1] + 0.5))
                            if 0 <= sx < pw and 0 <= sy < ph:
                                c = px[sy][sx]
                                if c is not None:
                                    cnt += 1
                                    anyc = c
                                    if dx == 0.0 and dy == 0.0:
                                        mid = c
                    if cnt >= 4:
                        out.set_at((ox_, oy), mid or anyc)
            cv.blit(out, (int(pos[0]) - REACH, int(pos[1]) - REACH))

        def compose(bob=0, dxl=0, dyl=0, dxr=0, dyr=0, sc_amp=0.0, sc_ph=0.0,
                    lean=0.0, tail_down=0.0, ab=0.0, af=0.0, sq=1.0):
            """Monta o pinguim por partes (pes, nadadeira de tras, corpo, cachecol, nadadeira da frente).
            lean = inclinacao do tronco p/ frente (px no topo); tail_down = cachecol 'caindo';
            ab / af = angulo das nadadeiras de tras / da frente (graus): 0 = penduradas,
            positivo = ponta p/ frente e p/ cima, negativo = ponta p/ tras e p/ cima (asa aberta);
            sq = esticar (>1) ou achatar (<1) verticalmente, ancorado no chao."""
            CW, CH, ox, oy = 44, 46, 4, 6
            b2 = body.copy()
            if sc_amp or tail_down:                     # cachecol ondulando
                b2.fill((0, 0, 0, 0), pygame.Rect(0, 11, 8, 13))
                for x in range(8):
                    fall = 1.0 - x / 10.0
                    dy = int(round(math.sin(sc_ph + x * 0.7) * sc_amp * fall
                                   + tail_down * (8 - x) / 8.0))
                    b2.blit(body, (x, 11 + dy), pygame.Rect(x, 11, 1, 13))
            if lean:                                    # tronco inclinado p/ frente
                b3 = pygame.Surface((sw, sh), pygame.SRCALPHA)
                for y in range(sh):
                    s = int(round(lean * max(0, 30 - y) / 30.0))
                    b3.blit(b2, (s, y), pygame.Rect(0, y, sw, 1))
                b2 = b3
            lx = int(round(lean * 8 / 30.0))            # ombros acompanham a inclinacao
            cv = pygame.Surface((CW, CH), pygame.SRCALPHA)
            cv.blit(foot_l, (ox + dxl, oy + dyl))
            cv.blit(foot_r, (ox + dxr, oy + dyr))
            put_arm(cv, arm_b_px, PIV_B, (ox + SH_B[0] + lx, oy + SH_B[1] + bob), ab)   # atras do corpo
            cv.blit(b2, (ox, oy + bob))
            put_arm(cv, arm_f_px, PIV_F, (ox + SH_F[0] + lx, oy + SH_F[1] + bob), af)   # na frente do corpo
            img = pygame.transform.scale(cv, (CW * 2, CH * 2))
            if abs(sq - 1.0) > 0.005:                   # squash & stretch ancorado no chao (y=84)
                nw, nh = int(CW * 2 * (2.0 - sq)), int(CH * 2 * sq)
                t = pygame.transform.scale(img, (nw, nh))
                out = pygame.Surface((CW * 2, CH * 2), pygame.SRCALPHA)
                out.blit(t, ((CW * 2 - nw) // 2, 84 - int(round(84 * sq))))
                img = out
            return img

        def both(img):
            return [img, pygame.transform.flip(img, True, False)]

        sin, cos, pi = math.sin, math.cos, math.pi
        self.pen = {}
        # parado: respira (sobe/desce) e os bracos balancam de leve
        idle_arm = ((-6, 8), (-9, 12), (-5, 9), (-2, 5))
        self.pen["idle"] = [both(compose(bob=b, sc_amp=1.0, sc_ph=i * 1.5, ab=a_[0], af=a_[1]))
                            for i, (b, a_) in enumerate(zip((0, 0, 1, 1), idle_arm))]

        # CAMINHADA (devagar): 8 quadros, passinhos curtos de pinguim - o corpo balanca de um
        # lado p/ o outro (waddle), os bracos abrem e fecham.
        walk = []
        N = 8
        for i in range(N):
            ph = i / float(N) * 2 * pi
            s_, c_ = sin(ph), cos(ph)
            walk.append(both(compose(
                bob=-int(round(abs(s_) * 2.0)) + 1,
                dxl=int(round(c_ * 4)), dyl=-int(round(max(0.0, -s_) * 3)),
                dxr=-int(round(c_ * 4)), dyr=-int(round(max(0.0, s_) * 3)),
                sc_amp=2.2, sc_ph=ph * 2, lean=1.0 + 1.8 * s_,
                ab=-14 - c_ * 24, af=14 + c_ * 26,
                sq=1.0 - 0.025 * cos(2 * ph))))
        self.pen["walk"] = walk

        # CORRIDA: 8 quadros. Os pes fazem uma "elipse" (apoio atras, volta no ar pela frente),
        # o corpo sobe/desce 2x por ciclo, o tronco se inclina p/ frente, o cachecol voa e os
        # bracos bombeiam em oposicao as pernas (bem abertos p/ tras no impulso).
        run = []
        N = 8
        for i in range(N):
            ph = i / float(N) * 2 * pi
            s_, c_ = sin(ph), cos(ph)
            run.append(both(compose(
                bob=-int(round(abs(s_) * 3.0)) + 1,
                dxl=int(round(c_ * 6)),
                dyl=-int(round(max(0.0, -s_) * 5)),
                dxr=-int(round(c_ * 6)),
                dyr=-int(round(max(0.0, s_) * 5)),
                sc_amp=3.6, sc_ph=ph * 2, lean=2.6 + 0.8 * s_,
                ab=-38 - c_ * 42, af=-26 + c_ * 52,
                sq=1.0 + 0.04 * abs(s_) - 0.02)))
        self.pen["run"] = run

        # PULO: bracos levantados batendo; QUEDA: bracos abertos "boiando" no ar
        jump_arm = ((-92, 100), (-70, 78), (-104, 112))
        self.pen["jump"] = [both(compose(bob=-1, dxl=1, dyl=-2, dxr=-1, dyr=-3,
                                         sc_amp=2.4, sc_ph=i * 1.3, lean=1.0,
                                         ab=a_[0], af=a_[1], sq=1.05))
                            for i, a_ in enumerate(jump_arm)]
        fall_arm = ((-58, 62), (-84, 90), (-46, 50))
        self.pen["fall"] = [both(compose(bob=0, dxl=-3, dyl=0, dxr=3, dyr=0,
                                         sc_amp=3.0, sc_ph=i * 1.1,
                                         ab=a_[0], af=a_[1], sq=0.97))
                            for i, a_ in enumerate(fall_arm)]

        def stretch(img, sx, sy, ang):
            """estica/achata o corpo (squash & stretch) e depois gira."""
            w0, h0 = img.get_size()
            im = pygame.transform.scale(img, (max(1, int(w0 * sx)), max(1, int(h0 * sy))))
            return pygame.transform.rotate(im, ang)

        # DASH = pinguim escorregando de barriga: deitado, cabeca pra frente, pes para tras e o
        # cachecol virando rastro. 0 = impacto (bem esticado, bracos colados pra tras);
        # 1..8 = deslize em ondas: a cabeca sobe e desce, o corpo estica e encolhe, os pes
        # chutam e os bracos remam em alternancia (bate-bate no gelo).
        dash = [both(stretch(compose(dyl=2, dyr=2, sc_amp=1.8, sc_ph=0.0, tail_down=6.0,
                                     ab=-4, af=2), 0.60, 1.42, -89))]
        for i in range(8):
            ph = i / 8.0 * 2 * pi
            s_, c_ = sin(ph), cos(ph)
            dash.append(both(stretch(compose(
                bob=int(round(s_ * 1.0)),
                dyl=2 + int(round(s_ * 2)), dyr=2 - int(round(s_ * 2)),
                dxl=int(round(c_ * 1.5)), dxr=-int(round(c_ * 1.5)),
                sc_amp=2.0 + 0.8 * c_, sc_ph=i * 1.7, tail_down=6.0 + 1.5 * s_,
                ab=-34 + s_ * 26, af=22 - s_ * 26),
                0.70 + 0.025 * s_, 1.25 - 0.045 * s_, -84 + 5 * c_)))
        self.pen["dash"] = dash
        self.pen["slide"] = dash[1]
        # lancamento (pulo durante o dash): o pinguim voa deitado, cabeca sobe e desce e os
        # bracos vao abrindo como asas
        launch = []
        for k, ang in enumerate((-62, -74, -86, -98, -110)):
            wing = (-24, -44, -62, -44, -28)[k]
            launch.append(both(stretch(compose(dyl=3, dyr=3, sc_amp=1.2, sc_ph=ang * 0.05,
                                               tail_down=7.0, ab=wing, af=-wing * 0.6),
                                       0.70, 1.26, ang)))
        self.pen["launch"] = launch
        # rastros: mesma pose, mas azulada/brilhante
        ghosts = []
        for pair in dash:
            g2 = []
            for im in pair:
                g = im.copy()
                g.fill((0, 80, 150, 0), special_flags=pygame.BLEND_RGB_ADD)
                g2.append(g)
            ghosts.append(g2)
        self.pen["dash_g"] = ghosts
        # recuperacao: o corpo levanta, os bracos balancam p/ cima p/ ajudar no equilibrio
        rec_specs = [(0.94, 1.10, -58, 1.5, -70, 78), (1.0, 1.04, -34, 1.5, -92, 100),
                     (1.08, 0.92, -12, 1.2, -50, 56)]
        self.pen["recover"] = [both(stretch(compose(sc_amp=a_, sc_ph=0.8, lean=1.0, ab=wb, af=wf),
                                            sx, sy, ang))
                               for sx, sy, ang, a_, wb, wf in rec_specs]
        self.title_pen = pygame.transform.scale(self.pen["idle"][0][0], (88 * 3, 92 * 3))
        self.life_icon = pygame.transform.scale(self.pen["idle"][0][0], (32, 34))
        # pinguim congelado (tela de game over): mesma imagem com tom azul gelo
        fr = self.pen["fall"][0][0].copy()
        fr.fill((40, 80, 130, 0), special_flags=pygame.BLEND_RGB_ADD)
        self.pen_frozen = pygame.transform.scale(fr, (fr.get_width() * 3 // 2, fr.get_height() * 3 // 2))

    # ---- chefe e drones
    def build_boss(self):
        sheet = load_img("boss")
        S = 5
        self.boss_S = S
        self.boss_pod, self.boss_plate, self.mini = [], [], []
        for f in range(4):
            pod = sheet.subsurface(pygame.Rect(f * 40, 10, 40, 30)).copy()
            plate = sheet.subsurface(pygame.Rect(f * 40, 0, 40, 6)).copy()
            self.boss_pod.append(pygame.transform.scale(pod, (40 * S, 30 * S)))
            self.boss_plate.append(pygame.transform.scale(plate, (40 * S, 6 * S)))
            self.mini.append(pygame.transform.scale(pod, (64, 48)))
        self.boss_rod = sheet.subsurface(pygame.Rect(20, 7, 3, 1)).copy()

    # ---- superficies procedurais (cache)
    def sprite(self, name, k=2):
        """Sprite de assets/<name>.raw ampliado k vezes (pixel art, sem suavizar)."""
        pre = {1: "t_", 2: "n_"}.get(self.theme)
        if pre and os.path.exists(os.path.join(ASSETS, pre + name + ".raw")):
            name = pre + name                       # versao do mundo (t_ = toxico, n_ = noturno), se existir
        key = ("sp", name, k)
        if key not in self.cache:
            img = load_img(name)
            self.cache[key] = pygame.transform.scale(
                img, (img.get_width() * k, img.get_height() * k))
        return self.cache[key]

    @staticmethod
    def _tile_x(dst, src, y, width, off):
        sw = src.get_width()
        x = -(off % sw)
        while x < width:
            dst.blit(src, (x, y))
            x += sw

    def ground_surface(self, w, h, seed, ice=False):
        """Chao: corpo de pedras + tampa de neve (ou gelo) + sombra e fundo escuro.
        A surface tem GROUND_MARGIN px extras de cada lado (pontas arredondadas da neve)."""
        tox = self.theme == 1
        key = ("g", w, h, seed, ice, tox, self.theme)
        if key in self.cache:
            return self.cache[key]
        M = GROUND_MARGIN
        s = pygame.Surface((w + 2 * M, h), pygame.SRCALPHA)
        body = self.sprite("solo_corpo")
        body_f = pygame.transform.flip(body, False, True)  # espelha p/ nao aparecer emenda
        off = (seed * 37) % body.get_width()
        body_y = 12

        # corpo (recortado na largura do chao)
        s.set_clip(pygame.Rect(M, 0, w, h))
        y, flip = body_y, False
        while y < h:
            tile = pygame.Surface((w + 2 * M, body.get_height()), pygame.SRCALPHA)
            self._tile_x(tile, body_f if flip else body, 0, w + 2 * M, off)
            s.blit(tile, (0, y))
            y += body.get_height()
            flip = not flip

        # escurece conforme desce (profundidade)
        fade_from = body_y + 90
        shade = pygame.Surface((w + 2 * M, h), pygame.SRCALPHA)
        for yy in range(fade_from, h):
            a = min(150, int((yy - fade_from) * 0.55))
            pygame.draw.line(shade, (10, 6, 12, a) if tox else (6, 8, 30, a), (0, yy), (w + 2 * M, yy))
        s.blit(shade, (0, 0))

        # sombra logo abaixo da neve + contorno escuro nas laterais
        for i, a in enumerate((90, 60, 36, 18)):
            pygame.draw.line(s, (10, 6, 12, a) if tox else (6, 8, 30, a), (M, 14 + i * 2), (M + w, 14 + i * 2), 2)
        edge = (22, 12, 20) if tox else (12, 16, 46)
        pygame.draw.rect(s, edge, (M, 14, 4, h))
        pygame.draw.rect(s, edge, (M + w - 4, 14, 4, h))
        s.set_clip(None)

        # tampa
        s.set_clip(pygame.Rect(M, 0, w, h))
        cap = self.sprite("solo_gelo" if ice else "solo_neve")
        self._tile_x(s, cap, 0, w + 2 * M, off + M)
        s.set_clip(None)
        if not ice:
            s.blit(self.sprite("solo_neve_ini"), (0, 0))
            s.blit(self.sprite("solo_neve_fim"), (M + w, 0))
        self.cache[key] = s
        return s

    def platform_surface(self, w):
        """Plataforma = ilha flutuante pronta (largura em tiles de 32 px na tela)."""
        n = min((2, 3, 4, 5, 6, 8), key=lambda v: abs(v * 32 - w))
        return self.sprite("ilha_%d" % n)

    def ice_surface(self):
        key = "ice_t" if self.theme == 1 else "ice"
        if key in self.cache:
            return self.cache[key]
        if self.theme == 1:          # bloco de cristal toxico (quebra com o dash)
            c_fill, c_edge, c_in, c_hi = (46, 170, 70, 235), (170, 255, 110, 255), (24, 110, 50, 255), (225, 255, 190)
        else:
            c_fill, c_edge, c_in, c_hi = (130, 195, 250, 235), (200, 238, 255, 255), (90, 150, 225, 255), (235, 250, 255)
        s = pygame.Surface((T, T), pygame.SRCALPHA)
        pygame.draw.rect(s, c_fill, (0, 0, T, T), border_radius=4)
        pygame.draw.rect(s, c_edge, (0, 0, T, T), 3, border_radius=4)
        pygame.draw.rect(s, c_in, (5, 5, T - 10, T - 10), 2)
        pygame.draw.line(s, c_hi, (10, 38), (30, 12), 4)
        pygame.draw.line(s, c_hi, (18, 40), (34, 22), 2)
        self.cache[key] = s
        return s


# ---------------------------------------------------------------- particulas
class Particles:
    def __init__(self):
        self.p = []

    def add(self, x, y, vx, vy, life, color, size, grav=0.0):
        self.p.append([x, y, vx, vy, life, life, color, size, grav])

    def burst(self, x, y, n, colors, speed=300, life=0.6, size=6, grav=900, up=0):
        for _ in range(n):
            a = random.uniform(0, math.tau)
            sp = random.uniform(0.2, 1.0) * speed
            self.add(x, y, math.cos(a) * sp, math.sin(a) * sp - up,
                     random.uniform(0.6, 1.0) * life, random.choice(colors),
                     random.randint(max(2, size - 3), size), grav)

    def update(self, dt):
        for q in self.p:
            q[4] -= dt
            q[3] += q[8] * dt
            q[0] += q[2] * dt
            q[1] += q[3] * dt
        self.p = [q for q in self.p if q[4] > 0]

    def draw(self, surf, cam, camy=0):
        for q in self.p:
            k = q[4] / q[5]
            sz = max(1, int(q[7] * (0.4 + 0.6 * k)))
            if sz >= 5:
                pygame.draw.circle(surf, q[6], (int(q[0] - cam + sz / 2), int(q[1] - camy + sz / 2)), sz // 2 + 1)
            else:
                pygame.draw.rect(surf, q[6], (int(q[0] - cam), int(q[1] - camy), sz, sz))


class Celebration:
    """Efeitos de comemoracao em coordenadas de TELA: chuva de confete e fogos de artificio."""

    def __init__(self, fireworks=True):
        self.t = 0.0
        self.conf = []
        self.rockets = []
        self.sparks = []
        self.acc = 0.0
        self.fw = fireworks
        self.next_fw = 0.5

    def burst_conf(self, x, y, n, colors=None):
        colors = colors or CONF_COLORS
        for _ in range(n):
            a = random.uniform(-math.pi * 0.95, -math.pi * 0.05)
            sp = random.uniform(250, 760)
            self.conf.append([x, y, math.cos(a) * sp, math.sin(a) * sp, random.uniform(0, 6.28),
                              random.uniform(-9, 9), random.choice(colors),
                              random.randint(9, 15), random.randint(6, 9), random.uniform(0, 6.28),
                              random.uniform(120, 230)])

    def sparkle(self, x, y, n=16, colors=((255, 240, 130), (255, 255, 255), (255, 200, 60))):
        for _ in range(n):
            a = random.uniform(0, math.tau)
            sp = random.uniform(80, 340)
            life = random.uniform(0.4, 0.9)
            self.sparks.append([x, y, math.cos(a) * sp, math.sin(a) * sp, life, life,
                                random.choice(colors), random.randint(4, 7), 0.0])

    def explode(self, x, y, color):
        n = random.randint(34, 48)
        c2 = random.choice(CONF_COLORS)
        for i in range(n):
            a = i / n * math.tau + random.uniform(-0.05, 0.05)
            sp = random.choice((230, 300, 360)) * random.uniform(0.85, 1.1)
            life = random.uniform(1.0, 1.5)
            self.sparks.append([x, y, math.cos(a) * sp, math.sin(a) * sp, life, life,
                                color if i % 3 else c2, random.randint(5, 8), 260.0])
        for _ in range(10):                                  # miolo branco
            a = random.uniform(0, math.tau)
            sp = random.uniform(40, 140)
            life = random.uniform(0.5, 0.9)
            self.sparks.append([x, y, math.cos(a) * sp, math.sin(a) * sp, life, life,
                                (255, 255, 255), 6, 200.0])

    def update(self, dt, rain=True):
        self.t += dt
        if rain:
            self.acc += dt * 70
            while self.acc >= 1.0:
                self.acc -= 1.0
                fall = random.uniform(120, 230)
                self.conf.append([random.uniform(-20, W + 20), -20, random.uniform(-30, 30), fall,
                                  random.uniform(0, 6.28), random.uniform(-6, 6),
                                  random.choice(CONF_COLORS), random.randint(9, 15),
                                  random.randint(6, 9), random.uniform(0, 6.28), fall])
        for c in self.conf:
            c[3] += 700 * dt
            if c[3] > c[10]:
                c[3] = approach(c[3], c[10], 1500 * dt)
            c[2] *= math.exp(-1.6 * dt)
            c[9] += dt * 7
            c[4] += c[5] * dt
            c[0] += (c[2] + math.sin(c[9] * 0.7) * 45) * dt
            c[1] += c[3] * dt
        self.conf = [c for c in self.conf if c[1] < H + 30]
        if self.fw:
            self.next_fw -= dt
            if self.next_fw <= 0:
                self.next_fw = random.uniform(0.5, 0.95)
                self.rockets.append([random.uniform(180, W - 180), H + 10, random.uniform(-700, -560),
                                     random.uniform(110, 300), random.choice(CONF_COLORS)])
        for r in self.rockets:
            r[1] += r[2] * dt
            r[2] *= math.exp(-0.9 * dt)
            if random.random() < 0.8:
                self.sparks.append([r[0] + random.uniform(-2, 2), r[1], random.uniform(-14, 14),
                                    random.uniform(10, 50), 0.35, 0.35, (255, 225, 160), 4, 0.0])
            if r[1] <= r[3] or r[2] > -90:
                self.explode(r[0], r[1], r[4])
                r[1] = -999
        self.rockets = [r for r in self.rockets if r[1] > -900]
        for s in self.sparks:
            s[4] -= dt
            s[3] += s[8] * dt
            s[2] *= math.exp(-0.9 * dt)
            s[0] += s[2] * dt
            s[1] += s[3] * dt
        self.sparks = [s for s in self.sparks if s[4] > 0]

    def draw(self, surf):
        for s in self.sparks:
            k = s[4] / s[5]
            sz = max(2, int(s[7] * (0.35 + 0.65 * k)))
            col = s[6] if k > 0.35 else tuple(int(v * (0.45 + k)) for v in s[6])
            pygame.draw.rect(surf, col, (int(s[0]), int(s[1]), sz, sz))
        for r in self.rockets:
            pygame.draw.rect(surf, (255, 245, 210), (int(r[0]) - 2, int(r[1]) - 2, 5, 9))
        for c in self.conf:
            x, y, _, _, rot, _, col, w, h, ph, _ = c
            f = math.cos(ph)
            hw, hh = w / 2.0, h / 2.0 * f
            ca, sa = math.cos(rot), math.sin(rot)
            pts = [(x + px * ca - py * sa, y + px * sa + py * ca)
                   for px, py in ((-hw, -hh), (hw, -hh), (hw, hh), (-hw, hh))]
            pygame.draw.polygon(surf, col if f > 0 else tuple(int(v * 0.68) for v in col), pts)


# ---------------------------------------------------------------- fase
class Level:
    def __init__(self, stage=0, toxic=False, night=False):
        self.stage = stage
        self.toxic = toxic                  # True = Mundo 2 (zona radioativa)
        self.night = night                  # True = Mundo 3 (geleiras noturnas)
        self.off = PART_START_COLS[stage]
        self.act = False
        self.goal = None
        self.goal_door = None
        self.solids = []
        self.grounds = []
        self.oneways = []
        self.ice = []
        self.spikes = []
        self.icicles = []
        self.springs = []
        self.decor = []
        self.width = STAGE_COLS[stage] * T
        self.build()
        self.rebuild()
        self.build_decor()

    # --- construtores
    def sec(self, k):
        self.act = (k == self.stage)

    def ground(self, c0, c1, h):
        if not self.act:
            return
        c0 -= self.off
        c1 -= self.off
        r = pygame.Rect(int(c0 * T), int(H - h * T), int((c1 - c0) * T), int(h * T + 400))
        self.solids.append(r)
        self.grounds.append(r)

    def plat(self, c0, h, w):
        if not self.act:
            return
        c0 -= self.off
        self.oneways.append(pygame.Rect(int(c0 * T), int(H - h * T), int(w * T), 20))

    def ice_wall(self, c, h_base, n):
        if not self.act:
            return
        c -= self.off
        for i in range(n):
            r = pygame.Rect(int(c * T), int(H - (h_base + i + 1) * T), T, T)
            self.ice.append({"rect": r, "alive": True})

    def spike(self, c0, n, h):
        if not self.act:
            return
        c0 -= self.off
        self.spikes.append(pygame.Rect(int(c0 * T + 6), int(H - h * T - 34), int(n * T - 12), 34))

    def spring(self, c, h):
        """Trampolim de gelo em cima do chao de altura h (em tiles)."""
        if not self.act:
            return
        c -= self.off
        self.springs.append({"rect": pygame.Rect(int(c * T), int(H - h * T - 20), T, 20), "t": 0.0})

    def icicle(self, c):
        if not self.act:
            return
        c -= self.off
        self.icicles.append({"x": c * T + T // 2, "top": 0.0, "state": "idle",
                             "t": 0.0, "vy": 0.0, "alive": True})

    def rebuild(self):
        self.solid_all = self.solids + [i["rect"] for i in self.ice if i["alive"]]

    # --- desenho da fase  (colunas locais de cada fase; 1 tile = 48 px)
    # Alcances (para quem for editar): pulo normal ~7 tiles de comprimento e 3 de altura;
    # pulo durante o dash (lancamento) ~12 tiles; trampolim sobe ~7 tiles.
    def build(self):
        self.sec(self.stage)
        self.solids.append(pygame.Rect(-80, -400, 80, H + 1200))          # parede da esquerda
        self.solids.append(pygame.Rect(self.width, -400, 80, H + 1200))   # parede da direita

        # ===== FASE 1: PRIMEIROS PASSOS  (pulo, deslize e o primeiro lancamento) =====
        self.sec(0)
        self.ground(0, 22, 3)
        self.spike(14, 2, 3)
        self.ground(27, 46, 3)              # buraco de 5: pulo normal
        self.ice_wall(37, 3, 4)             # parede alta de gelo: DASH (J) para quebrar
        self.ground(46, 62, 4)
        self.spike(53, 3, 4)
        self.ground(66, 84, 5)              # sobe um degrau
        self.icicle(72)
        self.icicle(75)
        self.ground(84, 98, 4)
        # buraco de 9 tiles: J (dash) e depois PULO = lancamento
        self.ground(107, 128, 4)
        self.ice_wall(118, 4, 4)
        self.spike(124, 2, 4)
        self.ground(133, 152, 4)            # chao final, com o iglu de chegada
        self.spike(138, 2, 4)

        # ===== FASE 2: GRUTA DE GELO  (estalactites, trampolim e torre; termina no CRIO-DRONE) =====
        self.sec(1)
        self.ground(0, 16, 4)
        self.ground(20, 40, 4)
        for c in (26, 29, 32, 35):
            self.icicle(c)
        self.ground(40, 58, 3)
        self.ice_wall(44, 3, 4)
        self.spike(52, 2, 3)
        self.ground(62, 79, 3)
        self.spike(67, 2, 3)
        self.spring(72, 3)                  # trampolim: sobe ate a torre
        self.ground(79, 91, 8)              # torre alta
        self.ground(91, 106, 5)
        self.ice_wall(94, 5, 4)
        self.spike(101, 2, 5)
        self.ground(110, 128, 4)
        for c in (114, 117, 120, 123):
            self.icicle(c)
        # buraco de 9: lancamento
        self.ground(137, 150, 4)
        self.spike(145, 2, 4)
        self.ground(150, 182, 3)            # arena do CRIO-DRONE

        # ===== FASE 3: ABISMOS  (plataformas, trampolim e dois buracos grandes) =====
        self.sec(2)
        self.ground(0, 10, 5)
        self.plat(12.5, 6, 4)
        self.plat(19, 7, 4)
        self.ground(24, 38, 5)
        self.spike(33, 2, 5)
        self.ground(41, 53, 4)
        self.spike(46, 2, 4)
        # buraco de 9: lancamento
        self.ground(62, 79, 4)
        for c in (67, 70):
            self.icicle(c)
        self.ice_wall(73, 4, 4)
        self.ground(83, 91, 6)
        self.plat(93, 8, 4)
        self.plat(99.5, 9, 4)
        self.ground(106, 119, 5)
        self.spike(113, 2, 5)
        self.spring(117, 5)                 # ajuda no buraco de 7
        self.ground(126, 166, 4)            # chao final, com o iglu de chegada
        for c in (131, 134):
            self.icicle(c)
        self.ice_wall(139, 4, 4)
        self.spike(144, 2, 4)

        # ===== FASE 4: CORRIDA FINAL  (tudo junto; termina no CRIO-GOLEM) =====
        self.sec(3)
        self.ground(0, 14, 4)
        self.spike(8, 2, 4)
        self.ground(18, 44, 4)
        self.ice_wall(24, 4, 4)
        for c in (31, 34):
            self.icicle(c)
        # buraco de 9: lancamento
        self.ground(53, 67, 4)
        self.spring(60, 4)                  # trampolim: sobe ate a torre
        self.ground(67, 79, 9)              # torre mais alta
        self.spike(72, 2, 9)
        self.ground(79, 90, 6)
        self.ground(90, 102, 3)
        for c in (93, 96, 99):
            self.icicle(c)
        self.plat(104.5, 5, 4)
        self.plat(111, 6, 4)
        self.ground(117, 160, 4)
        self.ice_wall(124, 4, 4)
        self.spike(130, 3, 4)
        self.ice_wall(138, 4, 4)
        for c in (143, 146, 149):
            self.icicle(c)
        self.spike(153, 2, 4)
        # buraco de 9: lancamento
        self.ground(169, 174, 4)
        self.ground(174, 211, 3)            # arena do CRIO-GOLEM
        # iglu de chegada (fases 1 e 3)
        goals = STAGE_GOAL_N if self.night else STAGE_GOAL
        if self.stage in goals:
            gx = int(goals[self.stage] * T)
            top = H - (3 if self.stage == 1 else 4) * T      # o chao da fase 2 e uma tile mais baixo
            self.goal = pygame.Rect(gx, top - GOAL_H, GOAL_W, GOAL_H)
            self.goal_door = pygame.Rect(self.goal.centerx - 44, self.goal.bottom - 96, 88, 96)

    # --- decoracao (pinheiros, pedras, cercas) sorteada com semente fixa por fase
    DECOR = {"pinheiro_p": (3, 18, 34), "pinheiro_m": (3, 24, 42), "pinheiro_g": (3, 30, 50),
             "pedra_1": (3, 22, 15), "pedra_2": (3, 30, 20),
             # Mundo 2: arvores mortas e barris radioativos
             "arv_p": (3, 18, 34), "arv_m": (3, 24, 42), "arv_g": (3, 30, 50), "barril": (3, 16, 18),
             # Mundo 3: torre de andaime enferrujado e poste com luz vermelha
             "andaime": (3, 24, 41), "farol": (3, 8, 24)}

    def build_decor(self):
        rng = random.Random(1234 + self.stage * 71)
        arena = STAGE_ARENA_COL.get(self.stage)
        arena_x = arena * T - 120 if arena is not None else 10 ** 9
        keep_out = [r.inflate(110, 400) for r in self.spikes]
        keep_out += [i["rect"].inflate(120, 400) for i in self.ice]
        keep_out += [sp["rect"].inflate(130, 400) for sp in self.springs]
        if self.goal is not None:
            keep_out.append(self.goal.inflate(420, 400))
        names = ["pinheiro_p", "pinheiro_m", "pinheiro_g", "pinheiro_m", "pedra_1", "pedra_2"]
        if self.toxic:
            names = ["arv_p", "arv_m", "arv_g", "arv_m", "barril", "pedra_1", "barril", "arv_g"]
        elif self.night:
            names = ["pinheiro_p", "pinheiro_m", "pinheiro_g", "farol", "pedra_1", "andaime", "pinheiro_m", "farol"]
        for g in self.grounds:
            if g.width < 4 * T or g.left > arena_x:
                continue
            x = g.left + rng.randint(50, 130)
            while x < g.right - 130 and x < arena_x:
                nm = rng.choice(names)
                k, sw, sh = self.DECOR[nm]
                box = pygame.Rect(x, g.top - sh * k, sw * k, sh * k)
                if box.collidelist(keep_out) == -1:
                    self.decor.append((nm, k, x, g.top + 8 - sh * k))
                x += sw * k + rng.randint(150, 380)
            # cerca de aviso na borda antes de um buraco
            nxt = [o for o in self.grounds if o.left > g.right - 2 and o.left - g.right > 0]
            if nxt and g.right < arena_x and g.width >= 5 * T:
                near = pygame.Rect(g.right - 160, g.top - 200, 160, 220)
                if near.collidelist(keep_out) == -1 and near.collidelist(self.spikes) == -1:
                    for i in range(2):
                        self.decor.append(("cerca", 3, g.right - 56 - i * 46, g.top + 6 - 18 * 3))

    # --- logica
    def update(self, dt, game):
        pl = game.player
        for sp in self.springs:
            sp["t"] = max(0.0, sp["t"] - dt)
        for ic in self.icicles:
            if not ic["alive"]:
                continue
            if ic["state"] == "idle":
                if not pl.dead and ic["x"] - 150 < pl.x + pl.w / 2 < ic["x"] + 40:
                    ic["state"] = "shake"
                    ic["t"] = 0.45
            elif ic["state"] == "shake":
                ic["t"] -= dt
                if ic["t"] <= 0:
                    ic["state"] = "fall"
                    ic["vy"] = 0.0
            elif ic["state"] == "fall":
                ic["vy"] += 2200 * dt
                ic["top"] += ic["vy"] * dt
                tip = pygame.Rect(int(ic["x"] - 9), int(ic["top"] + 30), 18, 40)
                if (tip.collidelist(self.solid_all) != -1 or
                        tip.collidelist(self.oneways) != -1 or ic["top"] > H + 100):
                    ic["alive"] = False
                    game.particles.burst(ic["x"], tip.bottom, 8,
                                         [(220, 240, 255), (150, 200, 250)], 260, 0.5, 5)

    def icicle_rect(self, ic):
        return pygame.Rect(int(ic["x"] - 9), int(ic["top"] + 24), 18, 46)


# ---------------------------------------------------------------- jogador
class Player:
    W_STAND, H_STAND = 40, 62
    W_SLIDE, H_SLIDE = 62, 30

    def __init__(self, x_center, y_bottom):
        self.w, self.h = self.W_STAND, self.H_STAND
        self.x = float(x_center - self.w / 2)
        self.y = float(y_bottom - self.h)
        self.vx = 0.0
        self.vy = 0.0
        self.facing = 1
        self.on_ground = False
        self.coyote = 0.0
        self.jump_buf = 0.0
        self.dash_buf = 0.0
        self.dash_t = 0.0
        self.dash_cd = 0.0
        self.dash_dir = 1
        self.air_dash = True
        self.wall = 0
        self.wall_lock = 0.0
        self.wall_sliding = False
        self.inv = 0.0
        self.hp = 4
        self.max_hp = 4
        self.anim = 0.0
        self.dead = False
        self.ghost_t = 0.0
        self.ghosts = []
        self.rings = []        # ondas de choque do dash
        self.streaks = []      # linhas de velocidade
        self.recover = 0.0
        self.ready_fx = 0.0
        self.launch = False     # voando deitado depois do pulo durante o dash
        self.spring_t = 0.0     # >0 logo depois de um trampolim (nao corta o pulo)
        self.launch_t = 0.0
        self.wake = []          # riscos no gelo deixados pelo deslize
        self.last_step = 0

    @property
    def rect(self):
        return pygame.Rect(int(round(self.x)), int(round(self.y)), self.w, self.h)

    @property
    def cx(self):
        return self.x + self.w / 2.0

    @property
    def attacking(self):
        """True enquanto escorrega ou voa deitado (machuca chefes, quebra gelo, invulneravel)."""
        return self.dash_t > 0 or self.launch

    def set_size(self, w, h):
        cx = self.x + self.w / 2.0
        bottom = round(self.y + self.h)
        self.w, self.h = w, h
        self.x = cx - w / 2.0
        self.y = float(bottom - h)

    # ---- dash (so no chao) e lancamento
    def start_dash(self, game, d):
        self.dash_dir = d if d != 0 else self.facing
        self.facing = self.dash_dir
        self.dash_t = DASH_TIME
        self.dash_cd = 0.0          # a recarga so comeca quando o dash termina
        self.dash_buf = 0.0
        self.recover = 0.0
        self.ghost_t = 0.0
        self.launch = False
        self.rings.append([self.cx - self.dash_dir * 10, self.y + self.h * 0.5, 0.26])
        self.set_size(self.W_SLIDE, self.H_SLIDE)
        game.shake(3)
        for _ in range(10):
            game.particles.add(self.cx - self.dash_dir * 20, self.y + self.h - 4,
                               -self.dash_dir * random.uniform(60, 260), random.uniform(-200, -20),
                               0.4, (235, 245, 255), 6, 500)

    def end_dash(self, d, recover=True):
        self.dash_t = 0.0
        self.launch = False
        self.dash_cd = DASH_COOLDOWN
        self.recover = DASH_RECOVER if recover else 0.0
        self.set_size(self.W_STAND, self.H_STAND)
        self.vx = self.dash_dir * (RUN_SPEED * 1.15 if d == self.dash_dir else 260.0)

    def launch_jump(self, game):
        """Pulo durante o dash: o pinguim e ATIRADO para frente, voando deitado."""
        dr = self.dash_dir
        self.dash_t = 0.0
        self.dash_cd = DASH_COOLDOWN
        self.launch = True
        self.launch_t = 0.0
        self.facing = dr
        self.vy = -JUMP_V * LAUNCH_VY
        self.vx = dr * DASH_SPEED * LAUNCH_VX
        self.on_ground = False
        self.coyote = 0.0
        self.jump_buf = 0.0
        self.ghost_t = 0.0
        self.rings.append([self.cx - dr * 6, self.y + self.h * 0.5, 0.26])
        game.shake(5)
        for _ in range(14):
            game.particles.add(self.cx - dr * 14, self.y + self.h - 2,
                               -dr * random.uniform(80, 340), random.uniform(-380, -60),
                               0.5, (235, 245, 255), 6, 700)

    def end_launch(self, game):
        """Aterrissagem do lancamento: levanta com a velocidade que sobrou."""
        self.launch = False
        self.set_size(self.W_STAND, self.H_STAND)
        self.recover = DASH_RECOVER
        self.vx = self.dash_dir * RUN_SPEED * 1.2
        game.shake(4)
        for _ in range(12):
            game.particles.add(self.cx + self.dash_dir * 10, self.y + self.h - 4,
                               self.dash_dir * random.uniform(40, 300), random.uniform(-260, -50),
                               0.45, (235, 245, 255), 6, 700)

    # ---- hit
    def hurt(self, game, src_x, force=False):
        if self.dead or self.inv > 0:
            return False
        if self.attacking and not force:
            return False
        self.hp -= 1
        self.inv = 1.6
        self.vy = -420.0
        self.vx = (sign(self.cx - src_x) or -self.facing) * 340.0
        if self.attacking:
            self.end_dash(0, False)
        game.shake(10)
        game.particles.burst(self.cx, self.y + 20, 10, [(255, 255, 255), (255, 120, 140)], 320, 0.5, 6)
        if self.hp <= 0:
            game.kill_player()
        return True

    # ---- atualizacao
    def update(self, dt, inp, level, game):
        self.inv = max(0.0, self.inv - dt)
        was_cd = self.dash_cd > 0
        self.dash_cd = max(0.0, self.dash_cd - dt)
        self.recover = max(0.0, self.recover - dt)
        self.ready_fx = max(0.0, self.ready_fx - dt)
        if was_cd and self.dash_cd <= 0 and not self.dead:      # dash recarregado
            self.ready_fx = 0.25
            game.particles.burst(self.cx, self.y + 14, 8, [(255, 255, 255), (150, 225, 255)],
                                 170, 0.4, 4, -200, 0)
        self.coyote = max(0.0, self.coyote - dt)
        self.jump_buf = max(0.0, self.jump_buf - dt)
        self.dash_buf = max(0.0, self.dash_buf - dt)
        self.spring_t = max(0.0, self.spring_t - dt)
        self.wall_lock = max(0.0, self.wall_lock - dt)
        d = inp["dir"]
        if inp["jump_down"]:
            self.jump_buf = JUMP_BUFFER
        if inp["dash_down"]:
            self.dash_buf = 0.12
        if d != 0 and self.dash_t <= 0 and self.wall_lock <= 0:
            self.facing = d

        if self.on_ground:
            self.coyote = COYOTE
            self.air_dash = True

        # dash
        if (self.dash_buf > 0 and self.dash_cd <= 0 and self.dash_t <= 0 and not self.launch
                and self.on_ground and self.wall_lock <= 0):      # dash SO no chao
            self.start_dash(game, d)

        # pulo
        self.wall_sliding = (not self.on_ground and self.wall != 0 and self.vy > 0
                             and d == self.wall and self.dash_t <= 0 and not self.launch)
        if self.jump_buf > 0:
            if self.dash_t > 0 and self.on_ground:     # pulo durante o dash = LANCAMENTO pra frente
                self.launch_jump(game)
            elif self.coyote > 0:
                self.vy = -JUMP_V
                self.coyote = 0.0
                self.jump_buf = 0.0
                self.on_ground = False
                game.particles.burst(self.cx, self.y + self.h, 6, [(235, 245, 255)], 160, 0.35, 5, 300, 0)
            elif self.wall_sliding or (self.wall != 0 and not self.on_ground):
                self.vy = -JUMP_V * 0.95
                self.vx = -self.wall * RUN_SPEED * 1.1
                self.facing = -self.wall
                self.wall_lock = 0.16
                self.jump_buf = 0.0
                self.air_dash = True
                if self.attacking:
                    self.end_dash(0)
                    self.vx = -self.wall * RUN_SPEED * 1.1
                game.particles.burst(self.cx + self.wall * 18, self.y + 30, 6, [(235, 245, 255)], 160, 0.35, 5, 300, 0)
        if not inp["jump_held"] and self.vy < -300 and self.dash_t <= 0 and not self.launch and self.spring_t <= 0:
            self.vy = -300.0

        # movimento horizontal / vertical
        if self.dash_t > 0:
            self.dash_t -= dt
            self.vx = self.dash_dir * DASH_SPEED
            self.vy = 0.0
            self.ghost_t -= dt
            if self.ghost_t <= 0:
                self.ghost_t = 0.03
                self.ghosts.append([self.rect.copy(), self.dash_dir, 0.24, self.dash_frame()])
            for _ in range(2):                       # linhas de velocidade
                self.streaks.append([self.cx - self.dash_dir * random.uniform(10, 50),
                                     self.y + random.uniform(-4, self.h + 4),
                                     random.uniform(50, 130), 0.2])
            self.wake.append([self.cx - self.dash_dir * 22, self.y + self.h - 2, 0.38])
            for _ in range(2):                       # spray de neve sob a barriga
                game.particles.add(self.cx - self.dash_dir * random.uniform(14, 30),
                                   self.y + self.h - 4,
                                   -self.dash_dir * random.uniform(60, 240), random.uniform(-260, -80),
                                   0.4, (235, 245, 255), random.choice((4, 6)), 700)
            if self.dash_t <= 0 and not self.can_stand(level):
                self.dash_t = 0.04                   # tunel baixo: continua deslizando ate caber em pe
            if self.dash_t <= 0:
                self.end_dash(d)
                if self.on_ground:                   # derrapagem ao parar
                    for _ in range(10):
                        game.particles.add(self.cx + self.dash_dir * 10, self.y + self.h - 4,
                                           self.dash_dir * random.uniform(40, 240),
                                           random.uniform(-240, -50), 0.45,
                                           (235, 245, 255), 6, 700)
        elif self.launch:
            # voando deitado: quase nao perde velocidade; segurar o lado contrario freia
            self.launch_t += dt
            if d != 0 and d != self.dash_dir:
                self.vx = approach(self.vx, d * RUN_SPEED, AIR_ACC * dt)
            else:
                self.vx = approach(self.vx, self.dash_dir * RUN_SPEED, 240.0 * dt)
            self.vy = min(self.vy + GRAV * dt, MAX_FALL)
            self.ghost_t -= dt
            if self.ghost_t <= 0:
                self.ghost_t = 0.04
                self.ghosts.append([self.rect.copy(), self.dash_dir, 0.2, 2])
            if random.random() < 0.8:
                game.particles.add(self.cx - self.dash_dir * 26, self.y + self.h * 0.6,
                                   -self.dash_dir * random.uniform(20, 90), random.uniform(-60, 40),
                                   0.35, (225, 242, 255), 5, 0)
        else:
            if self.wall_lock <= 0:
                target = d * RUN_SPEED
                if d == 0 and self.on_ground:
                    self.vx = approach(self.vx, 0.0, GROUND_FRIC * dt)
                else:
                    acc = GROUND_ACC if self.on_ground else AIR_ACC
                    if abs(self.vx) > RUN_SPEED and sign(self.vx) == d:
                        acc = 900.0
                    self.vx = approach(self.vx, target, acc * dt)
            self.vy = min(self.vy + GRAV * dt, MAX_FALL)
            if self.wall_sliding:
                self.vy = min(self.vy, 150.0)
                self.air_dash = True

        # quebra de gelo no dash / lancamento
        if self.attacking:
            probe = self.rect.inflate(abs(self.vx) * dt + 10, -6)
            for ice in level.ice:
                if ice["alive"] and probe.colliderect(ice["rect"]):
                    game.break_ice(ice)

        self.move_x(dt, level)
        was_vy = self.vy
        landed = self.move_y(dt, level)
        if landed and was_vy > 520:
            game.particles.burst(self.cx, self.y + self.h, 7, [(235, 245, 255)], 200, 0.4, 5, 400, 0)

        self.on_ground = landed or self.probe_ground(level)
        if self.dash_t > 0 and not self.on_ground:      # escorregou pra fora da borda: cai
            keep = self.dash_dir * DASH_SPEED * 0.75
            self.end_dash(d, False)
            self.vx = keep
        elif self.launch and self.on_ground and self.vy >= 0 and self.launch_t > 0.06:
            self.end_launch(game)
        elif self.launch and self.vx == 0.0:            # bateu na parede voando: larga o pose deitado
            self.launch = False
            self.set_size(self.W_STAND, self.H_STAND)
        self.wall = 0
        if not self.on_ground:
            r2 = self.rect.inflate(0, -10)
            if r2.move(-3, 0).collidelist(level.solid_all) != -1:
                self.wall = -1
            elif r2.move(3, 0).collidelist(level.solid_all) != -1:
                self.wall = 1

        # animacao / rastros
        self.anim += dt * (9.0 + abs(self.vx) / RUN_SPEED * 11.0)
        step = int(self.anim) % 8
        if (self.on_ground and self.dash_t <= 0 and abs(self.vx) > 260
                and step != self.last_step and step in (0, 4)):     # poeirinha a cada passada
            game.particles.add(self.cx - sign(self.vx) * 14, self.y + self.h - 3,
                               -sign(self.vx) * random.uniform(20, 80), random.uniform(-120, -40),
                               0.3, (235, 245, 255), 4, 500)
        self.last_step = step
        for w in self.wake:
            w[2] -= dt
        self.wake = [w for w in self.wake if w[2] > 0]
        for lst in (self.ghosts, self.rings, self.streaks):
            for g in lst:
                g[2] -= dt
        self.ghosts = [g for g in self.ghosts if g[2] > 0]
        self.rings = [g for g in self.rings if g[2] > 0]
        self.streaks = [g for g in self.streaks if g[2] > 0]

    def can_stand(self, level):
        """True se o pinguim em pe (sem agachar) cabe aqui sem entrar em blocos."""
        bottom = int(round(self.y + self.h))
        cx = int(round(self.x + self.w / 2.0))
        r = pygame.Rect(cx - self.W_STAND // 2, bottom - self.H_STAND, self.W_STAND, self.H_STAND - 2)
        return r.collidelist(level.solid_all) == -1

    def move_x(self, dt, level):
        self.x += self.vx * dt
        r = self.rect.inflate(0, -4)
        for i in r.collidelistall(level.solid_all):
            s = level.solid_all[i]
            if self.vx > 0:
                self.x = float(s.left - self.w)
            elif self.vx < 0:
                self.x = float(s.right)
            else:
                continue
            self.vx = 0.0
            r = self.rect.inflate(0, -4)

    def move_y(self, dt, level):
        prev_bottom = self.y + self.h
        self.y += self.vy * dt
        landed = False
        r = self.rect
        for i in r.collidelistall(level.solid_all):
            s = level.solid_all[i]
            if self.vy > 0:
                self.y = float(s.top - self.h)
                self.vy = 0.0
                landed = True
            elif self.vy < 0:
                self.y = float(s.bottom)
                self.vy = 0.0
            r = self.rect
        if self.vy >= 0:
            for s in level.oneways:
                if r.colliderect(s) and prev_bottom <= s.top + 1:
                    self.y = float(s.top - self.h)
                    self.vy = 0.0
                    landed = True
                    r = self.rect
        return landed

    def probe_ground(self, level):
        r = self.rect
        pr = r.move(0, 2)
        if pr.collidelist(level.solid_all) != -1:
            return True
        if self.vy >= 0:
            for s in level.oneways:
                if pr.colliderect(s) and r.bottom <= s.top + 2:
                    return True
        return False

    # ---- desenho
    def sprite(self, assets, t):
        fi = 0 if self.facing >= 0 else 1
        if self.dash_t > 0:
            return assets.pen["dash"][self.dash_frame()][0 if self.dash_dir >= 0 else 1], True
        if self.launch:
            k = 0 if self.vy < -420 else 1 if self.vy < -140 else 2 if self.vy < 140 else 3 if self.vy < 420 else 4
            return assets.pen["launch"][k][0 if self.dash_dir >= 0 else 1], True
        if self.recover > 0 and self.vy >= 0:
            k = min(2, int((1.0 - self.recover / DASH_RECOVER) * 3))
            return assets.pen["recover"][k][0 if self.dash_dir >= 0 else 1], "recover"
        if not self.on_ground:
            if self.wall_sliding:
                return assets.pen["fall"][0][fi], False
            if self.vy < 0:
                return assets.pen["jump"][int(self.anim * 0.5) % 3][fi], False
            return assets.pen["fall"][int(self.anim * 0.5) % 3][fi], False
        if abs(self.vx) > 270:                       # corrida: bracos bombeando, tronco inclinado
            return assets.pen["run"][int(self.anim) % 8][fi], False
        if abs(self.vx) > 40:                        # caminhada: passinhos balancando de lado
            return assets.pen["walk"][int(self.anim) % 8][fi], False
        return assets.pen["idle"][int(t * 3.0) % 4][fi], False

    def dash_frame(self):
        el = DASH_TIME - self.dash_t
        return 0 if el < 0.045 else 1 + int((el - 0.045) * 38) % 8

    def blit_pos(self, img, rect, slide):
        if slide == "recover":
            return rect.centerx - img.get_width() // 2, rect.bottom + 12 - img.get_height()
        if slide:
            return rect.centerx - img.get_width() // 2, rect.bottom - img.get_height() + 6
        return rect.centerx - img.get_width() // 2, rect.bottom - 80

    def draw(self, surf, cam, camy, assets, t):
        for x, y, life in self.wake:                  # riscos do deslize no gelo/neve
            L = int(34 * life / 0.38)
            sx, sy = int(x - cam), int(y - camy)
            pygame.draw.line(surf, (150, 205, 240), (sx - L // 2, sy), (sx + L // 2, sy), 3)
            pygame.draw.line(surf, (235, 248, 255), (sx - L // 3, sy - 2), (sx + L // 3, sy - 2), 1)
        for x, y, ln, life in self.streaks:           # linhas de velocidade
            L = ln * life / 0.2
            sx = x - cam
            sd = -self.dash_dir
            pygame.draw.line(surf, (225, 242, 255), (sx, y - camy), (sx + sd * L, y - camy), 2)
        for x, y, life in self.rings:                 # onda de choque do inicio
            t = 1.0 - life / 0.26
            rw, rh = int(18 + 46 * t), int(40 + 36 * t)
            tmp = pygame.Surface((rw * 2 + 6, rh * 2 + 6), pygame.SRCALPHA)
            pygame.draw.ellipse(tmp, (235, 248, 255, int(210 * (1 - t))), tmp.get_rect(),
                                max(1, int(6 * (1 - t))))
            surf.blit(tmp, (x - tmp.get_width() // 2 - cam, y - tmp.get_height() // 2 - camy))
        for rc, dr, life, fr in self.ghosts:          # rastros azulados
            img = assets.pen["dash_g"][fr][0 if dr >= 0 else 1]
            img.set_alpha(int(170 * life / 0.24))
            x, y = self.blit_pos(img, rc, True)
            surf.blit(img, (x - cam, y - camy))
        if self.dead:
            return
        if self.inv > 0 and int(self.inv * 18) % 2 == 0:
            return
        img, slide = self.sprite(assets, t)
        x, y = self.blit_pos(img, self.rect, slide)
        surf.blit(img, (x - cam, y - camy))


# ---------------------------------------------------------------- chefe
class Boss:
    name = "CRIO-DRONE"

    def __init__(self, game, x0):
        self.game = game
        self.S = game.assets.boss_S
        self.x0 = x0
        self.cx = x0 + W / 2.0
        self.hp = self.max_hp = 12
        self.state = "intro"
        self.t = 0.0
        self.anim = 0.0
        self.ceil_y = 8
        self.hover_y = 120.0
        self.floor_y = float(H - 3 * T)
        self.land_y = self.floor_y - 30 * self.S + 6
        self.pod_y = -190.0
        self.vy = 0.0
        self.shots = 0
        self.shoot_t = 1.0
        self.timer = 0.0
        self.flash = 0.0
        self.dmg_cd = 0.0
        self.phase = 1
        self.bullets = []
        self.waves = []
        self.boom_t = 0.0
        self.q = 0.0                     # mola de squash & stretch do casulo
        self.qv = 0.0
        self.tilt = 0.0                  # inclinacao suave (graus) ao se mover
        self.px = self.cx
        self.muzzle = 0.0                # brilho do bico ao atirar

    @property
    def vulnerable(self):
        return self.state == "stunned"

    def pod_rect(self):
        S = self.S
        return pygame.Rect(int(self.cx - 14 * S), int(self.pod_y + 6 * S), 30 * S, 22 * S)

    def hit(self, dmg):
        if self.dmg_cd > 0 or self.state in ("dying", "dead"):
            return False
        self.hp -= dmg
        self.dmg_cd = 0.5
        if self.state == "stunned":
            self.timer = min(self.timer, 1.8)
        self.flash = 0.25
        self.qv -= 4.0                                       # amassa com o impacto
        g = self.game
        g.shake(14)
        pr = self.pod_rect()
        g.particles.burst(pr.centerx, pr.centery, 16,
                          [(255, 255, 255), (150, 235, 80), (255, 210, 90)], 420, 0.7, 7)
        if self.hp <= 0:
            self.hp = 0
            self.state = "dying"
            self.timer = 2.6
            g.shake(20)
        elif self.phase == 1 and self.hp <= self.max_hp // 2:
            self.phase = 2
        return True

    def update(self, dt, player):
        g = self.game
        self.t += dt
        self.anim += dt
        self.flash = max(0.0, self.flash - dt)
        self.dmg_cd = max(0.0, self.dmg_cd - dt)
        sp_follow = 170.0 if self.phase == 1 else 250.0
        lo, hi = self.x0 + 140, self.x0 + W - 140
        self.muzzle = max(0.0, self.muzzle - dt)
        qt = {"slam": 0.30, "rise": 0.10, "telegraph": 0.06,
              "hover": 0.035 * math.sin(self.t * 4.0)}.get(self.state, 0.0)
        self.q, self.qv = spring(self.q, self.qv, qt, dt)
        vxs = (self.cx - self.px) / max(dt, 1e-4)
        self.px = self.cx
        self.tilt += (clamp(-vxs * 0.02, -8.0, 8.0) - self.tilt) * min(1.0, dt * 10.0)

        if self.state == "intro":
            self.pod_y += 230 * dt
            if self.pod_y >= self.hover_y:
                self.pod_y = self.hover_y
                self.state = "hover"
                self.shots = 0
                self.shoot_t = 1.0
        elif self.state == "hover":
            dx = player.cx - self.cx
            self.cx = clamp(self.cx + clamp(dx, -sp_follow * dt, sp_follow * dt), lo, hi)
            self.pod_y = self.hover_y + math.sin(self.t * 3.0) * 10
            self.shoot_t -= dt
            if self.shoot_t <= 0:
                n = 3 if self.phase == 1 else 5
                for i in range(n):
                    vx = (i - (n - 1) / 2.0) * 150 + random.uniform(-30, 30)
                    self.bullets.append([self.cx, self.pod_y + 140, vx, 60 + random.uniform(0, 60), [], 0.0])
                self.muzzle = 0.25
                self.qv -= 3.0
                g.particles.burst(self.cx, self.pod_y + 135, 8, [(150, 235, 80), (220, 255, 150)], 260, 0.4, 5, 500, 0)
                self.shots += 1
                self.shoot_t = 1.5 if self.phase == 1 else 1.0
                if self.shots >= (3 if self.phase == 1 else 4):
                    self.state = "telegraph"
                    self.timer = 0.95 if self.phase == 1 else 0.7
        elif self.state == "telegraph":
            self.timer -= dt
            dx = player.cx - self.cx
            if self.timer > 0.3:
                self.cx = clamp(self.cx + clamp(dx, -480 * dt, 480 * dt), lo, hi)
            if self.timer <= 0:
                self.state = "slam"
                self.vy = 0.0
        elif self.state == "slam":
            self.vy += 4200 * dt
            self.pod_y += self.vy * dt
            if self.pod_y >= self.land_y:
                self.pod_y = self.land_y
                self.state = "stunned"
                self.timer = 2.5 if self.phase == 1 else 2.0
                g.shake(22)
                self.qv = -4.5
                spd = 360.0 if self.phase == 1 else 470.0
                self.waves.append([self.cx - 70, -1, spd])
                self.waves.append([self.cx + 70, 1, spd])
                g.particles.burst(self.cx, self.floor_y, 24, [(235, 245, 255), (150, 200, 250)],
                                  480, 0.7, 7, 900, 200)
        elif self.state == "stunned":
            self.timer -= dt
            if random.random() < dt * 14:                          # fagulhas do casulo quebrado
                pr = self.pod_rect()
                g.particles.add(random.randint(pr.left, pr.right), pr.top + random.randint(0, 40),
                                random.uniform(-80, 80), random.uniform(-260, -120), 0.5,
                                random.choice([(255, 225, 80), (255, 255, 255)]), 4, 700)
            if self.timer <= 0:
                self.state = "rise"
        elif self.state == "rise":
            self.pod_y -= 460 * dt
            if self.pod_y <= self.hover_y:
                self.pod_y = self.hover_y
                self.state = "hover"
                self.shots = 0
                self.shoot_t = 0.7
        elif self.state == "dying":
            self.timer -= dt
            self.boom_t -= dt
            if self.boom_t <= 0:
                self.boom_t = 0.07
                pr = self.pod_rect()
                x = random.randint(pr.left, pr.right)
                y = random.randint(pr.top, pr.bottom)
                g.particles.burst(x, y, 12, [(255, 255, 255), (255, 200, 80), (255, 110, 60),
                                             (150, 235, 80)], 380, 0.8, 8)
                g.shake(8)
            if self.timer <= 0:
                self.state = "dead"
                g.boss_defeated()

        # projeteis de acido
        pl_rect = player.rect
        for b in self.bullets:
            b[3] += 900 * dt
            b[0] += b[2] * dt
            b[1] += b[3] * dt
            b[5] += dt
            trail_push(b[4], b[0], b[1], 9)
            if random.random() < dt * 16:                          # pinga acido
                g.particles.add(b[0], b[1], random.uniform(-30, 30), random.uniform(0, 40), 0.4,
                                (150, 235, 80), 4, 500)
        keep = []
        for b in self.bullets:
            br = pygame.Rect(int(b[0] - 8), int(b[1] - 8), 16, 16)
            if b[1] >= self.floor_y - 6:
                g.particles.burst(b[0], self.floor_y - 4, 5, [(150, 235, 80), (200, 255, 120)],
                                  160, 0.4, 5, 600, 100)
                continue
            if not player.dead and br.colliderect(pl_rect):
                if player.attacking:
                    keep.append(b)
                    continue
                player.hurt(g, b[0])
                continue
            keep.append(b)
        self.bullets = keep

        # ondas de choque no chao
        keepw = []
        for w in self.waves:
            w[0] += w[1] * w[2] * dt
            wr = pygame.Rect(int(w[0] - 20), int(self.floor_y - 30), 40, 30)
            if w[0] < self.x0 - 40 or w[0] > self.x0 + W + 40:
                continue
            if not player.dead and wr.colliderect(pl_rect):
                player.hurt(g, w[0])
            g.particles.add(w[0], self.floor_y - 4, 0, -60, 0.3, (235, 245, 255), 6, 0)
            keepw.append(w)
        self.waves = keepw

        # contato com o corpo
        if player.dead or self.state in ("dying", "dead"):
            return
        pod = self.pod_rect()
        if pod.colliderect(pl_rect):
            if self.vulnerable:
                if player.attacking:
                    if self.hit(2):
                        player.end_dash(0)
                        player.vx = -player.dash_dir * 380.0
                        player.vy = -420.0
                        player.air_dash = True
                elif player.vy > 0 and pl_rect.bottom < pod.top + 40:
                    if self.hit(1):
                        player.vy = -760.0
                        player.air_dash = True
            else:
                player.hurt(g, self.cx)

    # ---- desenho
    def draw(self, surf, cam, camy, assets):
        if self.state == "dead":
            return
        S = self.S
        st = self.state
        f = int(self.anim * 9) % 4
        shake_x = 0
        if st == "telegraph":
            shake_x = random.randint(-4, 4)
        if st == "dying":
            shake_x = random.randint(-8, 8)
        cx = self.cx + shake_x
        px = int(cx - S - cam)                                   # centro do casulo na tela
        pcy = int(self.pod_y + 15 * S - camy)                    # meio do casulo
        near = clamp((self.pod_y - self.hover_y) / max(1.0, self.land_y - self.hover_y), 0.0, 1.0)
        draw_shadow(surf, px, self.floor_y - camy - 2, 120 + 120 * near, 0.35 + 0.55 * near)
        # aura de carga (antes da pancada) e rastro de velocidade (durante a queda)
        if st == "telegraph":
            k = 0.5 + 0.5 * math.sin(self.t * 28)
            draw_glow(surf, px, pcy, 150 + int(20 * k), (255, 60, 40), 0.55 + 0.4 * k)
        elif st == "slam":
            for j in range(1, 6):
                draw_glow(surf, px, pcy - j * 34, 72, (170, 230, 255), 0.5 - j * 0.08)
        # placa no teto
        plate = assets.boss_plate[f]
        surf.blit(plate, (int(cx - 21 * S - cam), int(self.ceil_y - camy)))
        # haste
        top = self.ceil_y + 6 * S
        length = int(self.pod_y - top) + 6
        if length > 0:
            rod = pygame.transform.scale(assets.boss_rod, (3 * S, length))
            surf.blit(rod, (int(cx - S - cam), int(top - camy)))
        pod = assets.boss_pod[f]
        if self.flash > 0 or (st == "dying" and int(self.t * 20) % 2 == 0):
            pod = add_flash(pod, (170, 170, 170))
        elif st == "telegraph" and int(self.t * 16) % 2 == 0:
            pod = add_flash(pod, (140, 0, 0))
        pw, ph = pod.get_size()                                  # squash & stretch + inclinacao, preso pelo fundo
        sw, sh = max(2, int(pw * (1.0 - 0.55 * self.q))), max(2, int(ph * (1.0 + self.q)))
        if (sw, sh) != (pw, ph):
            pod = pygame.transform.scale(pod, (sw, sh))
        if abs(self.tilt) > 0.4:
            pod = pygame.transform.rotate(pod, self.tilt)
        bottom = self.pod_y + ph - camy
        surf.blit(pod, (int(px - pod.get_width() / 2), int(bottom - sh / 2 - pod.get_height() / 2)))
        # brilho do bico: carrega antes de atirar e estoura ao disparar
        mz = self.muzzle * 4.0
        if st == "hover" and self.shoot_t < 0.35:
            mz = max(mz, 1.0 - self.shoot_t / 0.35)
        if mz > 0.02:
            draw_glow(surf, px, int(self.pod_y + 130 - camy), 38 + int(26 * min(mz, 1.0)), (130, 255, 70), min(mz, 1.0))
        if self.vulnerable:
            for i in range(4):
                a = self.t * 5 + i * math.tau / 4
                sx = cx + math.cos(a) * 70
                sy = self.pod_y + 6 + math.sin(a) * 14
                draw_glow(surf, sx - cam, sy - camy, 22, (255, 210, 60), 0.6)
                pygame.draw.polygon(surf, (255, 225, 80), [
                    (sx - cam, sy - camy - 9), (sx - cam + 4, sy - camy - 2), (sx - cam + 10, sy - camy),
                    (sx - cam + 4, sy - camy + 3), (sx - cam, sy - camy + 10), (sx - cam - 4, sy - camy + 3),
                    (sx - cam - 10, sy - camy), (sx - cam - 4, sy - camy - 2)])
        for b in self.bullets:                                   # acido: bolha brilhante com rastro
            bx, by = int(b[0] - cam), int(b[1] - camy)
            draw_trail(surf, b[4], cam, camy, (90, 255, 60), 13)
            r = 10 + int(round(2 * math.sin(b[5] * 18)))
            draw_glow(surf, bx, by, 32, (90, 230, 50), 0.9)
            pygame.draw.circle(surf, (40, 110, 20), (bx, by), r + 2)
            pygame.draw.circle(surf, (110, 210, 50), (bx, by), r)
            pygame.draw.circle(surf, (190, 255, 110), (bx, by), max(2, r - 3))
            pygame.draw.circle(surf, (240, 255, 210), (bx - 3, by - 3), 3)
        for w in self.waves:
            draw_ice_wave(surf, cam, camy, self.floor_y, w, self.t)


# ---------------------------------------------------------------- chefe da fase 2 do Mundo 2: GELEIA GIGANTE
class Slime(Boss):
    """GELEIA (Mundo 2, fase 2): luta de TERRITORIO e RISCO. Sem pancada no chao nem ondas.
    - PULA-PULA: quica pela arena como uma bola e deixa POCAS PEGAJOSAS onde pousa (a sombra mostra onde).
    - GOSMA: cospe bolas que viram pocas ao cair.
    - GOTEIRA: sobe no teto e pinga gosma em cima de voce; depois cai num ponto marcado.
    - MITOSE: se divide em mini-geleias e fica FRACA (vulneravel!). Mas as minis voltam pra ela: cada uma
      que a alcanca CURA 1 de vida. Mate as minis com DASH/pisao e bata nela antes disso.
    Poca = GRUDADO: lento e sem pulo. DASH (J) solta voce."""
    name = "GELEIA"
    FW, FH, NF = 166, 166, 9
    K = 1.4
    PAT1 = ["bounce", "glob", "mitosis", "drip"]
    PAT2 = ["glob", "bounce", "mitosis", "drip", "bounce", "mitosis"]
    GOO_T = 2.0                                  # tempo grudado depois de sair da poca

    def __init__(self, game, x0):
        Boss.__init__(self, game, x0)
        self.gy = self.land_y
        self.pattern = list(self.PAT1)
        self.ai = 0
        self.enraged = False
        self.sz = 1.0
        self.minis, self.puddles, self.globs, self.drips = [], [], [], []
        self.goo = 0.0
        self.pl = None
        self.bounces = 0
        self.sx = self.tx = self.cx
        self.lt, self.LT = 0.0, 0.85
        self.drip_n, self.drip_t = 0, 0.0
        self.land_x = self.cx

    @property
    def vulnerable(self):
        return self.state == "frail"

    def pod_rect(self):
        bottom = self.pod_y + 140
        w, h = 160 * self.sz, 150 * self.sz
        return pygame.Rect(int(self.cx - w / 2), int(bottom - h), int(w), int(h))

    def frames(self, assets):
        key = "slime_frames"
        if key not in assets.cache:
            sheet = load_img("slime")
            fw = sheet.get_width() / float(self.NF)
            out = []
            for i in range(self.NF):
                x = int(round(i * fw))
                fr = sheet.subsurface(pygame.Rect(x, 0, self.FW, self.FH)).copy()
                out.append(pygame.transform.scale(fr, (int(self.FW * self.K), int(self.FH * self.K))))
            assets.cache[key] = out
        return assets.cache[key]

    def hit(self, dmg):
        ok = Boss.hit(self, dmg)
        if ok and self.phase == 2 and not self.enraged:
            self.enraged = True
            self.pattern = list(self.PAT2)
            self.ai = 0
            self.game.shake(18)
        return ok

    # ---- ganchos do jogo (controle do jogador)
    def mod_input(self, inp, pl):
        if self.state in ("dying", "dead"):
            self.goo = 0.0
            return inp
        if self.goo > 0 and not pl.attacking:
            if inp["dash_down"]:
                self.goo = 0.0                       # DASH solta do grude
                self.game.particles.burst(pl.cx, pl.y + pl.h - 6, 10, [(120, 210, 255), (30, 110, 210)],
                                          260, 0.4, 5, 600, 100)
            else:
                inp = dict(inp)
                inp["jump_down"] = False
                inp["jump_held"] = False
        return inp

    def post_player(self, pl):
        if self.goo > 0 and not pl.attacking:
            pl.vx = clamp(pl.vx, -150.0, 150.0)

    # ---- helpers
    def add_puddle(self, x, life):
        self.puddles.append({"x": clamp(x, self.x0 + 70, self.x0 + W - 70), "life": life, "age": 0.0})
        if len(self.puddles) > 7:
            self.puddles.pop(0)

    def start_bounce(self, player):
        lo, hi = self.x0 + 110, self.x0 + W - 110
        self.sx = self.cx
        self.tx = clamp(player.cx + random.uniform(-150, 150), lo, hi)
        self.lt = 0.0
        self.LT = 0.85 if self.phase == 1 else 0.68
        self.state = "bounce"

    def pick_move(self, player):
        mv = self.pattern[self.ai % len(self.pattern)]
        self.ai += 1
        p1 = (self.phase == 1)
        if mv == "bounce":
            self.state = "bounce_t"
            self.timer = 0.55
            self.bounces = 3 if p1 else 5
        elif mv == "glob":
            self.state = "glob_t"
            self.timer = 0.75 if p1 else 0.55
        elif mv == "mitosis":
            if len(self.minis) >= 2:                          # ainda tem minis vivas: cospe gosma
                self.state = "glob_t"
                self.timer = 0.6
            else:
                self.state = "mitosis_t"
                self.timer = 0.9
        else:
            self.state = "drip_up"
            self.drip_n = 6 if p1 else 9

    def update(self, dt, player):
        g = self.game
        self.pl = player
        self.t += dt
        self.anim += dt
        self.flash = max(0.0, self.flash - dt)
        self.dmg_cd = max(0.0, self.dmg_cd - dt)
        self.goo = max(0.0, self.goo - dt)
        lo, hi = self.x0 + 110, self.x0 + W - 110
        st = self.state
        p1 = (self.phase == 1)
        goal = 0.68 if st == "frail" else 1.0
        self.sz += (goal - self.sz) * min(1.0, dt * 7.0)
        BLUE = [(120, 210, 255), (30, 110, 210), (220, 245, 255)]
        # mola de squash & stretch (transicoes suaves entre as poses)
        if st == "bounce_t":
            qt = -0.28 + 0.04 * math.sin(self.t * 30)
        elif st == "glob_t":
            qt = -0.16 + 0.04 * math.sin(self.t * 26)
        elif st == "mitosis_t":
            qt = 0.06 * math.sin(self.t * 40)
        elif st == "bounce":
            qt = 0.28 * abs(1.0 - 2.0 * clamp(self.lt / self.LT, 0.0, 1.0)) - 0.05
        elif st in ("drip_up", "drip_fall"):
            qt = 0.35
        elif st == "frail":
            qt = 0.06 * math.sin(self.t * 10)
        else:
            qt = 0.035 * math.sin(self.t * 3.2)
        self.q, self.qv = spring(self.q, self.qv, qt, dt)

        if st == "intro":
            self.vy += 3000 * dt
            self.pod_y += self.vy * dt
            if self.pod_y >= self.gy:
                self.pod_y = self.gy
                self.vy = 0.0
                self.state = "idle"
                self.timer = 1.0
                g.shake(22)
                self.qv = -6.0
                g.particles.burst(self.cx, self.floor_y, 24, BLUE, 480, 0.7, 7, 900, 200)
        elif st == "idle":
            self.timer -= dt
            if self.timer <= 0:
                self.pick_move(player)
        elif st == "bounce_t":                              # PULA-PULA: agacha
            self.timer -= dt
            if self.timer <= 0:
                self.start_bounce(player)
        elif st == "bounce":
            self.lt += dt
            u = min(1.0, self.lt / self.LT)
            self.cx = self.sx + (self.tx - self.sx) * u
            self.pod_y = self.gy - 4 * 300.0 * u * (1 - u)
            if u >= 1.0:
                self.pod_y = self.gy
                g.shake(8)
                self.qv = -4.5
                g.particles.burst(self.cx, self.floor_y, 10, BLUE, 300, 0.5, 6, 800, 150)
                self.add_puddle(self.cx, 6.0 if p1 else 9.0)
                self.bounces -= 1
                if self.bounces > 0:
                    self.start_bounce(player)
                else:
                    self.state = "idle"
                    self.timer = 1.1 if p1 else 0.8
        elif st == "glob_t":                                # GOSMA: infla e cospe bolas de gosma
            self.timer -= dt
            if self.timer <= 0:
                n = 3 if p1 else 5
                y0 = self.pod_y + 30
                T_ = 0.9
                for i in range(n):
                    tx = clamp(player.cx + (i - (n - 1) / 2.0) * 150 + random.uniform(-30, 30), lo, hi)
                    vx = (tx - self.cx) / T_
                    vy = (self.floor_y - 6 - y0 - 0.5 * 900 * T_ * T_) / T_
                    self.globs.append([self.cx, y0, vx, vy, [], 0.0])
                g.particles.burst(self.cx, y0, 8, BLUE, 260, 0.4, 5)
                self.qv = -3.5
                self.state = "idle"
                self.timer = 1.3 if p1 else 0.9
        elif st == "mitosis_t":                             # MITOSE: treme e se divide
            self.timer -= dt
            if self.timer <= 0:
                n = 2 if p1 else 3
                for i in range(n):
                    d = -1 if i % 2 == 0 else 1
                    self.minis.append({"x": clamp(self.cx + d * (90 + 70 * (i // 2)), self.x0 + 50, self.x0 + W - 50),
                                       "yo": 0.0, "vy": -420.0, "vx": d * 200.0, "hop": 0.5})
                g.shake(12)
                self.qv = 5.0
                g.particles.burst(self.cx, self.gy + 100, 16, BLUE, 340, 0.6, 6, 700, 100)
                self.state = "frail"
                self.timer = 4.6 if p1 else 4.0
        elif st == "frail":                                 # FRACA: bata nela (mas as minis vem curar!)
            self.timer -= dt
            if self.timer <= 0:
                self.state = "idle"
                self.timer = 0.9
        elif st == "drip_up":                               # GOTEIRA: sobe no teto
            self.pod_y -= 1900 * dt
            if self.pod_y <= -420:
                self.pod_y = -420.0
                self.state = "drip_hang"
                self.drip_t = 0.4
        elif st == "drip_hang":
            self.drip_t -= dt
            if self.drip_t <= 0 and self.drip_n > 0:
                self.drip_n -= 1
                self.drip_t = 0.5 if p1 else 0.36
                self.drips.append({"x": clamp(player.cx + random.uniform(-110, 110), self.x0 + 40, self.x0 + W - 40),
                                   "y": 20.0, "vy": 0.0, "delay": 0.7})
            if self.drip_n <= 0 and self.drip_t <= -0.6:
                far = self.x0 + W - 220 if player.cx < self.x0 + W / 2 else self.x0 + 220
                self.land_x = far + random.uniform(-80, 80)
                self.cx = clamp(self.land_x, lo, hi)
                self.state = "drip_aim"
                self.timer = 1.0
        elif st == "drip_aim":                              # marca onde vai cair
            self.timer -= dt
            if self.timer <= 0:
                self.state = "drip_fall"
                self.vy = 0.0
        elif st == "drip_fall":
            self.vy += 4800 * dt
            self.pod_y += self.vy * dt
            if self.pod_y >= self.gy:
                self.pod_y = self.gy
                self.vy = 0.0
                g.shake(16)
                self.qv = -6.0
                g.particles.burst(self.cx, self.floor_y, 18, BLUE, 420, 0.6, 6, 900, 180)
                self.add_puddle(self.cx - 80, 6.0)
                self.add_puddle(self.cx + 80, 6.0)
                if not player.dead and self.pod_rect().colliderect(player.rect):
                    player.hurt(g, self.cx)
                self.state = "idle"
                self.timer = 1.4 if p1 else 1.0
        elif st == "dying":
            self.minis, self.puddles, self.globs, self.drips = [], [], [], []
            self.goo = 0.0
            self.timer -= dt
            self.boom_t -= dt
            if self.boom_t <= 0:
                self.boom_t = 0.07
                pr = self.pod_rect()
                x = random.randint(pr.left, pr.right)
                y = random.randint(pr.top, pr.bottom)
                g.particles.burst(x, y, 12, [(255, 255, 255), (120, 210, 255), (56, 184, 249),
                                             (30, 110, 210)], 380, 0.8, 8)
                g.shake(8)
            if self.timer <= 0:
                self.state = "dead"
                g.boss_defeated()

        pl_rect = player.rect

        # bolas de gosma
        keepg = []
        for b in self.globs:
            b[3] += 900 * dt
            b[0] += b[2] * dt
            b[1] += b[3] * dt
            b[5] += dt
            trail_push(b[4], b[0], b[1], 9)
            if random.random() < dt * 14:                          # pinga gosma
                g.particles.add(b[0], b[1], random.uniform(-30, 30), random.uniform(0, 40), 0.4,
                                (120, 210, 255), 4, 500)
            br = pygame.Rect(int(b[0] - 10), int(b[1] - 10), 20, 20)
            if b[1] >= self.floor_y - 6:
                g.particles.burst(b[0], self.floor_y - 4, 6, BLUE, 180, 0.4, 5, 600, 100)
                self.add_puddle(b[0], 7.0)
                continue
            if not player.dead and br.colliderect(pl_rect) and not player.attacking:
                player.hurt(g, b[0])
                continue
            keepg.append(b)
        self.globs = keepg

        # pingos da goteira
        keepd = []
        for d in self.drips:
            if d["delay"] > 0:
                d["delay"] -= dt
                keepd.append(d)
                continue
            d["vy"] += 1800 * dt
            d["y"] += d["vy"] * dt
            if d["y"] >= self.floor_y - 14:
                g.particles.burst(d["x"], self.floor_y - 4, 5, BLUE, 160, 0.4, 5, 600, 100)
                self.add_puddle(d["x"], 5.0)
                continue
            dr = pygame.Rect(int(d["x"] - 9), int(d["y"] - 4), 18, 30)
            if not player.dead and dr.colliderect(pl_rect) and not player.attacking:
                player.hurt(g, d["x"])
                continue
            keepd.append(d)
        self.drips = keepd

        # pocas pegajosas: grudam (lento, sem pulo). DASH solta.
        keepp = []
        for p in self.puddles:
            p["life"] -= dt
            p["age"] += dt
            if p["life"] <= 0:
                continue
            pr = pygame.Rect(int(p["x"] - 70), int(self.floor_y - 16), 140, 18)
            if not player.dead and not player.attacking and pr.colliderect(pl_rect):
                self.goo = self.GOO_T
            keepp.append(p)
        self.puddles = keepp

        # minis: pulam ate a geleia e CURAM 1 de vida. DASH/pisao acaba com elas.
        keepm = []
        pod = self.pod_rect()
        for m in self.minis:
            m["hop"] -= dt
            if m["yo"] > 0 or m["vy"] < 0:
                m["vy"] += 1500 * dt
                m["yo"] -= m["vy"] * dt
                m["x"] = clamp(m["x"] + m["vx"] * dt, self.x0 + 40, self.x0 + W - 40)
                if m["yo"] <= 0 and m["vy"] > 0:
                    m["yo"] = 0.0
                    m["vy"] = 0.0
                    m["vx"] = 0.0
                    m["hop"] = 0.35
            elif m["hop"] <= 0:
                m["vy"] = -520.0
                m["vx"] = (1 if self.cx >= m["x"] else -1) * 190.0
            r = pygame.Rect(int(m["x"] - 26), int(self.floor_y - m["yo"] - 44), 52, 44)
            if self.state not in ("dying", "dead") and r.colliderect(pod) and self.pod_y > 0:
                if self.hp < self.max_hp:                    # absorvida: cura
                    self.hp += 1
                g.particles.burst(m["x"], r.centery, 12, [(150, 255, 170), (255, 255, 255), (56, 184, 249)],
                                  300, 0.6, 6, -200, 0)
                continue
            dead = False
            if not player.dead and r.colliderect(pl_rect):
                if player.attacking:
                    dead = True
                elif player.vy > 0 and pl_rect.bottom < r.top + 24:
                    dead = True
                    player.vy = -640.0
                else:
                    player.hurt(g, m["x"])
            if dead:
                g.particles.burst(m["x"], r.centery, 10, BLUE, 280, 0.5, 6, 700, 100)
                continue
            keepm.append(m)
        self.minis = keepm

        # contato com o corpo
        if player.dead or self.state in ("dying", "dead"):
            return
        pod = self.pod_rect()
        if pod.colliderect(pl_rect):
            if self.vulnerable:
                if player.attacking:
                    if self.hit(2):
                        player.end_dash(0)
                        player.vx = -player.dash_dir * 380.0
                        player.vy = -420.0
                        player.air_dash = True
                elif player.vy > 0 and pl_rect.bottom < pod.top + 40:
                    if self.hit(1):
                        player.vy = -760.0
                        player.air_dash = True
            else:
                player.hurt(g, self.cx)

    # ---- desenho
    def draw(self, surf, cam, camy, assets):
        if self.state == "dead":
            return
        st = self.state
        fr = self.frames(assets)
        img = fr[3] if st == "frail" else fr[int(self.anim * 9) % self.NF]
        iw, ih = img.get_width(), img.get_height()
        sx = self.sz * (1.0 - 0.6 * self.q)                      # a mola faz o corpo esticar e amassar
        sy = self.sz * (1.0 + self.q)
        img = pygame.transform.scale(img, (max(2, int(iw * sx)), max(2, int(ih * sy))))
        if self.flash > 0 or (st == "dying" and int(self.t * 20) % 2 == 0):
            img = add_flash(img, (170, 170, 170))
        elif st == "mitosis_t" and int(self.t * 16) % 2 == 0:
            img = add_flash(img, (60, 140, 60))
        elif self.enraged:
            img = add_flash(img, (60, 0, 0))
        shake_x = 0
        if st in ("glob_t", "mitosis_t", "bounce_t"):
            shake_x = random.randint(-3, 3)
        elif st == "dying":
            shake_x = random.randint(-8, 8)
        cx = self.cx + shake_x
        fy = int(self.floor_y - camy)

        # marcadores de pouso (anel de mira que fecha)
        marks = []
        if st == "bounce":
            marks.append(self.tx)
        if st in ("drip_aim", "drip_fall"):
            marks.append(self.land_x)
        for mx in marks:
            k = 0.6 + 0.4 * abs(math.sin(self.t * 12))
            draw_glow(surf, mx - cam, fy - 8, 100, (255, 60, 80), 0.55 * k)
            sh = pygame.Surface((190, 26), pygame.SRCALPHA)
            pygame.draw.ellipse(sh, (255, 70, 90, int(150 * k)), (0, 0, 190, 26))
            pygame.draw.ellipse(sh, (255, 200, 205, int(190 * k)), (47, 6, 96, 14))
            surf.blit(sh, (int(mx - 95 - cam), fy - 14))

        # pocas pegajosas: crescem ao surgir, encolhem ao sumir, com ondas e bolhas
        for pd in self.puddles:
            k = min(1.0, pd["age"] / 0.25) * min(1.0, pd["life"] / 1.0)
            k = k * k * (3 - 2 * k)
            wd = int(70 * k)
            if wd < 4:
                continue
            x = int(pd["x"] - cam)
            hh = max(4, int(22 * (0.4 + 0.6 * k)))
            draw_glow(surf, x, fy - 8, wd + 10, (40, 120, 220), 0.35 * k)
            pygame.draw.ellipse(surf, (24, 90, 185), (x - wd, fy - hh + 4, wd * 2, hh))
            pygame.draw.ellipse(surf, (60, 150, 235), (x - int(wd * 0.78), fy - hh + 6, int(wd * 1.56), max(3, hh - 6)))
            pygame.draw.ellipse(surf, (150, 225, 255), (x - int(wd * 0.5), fy - hh + 8, int(wd * 0.9), max(2, hh // 3)))
            rp = (self.t * 1.3 + pd["x"] * 0.013) % 1.0               # onda que se espalha
            rw = int(wd * (0.25 + 0.75 * rp))
            if rw > 6:
                pygame.draw.ellipse(surf, (90, 180, 245), (x - rw, fy - hh // 2 - 2, rw * 2, max(3, hh // 2)), 1)
            for bi in range(2):                                       # bolhas subindo
                u = (self.t * 0.7 + pd["x"] * 0.011 + bi * 0.5) % 1.0
                bx = x + int(math.sin(self.t * 1.3 + bi * 3 + pd["x"]) * wd * 0.5)
                by = fy - 10 - int(u * 18)
                pygame.draw.circle(surf, (190, 235, 255), (bx, by), max(1, int(3 * (1 - u) * k)), 1)

        hgt = clamp((self.gy - self.pod_y) / 320.0, 0.0, 1.0)
        draw_shadow(surf, cx - cam, fy - 3, (170 * self.sz) * (1.0 - 0.4 * hgt) * (1.0 + 0.3 * self.q), 0.9 - 0.5 * hgt)
        # corpo (preso pelo chao ao agachar e preso pelo fundo ao esticar)
        surf.blit(img, (int(cx - img.get_width() / 2 - cam),
                        int(self.pod_y + 152 - img.get_height() - camy)))

        # mini-geleias: esticam no pulo, agacham antes de pular e piscam
        for i, m in enumerate(self.minis):
            x = int(m["x"] - cam)
            y = int(self.floor_y - m["yo"] - camy)
            air = m["yo"] > 0 or m["vy"] < 0
            if air:
                stv = clamp(abs(m["vy"]) / 900.0, 0.0, 0.35)
            elif m["hop"] < 0.15:
                stv = -0.25 * (1.0 - m["hop"] / 0.15)
            else:
                stv = 0.07 * math.sin(self.t * 6 + i)
            wm = int(56 * (1 - 0.5 * stv))
            hm = int(46 * (1 + stv))
            shw = max(10, int(46 - m["yo"] * 0.12))                   # sombra no chao
            pygame.draw.ellipse(surf, (20, 40, 80), (x - shw // 2, int(self.floor_y - camy) - 5, shw, 8))
            draw_glow(surf, x, y - hm // 2, 44, (40, 150, 230), 0.4)
            pygame.draw.ellipse(surf, (20, 60, 150), (x - wm // 2, y - hm, wm, hm + 2))
            pygame.draw.ellipse(surf, (56, 184, 249), (x - wm // 2 + 4, y - hm + 3, wm - 8, hm - 5))
            pygame.draw.ellipse(surf, (220, 245, 255), (x - wm // 2 + 10, y - hm + 6, 14, 9))
            ex = 3 if self.cx >= m["x"] else -3                       # olha pra mae
            if (self.t * 0.9 + i * 0.37) % 2.5 < 0.12:
                pygame.draw.line(surf, (20, 30, 60), (x - 11 + ex, y - hm // 2), (x - 5 + ex, y - hm // 2), 2)
                pygame.draw.line(surf, (20, 30, 60), (x + 5 + ex, y - hm // 2), (x + 11 + ex, y - hm // 2), 2)
            else:
                pygame.draw.rect(surf, (20, 30, 60), (x - 11 + ex, y - hm // 2 - 5, 6, 9))
                pygame.draw.rect(surf, (20, 30, 60), (x + 5 + ex, y - hm // 2 - 5, 6, 9))
                pygame.draw.rect(surf, (255, 255, 255), (x - 10 + ex, y - hm // 2 - 4, 2, 3))
                pygame.draw.rect(surf, (255, 255, 255), (x + 6 + ex, y - hm // 2 - 4, 2, 3))

        # pingos da goteira (aviso piscando no teto, depois gota com rastro)
        for d in self.drips:
            x = int(d["x"] - cam)
            if d["delay"] > 0:
                k = 0.5 + 0.5 * math.sin(self.t * 24)
                draw_glow(surf, x, 22, 40, (255, 70, 90), 0.5 + 0.4 * k)
                if k > 0.3:
                    pygame.draw.polygon(surf, (255, 90, 110), [(x - 10, 10), (x + 10, 10), (x, 34)])
                    pygame.draw.polygon(surf, (255, 220, 225), [(x - 4, 14), (x + 4, 14), (x, 26)])
            else:
                y = int(d["y"] - camy)
                for j in range(1, 5):
                    draw_glow(surf, x, y - j * 16, 14, (60, 150, 235), 0.45 - j * 0.09)
                draw_glow(surf, x, y + 8, 30, (60, 160, 240), 0.7)
                pygame.draw.polygon(surf, (20, 60, 150), [(x, y - 14), (x - 9, y + 8), (x + 9, y + 8)])
                pygame.draw.circle(surf, (20, 60, 150), (x, y + 10), 11)
                pygame.draw.polygon(surf, (56, 184, 249), [(x, y - 8), (x - 6, y + 8), (x + 6, y + 8)])
                pygame.draw.circle(surf, (56, 184, 249), (x, y + 10), 8)
                pygame.draw.circle(surf, (225, 248, 255), (x - 3, y + 7), 3)

        # bolas de gosma: esticadas na direcao do movimento, com rastro e brilho
        for b in self.globs:
            bx, by = int(b[0] - cam), int(b[1] - camy)
            draw_trail(surf, b[4], cam, camy, (60, 160, 255), 14)
            draw_glow(surf, bx, by, 34, (50, 150, 240), 0.8)
            spd = math.hypot(b[2], b[3])
            st_ = 1.0 + min(0.55, spd / 1800.0) + 0.07 * math.sin(b[5] * 20)
            bs = pygame.Surface((56, 56), pygame.SRCALPHA)
            pygame.draw.ellipse(bs, (20, 60, 150), (28 - int(15 * st_), 28 - 13, int(30 * st_), 26))
            pygame.draw.ellipse(bs, (56, 184, 249), (28 - int(12 * st_), 28 - 10, int(24 * st_), 20))
            pygame.draw.ellipse(bs, (225, 248, 255), (28 - int(8 * st_), 28 - 8, int(10 * st_), 6))
            bs = pygame.transform.rotate(bs, -math.degrees(math.atan2(b[3], b[2])))
            surf.blit(bs, (bx - bs.get_width() // 2, by - bs.get_height() // 2))

        pr = self.pod_rect()
        if self.vulnerable:
            for i in range(4):
                a = self.t * 5 + i * math.tau / 4
                sx2 = cx + math.cos(a) * 60 - cam
                sy2 = pr.top + 6 + math.sin(a) * 14 - camy
                draw_glow(surf, sx2, sy2, 22, (255, 210, 60), 0.6)
                pygame.draw.polygon(surf, (255, 225, 80), [
                    (sx2, sy2 - 9), (sx2 + 4, sy2 - 2), (sx2 + 10, sy2), (sx2 + 4, sy2 + 3),
                    (sx2, sy2 + 10), (sx2 - 4, sy2 + 3), (sx2 - 10, sy2), (sx2 - 4, sy2 - 2)])

        # jogador grudado
        if self.goo > 0 and self.pl is not None and not self.pl.dead:
            px = int(self.pl.cx - cam)
            py = int(self.pl.y + self.pl.h - camy)
            pygame.draw.ellipse(surf, (30, 110, 210), (px - 34, py - 12, 68, 18))
            pygame.draw.ellipse(surf, (120, 210, 255), (px - 22, py - 10, 44, 9))
            for k in range(3):                                        # fios de gosma esticando
                fx = px - 18 + k * 18
                pygame.draw.line(surf, (60, 150, 235), (fx, py - 4), (fx + int(math.sin(self.t * 6 + k) * 3), py - 18), 3)
            draw_text(surf, assets.font_s, "GRUDADO!  DASH (J) SOLTA", px, int(self.pl.y - 36 - camy),
                      (150, 235, 255), center=True)


# ---------------------------------------------------------------- chefe final: CRIO-GOLEM
class Golem:
    """Golem de gelo. Ataques: bolas de gelo, estalactites do teto (fase 2) e pancada no chao.
    So fica vulneravel (nucleo aberto) depois da pancada: ataque com DASH no peito!"""
    name = "CRIO-GOLEM"
    S = 4
    EXTRA = ()                       # estados extras (usados por subclasses, ex.: DIOGO)
    SH_W, SH_H = 20, 68              # tamanho do que cai do teto
    KEEP = 330.0                     # distancia que ele mantem do jogador ao andar
    SPD1, SPD2 = 105.0, 165.0        # velocidade de caminhada (fase 1 / fase 2)
    SPR_BODY, SPR_OPEN, SPR_ARM = "golem_corpo", "golem_corpo_aberto", "golem_braco"
    SPR_BALL, SPR_SHARD = "bola_gelo", "estilhaco"
    FX_ICE = (110, 190, 255)         # cor dos brilhos dos golpes (azul = gelo)
    WAVE_COLS = None                 # paleta da onda de choque (None = gelo azul)

    def __init__(self, game, x0):
        self.game = game
        self.x0 = x0
        self.cx = x0 + W - 330.0
        self.hp = self.max_hp = 12
        self.state = "intro"
        self.t = 0.0
        self.anim = 0.0
        self.floor_y = float(H - 3 * T)
        self.yo = 760.0                 # altura acima do chao (na intro ele cai do teto)
        self.vy = 0.0
        self.face = -1
        self.timer = 0.0
        self.flash = 0.0
        self.dmg_cd = 0.0
        self.phase = 1
        self.pattern = ["throw", "slam"]
        self.ai = 0
        self.balls_left = 0
        self.arm = 0.0                  # 0 = bracos baixos, 1 = bracos levantados
        self.arm_l = 0.0                # levantada suavizada de cada braco
        self.arm_r = 0.0
        self.q = 0.0                    # mola de squash & stretch do corpo
        self.qv = 0.0
        self.balls = []
        self.waves = []
        self.shards = []
        self.boom_t = 0.0

    @property
    def vulnerable(self):
        return self.state == "stunned"

    def body_rect(self):
        S = self.S
        top = self.floor_y - 86 * S - self.yo
        return pygame.Rect(int(self.cx - 28.75 * S), int(top + 6 * S), int(57.5 * S), int(80 * S))

    def bounds(self):
        """Limites da caminhada (x) dentro da arena."""
        m = 57.5 * self.S
        return self.x0 + m, self.x0 + W - m

    def after_slam(self):
        """O que acontece quando a pancada no chao termina (o Golem de gelo fica tonto = vulneravel)."""
        self.state = "stunned"
        self.timer = 3.0 if self.phase == 1 else 2.4

    def hit(self, dmg):
        if self.dmg_cd > 0 or self.state in ("dying", "dead"):
            return False
        self.hp -= dmg
        self.dmg_cd = 0.5
        if self.state == "stunned":
            self.timer = min(self.timer, 1.8)
        self.flash = 0.25
        g = self.game
        g.shake(14)
        br = self.body_rect()
        g.particles.burst(br.centerx, br.centery - 20, 18,
                          [(255, 255, 255), (150, 220, 255), (255, 210, 90)], 440, 0.7, 7)
        if self.hp <= 0:
            self.hp = 0
            self.state = "dying"
            self.timer = 2.6
            self.balls, self.shards, self.waves = [], [], []
            g.shake(20)
        elif self.phase == 1 and self.hp <= self.max_hp // 2:
            self.phase = 2
            self.pattern = ["throw", "rain", "slam"]
            g.shake(16)
        return True

    # ---- ataques
    def throw_ball(self, player):
        bx = self.cx + self.face * 17.5 * self.S
        by = self.floor_y - 57.5 * self.S - self.yo
        vx = clamp((player.cx - bx) / 0.96, -650.0, 650.0)
        self.balls.append({"x": bx, "y": by, "vx": vx, "vy": -480.0, "n": 0,
                           "roll": False, "rot": 0.0, "tr": [], "age": 0.0})
        self.game.particles.burst(bx, by, 8, [(235, 248, 255), (150, 210, 255)], 240, 0.4, 5, 300, 0)

    def spawn_rain(self, player):
        xs = [player.cx + random.uniform(-60, 60)]
        xs += [random.uniform(self.x0 + 80, self.x0 + W - 80) for _ in range(5)]
        for i, x in enumerate(xs):
            self.shards.append({"x": clamp(x, self.x0 + 60, self.x0 + W - 60), "y": -90.0,
                                "vy": 0.0, "delay": 0.8 + i * 0.18})

    def start_extra(self, nxt, player):
        self.state = "walk"
        self.timer = 0.5

    def extra_state(self, dt, player):
        pass

    def update(self, dt, player):
        g = self.game
        self.t += dt
        self.anim += dt
        self.flash = max(0.0, self.flash - dt)
        self.dmg_cd = max(0.0, self.dmg_cd - dt)
        sp = self.SPD1 if self.phase == 1 else self.SPD2
        lo, hi = self.bounds()
        st = self.state
        # corpo de borracha (respira, agacha ao andar, amassa nos impactos)
        if st == "walk":
            qt = 0.02 * math.sin(self.anim * 10)
        elif st == "slam_t":
            qt = 0.05 * self.arm
        elif st == "throw":
            qt = -0.03
        elif st == "stunned":
            qt = -0.025 + 0.01 * math.sin(self.t * 5)
        else:
            qt = 0.012 * math.sin(self.t * 2.6)
        self.q, self.qv = spring(self.q, self.qv, qt, dt)
        # bracos: levantam e descem suavemente
        tl = tr_ = 0.0
        if st == "slam_t":
            tl = tr_ = self.arm
        elif st == "throw":
            if self.face > 0:
                tr_ = 0.85
            else:
                tl = 0.85
        elif st == "rain":
            tl = tr_ = 0.9
        elif st == "walk":
            tl = 0.07 + 0.06 * math.sin(self.anim * 8)
            tr_ = 0.07 + 0.06 * math.sin(self.anim * 8 + math.pi)
        kk = min(1.0, dt * 13.0)
        self.arm_l += (tl - self.arm_l) * kk
        self.arm_r += (tr_ - self.arm_r) * kk

        if st == "intro":
            self.vy += 2600 * dt
            self.yo -= self.vy * dt
            if self.yo <= 0:
                self.yo = 0.0
                self.vy = 0.0
                self.state = "walk"
                self.timer = 1.4
                self.qv = -6.0
                g.shake(22)
                g.particles.burst(self.cx, self.floor_y, 26, [(235, 245, 255), (150, 200, 250)],
                                  520, 0.8, 8, 900, 220)
        elif st == "walk":
            dx = player.cx - self.cx
            self.face = 1 if dx >= 0 else -1
            if abs(dx) > self.KEEP:
                self.cx = clamp(self.cx + self.face * sp * dt, lo, hi)
            self.timer -= dt
            if self.timer <= 0:
                nxt = self.pattern[self.ai % len(self.pattern)]
                self.ai += 1
                if nxt == "throw":
                    self.state = "throw"
                    self.timer = 0.75
                    self.balls_left = 1 if self.phase == 1 else 2
                elif nxt == "slam":
                    self.state = "slam_t"
                    self.timer = 1.0 if self.phase == 1 else 0.75
                elif nxt == "rain":
                    self.state = "rain"
                    self.timer = 2.4
                    self.spawn_rain(player)
                else:
                    self.start_extra(nxt, player)
        elif st == "throw":
            self.face = 1 if player.cx >= self.cx else -1
            self.timer -= dt
            if self.timer <= 0:
                self.throw_ball(player)
                self.qv = 3.0
                self.balls_left -= 1
                if self.balls_left <= 0:
                    self.state = "walk"
                    self.timer = 1.5 if self.phase == 1 else 1.0
                else:
                    self.timer = 0.55
        elif st == "slam_t":
            total = 1.0 if self.phase == 1 else 0.75
            self.timer -= dt
            self.arm = clamp(1.0 - self.timer / total, 0.0, 1.0)
            if self.timer <= 0:
                self.after_slam()
                self.arm = 0.0
                self.qv = -5.0
                g.shake(24)
                spd = 330.0 if self.phase == 1 else 440.0
                self.waves.append([self.cx - 37.5 * self.S, -1, spd])
                self.waves.append([self.cx + 37.5 * self.S, 1, spd])
                g.particles.burst(self.cx, self.floor_y, 26, [(235, 245, 255), (150, 200, 250)],
                                  500, 0.7, 7, 900, 200)
        elif st == "stunned":
            self.timer -= dt
            if self.timer <= 0:
                self.state = "walk"
                self.timer = 1.0
        elif st == "rain":
            self.timer -= dt
            if self.timer <= 0:
                self.state = "walk"
                self.timer = 1.0
        elif st in self.EXTRA:
            self.extra_state(dt, player)
        elif st == "dying":
            self.timer -= dt
            self.boom_t -= dt
            if self.boom_t <= 0:
                self.boom_t = 0.07
                br = self.body_rect()
                x = random.randint(br.left, br.right)
                y = random.randint(br.top, br.bottom)
                g.particles.burst(x, y, 12, [(255, 255, 255), (255, 200, 80), (255, 110, 60),
                                             (150, 220, 255)], 380, 0.8, 8)
                g.shake(8)
            if self.timer <= 0:
                self.state = "dead"
                g.boss_defeated()

        pl_rect = player.rect

        # bolas de gelo
        keep = []
        for b in self.balls:
            if b["roll"]:
                b["x"] += b["vx"] * dt
            else:
                b["vy"] += 1500 * dt
                b["x"] += b["vx"] * dt
                b["y"] += b["vy"] * dt
                if b["y"] >= self.floor_y - 30 and b["vy"] > 0:
                    b["y"] = self.floor_y - 30
                    b["n"] += 1
                    g.particles.burst(b["x"], self.floor_y - 4, 6, [(235, 248, 255), (150, 210, 255)],
                                      200, 0.4, 5, 600, 100)
                    if b["n"] == 1:
                        b["vy"] = -300.0
                        b["vx"] *= 0.7
                    else:
                        b["roll"] = True
                        b["vy"] = 0.0
                        b["vx"] = (1 if b["vx"] >= 0 else -1) * 300.0
            b["rot"] += b["vx"] * dt * 0.02
            b["age"] += dt
            trail_push(b["tr"], b["x"], b["y"], 9)
            if random.random() < dt * 22:                          # lascas de gelo soltando
                g.particles.add(b["x"] + random.uniform(-14, 14), b["y"] + random.uniform(-14, 14),
                                random.uniform(-40, 40), random.uniform(-30, 40), 0.45, (220, 245, 255), 4, 200)
            if b["x"] < self.x0 + 10 or b["x"] > self.x0 + W - 10:
                g.particles.burst(b["x"], b["y"], 8, [(235, 248, 255), (150, 210, 255)], 260, 0.5, 5)
                continue
            br = pygame.Rect(int(b["x"] - 26), int(b["y"] - 26), 52, 52)
            if not player.dead and br.colliderect(pl_rect):
                if player.hurt(g, b["x"]):
                    continue
            keep.append(b)
        self.balls = keep

        # estalactites do teto
        keep = []
        for s in self.shards:
            if s["delay"] > 0:
                s["delay"] -= dt
                keep.append(s)
                continue
            s["vy"] += 2400 * dt
            s["y"] += s["vy"] * dt
            if s["y"] + self.SH_H >= self.floor_y:
                g.particles.burst(s["x"], self.floor_y - 4, 7, [(235, 248, 255), (150, 210, 255)],
                                  240, 0.5, 5, 700, 100)
                continue
            sr = pygame.Rect(int(s["x"] - self.SH_W // 2), int(s["y"]), self.SH_W, self.SH_H)
            if not player.dead and sr.colliderect(pl_rect):
                if player.hurt(g, s["x"]):
                    continue
            keep.append(s)
        self.shards = keep

        # ondas de choque no chao
        keepw = []
        for w in self.waves:
            w[0] += w[1] * w[2] * dt
            wr = pygame.Rect(int(w[0] - 20), int(self.floor_y - 30), 40, 30)
            if w[0] < self.x0 - 40 or w[0] > self.x0 + W + 40:
                continue
            if not player.dead and wr.colliderect(pl_rect):
                player.hurt(g, w[0])
            g.particles.add(w[0], self.floor_y - 4, 0, -60, 0.3, (235, 245, 255), 6, 0)
            keepw.append(w)
        self.waves = keepw

        self.contact(player, pl_rect)

    def contact(self, player, pl_rect):
        """Contato do jogador com o corpo (o Golem de gelo: dash no peito quando tonto)."""
        g = self.game
        if player.dead or self.state in ("dying", "dead"):
            return
        if self.body_rect().colliderect(pl_rect):
            if self.vulnerable:
                if player.attacking and self.hit(2):
                    player.end_dash(0)
                    player.vx = -player.dash_dir * 380.0
                    player.vy = -420.0
                    player.air_dash = True
            else:
                player.hurt(g, self.cx)

    # ---- desenho
    def _draw_arm(self, surf, arm, x, y, side, lift):
        """Braco que gira no ombro. (x, y) = canto do braco pendurado; side = -1 esquerdo, +1 direito."""
        ang = side * 175.0 * clamp(lift, 0.0, 1.0)
        key = ("golem_arm_rot", self.S, side, int(round(ang / 4.0)))
        cache = self.game.assets.cache
        rot = cache.get(key)
        w, h = arm.get_size()
        if rot is None:
            rot = pygame.transform.rotate(arm, int(round(ang / 4.0)) * 4.0)
            cache[key] = rot
        pvx, pvy = w / 2.0, 9.0 * self.S                           # ombro
        vx, vy = pvx - w / 2.0, pvy - h / 2.0
        a = math.radians(int(round(ang / 4.0)) * 4.0)
        rx = vx * math.cos(a) + vy * math.sin(a)
        ry = -vx * math.sin(a) + vy * math.cos(a)
        cx_ = x + pvx - rx
        cy_ = y + pvy - ry
        surf.blit(rot, (int(cx_ - rot.get_width() / 2.0), int(cy_ - rot.get_height() / 2.0)))

    def draw(self, surf, cam, camy, assets):
        if self.state == "dead":
            return
        S = self.S
        st = self.state
        shake = 0
        if st == "slam_t":
            shake = random.randint(-4, 4)
        elif st == "dying":
            shake = random.randint(-8, 8)
        elif st == "throw":
            shake = random.randint(-2, 2)
        cx = self.cx + shake
        hop = int(abs(math.sin(self.anim * 5.0)) * 6) if st == "walk" else 0
        body = assets.sprite(self.SPR_OPEN if st == "stunned" else self.SPR_BODY, S)
        arm_dn = assets.sprite(self.SPR_ARM, S)
        if self.flash > 0 or (st == "dying" and int(self.t * 20) % 2 == 0):
            body = add_flash(body, (170, 170, 170))
        elif st in ("slam_t", "throw") and int(self.t * 16) % 2 == 0:
            body = add_flash(body, (140, 0, 0))
        bw, bh = body.get_size()
        sw, sh = max(2, int(bw * (1.0 - 0.5 * self.q))), max(2, int(bh * (1.0 + self.q)))
        if (sw, sh) != (bw, bh):
            body = pygame.transform.scale(body, (sw, sh))
        lean = 0
        if st == "throw":
            lean = -self.face * 10                                  # puxa o corpo pra tras antes do arremesso
        elif st == "slam_t":
            lean = int(-6 * self.arm)
        base = self.floor_y - self.yo - hop
        top = base - sh
        bx = int(cx - cam - sw / 2.0) + lean

        draw_shadow(surf, bx + sw // 2, self.floor_y - camy - 2, sw * 0.95, clamp(1.0 - self.yo / 500.0, 0.0, 1.0))
        # aura de aviso
        if st == "slam_t":
            draw_glow(surf, bx + sw // 2, int(top + sh * 0.5 - camy), 190, (255, 60, 40), 0.25 + 0.45 * self.arm)
        elif st == "throw":
            draw_glow(surf, bx + sw // 2, int(top + sh * 0.3 - camy), 150, (120, 200, 255), 0.5)

        # bracos (atras do corpo)
        ay = int(top + 34 * S * (1.0 + self.q) - camy)
        self._draw_arm(surf, arm_dn, bx - 6 * S, ay, -1, self.arm_l)
        self._draw_arm(surf, arm_dn, bx + 88 * S, ay, 1, self.arm_r)
        surf.blit(body, (bx, int(top - camy)))

        # nucleo aberto brilhando (hora de bater!) e estrelinhas
        if self.vulnerable:
            k = 0.65 + 0.35 * math.sin(self.t * 9)
            draw_glow(surf, bx + sw // 2, int(top + sh * 0.5 - camy), 120 + int(16 * k), (255, 200, 80), 0.55 * k + 0.2)
            for i in range(4):
                a = self.t * 5 + i * math.tau / 4
                sx = cx + math.cos(a) * 90 - cam
                sy = top + 10 * S + math.sin(a) * 16 - camy
                draw_glow(surf, sx, sy, 22, (255, 210, 60), 0.6)
                pygame.draw.polygon(surf, (255, 225, 80), [
                    (sx, sy - 9), (sx + 4, sy - 2), (sx + 10, sy), (sx + 4, sy + 3),
                    (sx, sy + 10), (sx - 4, sy + 3), (sx - 10, sy), (sx - 4, sy - 2)])

        self.draw_attacks(surf, cam, camy, assets)

    def draw_attacks(self, surf, cam, camy, assets):
        # bolas de gelo: giram, brilham e deixam rastro de geada
        ball_key = ("golem_ball66", self.SPR_BALL)
        ball_img = assets.cache.get(ball_key)
        if ball_img is None:
            ball_img = pygame.transform.scale(assets.sprite(self.SPR_BALL, 1), (66, 66))
            assets.cache[ball_key] = ball_img
        fx = self.FX_ICE
        for b in self.balls:
            bx, by = int(b["x"] - cam), int(b["y"] - camy)
            draw_trail(surf, b["tr"], cam, camy, fx, 22)
            draw_glow(surf, bx, by, 58 + int(4 * math.sin(b["age"] * 14)), fx, 0.75)
            rot = pygame.transform.rotate(ball_img, -math.degrees(b["rot"]))
            surf.blit(rot, (bx - rot.get_width() // 2, by - rot.get_height() // 2))
            for i in range(3):                                      # brilhinhos orbitando
                a = b["age"] * 6 + i * math.tau / 3
                pygame.draw.circle(surf, (235, 250, 255), (bx + int(math.cos(a) * 34), by + int(math.sin(a) * 34)), 2)
        # estalactites: aviso no chao (anel + guia), depois queda com rastro de vento
        shard_img = assets.sprite(self.SPR_SHARD, 2)
        for sh_ in self.shards:
            x = int(sh_["x"] - cam)
            if sh_["delay"] > 0:
                k = 0.5 + 0.5 * math.sin(self.t * 22)
                y = int(self.floor_y - camy)
                draw_glow(surf, x, y - 6, 54, (255, 60, 80), 0.35 + 0.4 * k)
                pygame.draw.ellipse(surf, (255, 110, 130), (x - 26, y - 10, 52, 12), 2)
                if k > 0.25:
                    pygame.draw.polygon(surf, (255, 90, 110), [(x - 14, y - 4), (x + 14, y - 4), (x, y - 26)])
                    pygame.draw.polygon(surf, (255, 220, 225), [(x - 4, y - 8), (x + 4, y - 8), (x, y - 20)])
                for yy in range(40, int(self.floor_y) - 40, 36):    # guia pontilhada
                    pygame.draw.line(surf, (255, 120, 140), (x, int(yy - camy)), (x, int(yy + 10 - camy)), 1)
            else:
                yy = int(sh_["y"] - camy)
                for j in range(1, 5):
                    draw_glow(surf, x, yy - j * 20 + 20, 18, fx, 0.5 - j * 0.1)
                draw_glow(surf, x, yy + 30, 44, fx, 0.6)
                surf.blit(shard_img, (x - shard_img.get_width() // 2, yy))
        # ondas de choque
        for w in self.waves:
            draw_ice_wave(surf, cam, camy, self.floor_y, w, self.t, self.WAVE_COLS)


# ---------------------------------------------------------------- chefe final do Mundo 2: O CARA
class Diogo(object):
    """DIOGO, professor de T.I. (chefe final do Mundo 2). Luta de AULA DE INFORMATICA: ele nao anda nem soca.
    - ALT+TAB: some e reaparece do lado oposto ao seu.
    - PING: pacotes de rede deslizam (no chao: pule; no ar: nao pule na hora errada). DASH atravessa.
    - POP-UPS: janelas de erro quicando pela arena (estilo protetor de tela). DASH ou pisao fecham.
    - TELA AZUL: a tela pisca azul e vem uma rajada de pings (os controles NAO sao mais invertidos).
    - COMPILAR: ele senta no notebook (barra de progresso). E a HORA DE BATER: ataque com DASH para dar CRASH
      ("nao esta respondendo") e causar dano. Se a barra chegar a 100%, ele faz DEPLOY: chuva de bugs.
    - CTRL+Z (fase 2): marca sua posicao e, depois de 2,6s, VOLTA voce para la."""
    name = "DIOGO"
    S = 6
    PAT1 = ["ping", "popup", "bsod", "compile"]
    PAT2 = ["popup", "ping", "undo", "bsod", "compile", "ping", "compile"]

    def __init__(self, game, x0):
        self.game = game
        self.x0 = x0
        self.floor_y = float(H - 3 * T)
        self.xl = x0 + 250.0
        self.xr = x0 + W - 250.0
        self.cx = self.xr
        self.hp = self.max_hp = 12
        self.state = "intro"
        self.t = 0.0
        self.anim = 0.0
        self.flash = 0.0
        self.dmg_cd = 0.0
        self.phase = 1
        self.yo = 760.0
        self.vy = 0.0
        self.timer = 0.0
        self.pattern = list(self.PAT1)
        self.ai = 0
        self.next_move = None
        self.tp_to = self.cx
        self.pkts, self.pops, self.rain = [], [], []
        self.bsod_t = 0.0
        self.prog = 0.0
        self.cdur = 4.8
        self.rec = None
        self.ping_n = 0
        self.ping_t = 0.0
        self.pop_n = 0
        self.pop_t = 0.0
        self.boom_t = 0.0
        self.pl = None
        self.bsod_fx = 0.0
        self.ap = None                   # parametros de animacao suavizados
        self.muzzle = 0.0                # brilho das maos ao mandar um ping
        self.mz_x = self.cx

    @property
    def vulnerable(self):
        return self.state in ("compile", "crash")

    def body_rect(self):
        h = 49 * self.S
        top = self.floor_y - h - self.yo
        return pygame.Rect(int(self.cx - 62), int(top + 10), 124, int(h - 10))

    def hit(self, dmg):
        if self.dmg_cd > 0 or self.state in ("dying", "dead"):
            return False
        g = self.game
        self.hp -= dmg
        self.dmg_cd = 0.5
        self.flash = 0.25
        g.shake(14)
        br = self.body_rect()
        g.particles.burst(br.centerx, br.centery - 20, 18,
                          [(255, 255, 255), (120, 200, 255), (255, 210, 90)], 440, 0.7, 7)
        if self.hp <= 0:
            self.hp = 0
            self.state = "dying"
            self.timer = 2.6
            self.pkts, self.pops, self.rain, self.rec = [], [], [], None
            self.bsod_t = 0.0
            g.shake(20)
            return True
        if self.state == "compile":                          # interrompeu a compilacao: CRASH
            self.state = "crash"
            self.timer = 2.4 if self.phase == 1 else 2.0
            self.prog = 0.0
            g.shake(22)
        if self.phase == 1 and self.hp <= self.max_hp // 2:
            self.phase = 2
            self.pattern = list(self.PAT2)
            self.ai = 0
            g.shake(16)
        return True

    # ---- ganchos do jogo
    def mod_input(self, inp, pl):
        return inp                                           # o Diogo nao mexe nos controles

    def post_player(self, pl):
        pass

    # ---- golpes
    def pick(self, player):
        mv = self.pattern[self.ai % len(self.pattern)]
        self.ai += 1
        self.next_move = mv
        far = self.xl if player.cx > self.x0 + W / 2 else self.xr          # lado oposto ao do jogador
        if abs(far - self.cx) > 100:
            self.tp_to = far
            self.state = "tab_out"
            self.timer = 0.3
        else:
            self.start_move(mv, player)

    def start_move(self, mv, player):
        p1 = (self.phase == 1)
        if mv == "ping":
            self.state = "ping"
            self.ping_n = 5 if p1 else 7
            self.ping_t = 0.5
        elif mv == "popup":
            self.state = "popup"
            self.pop_n = 3 if p1 else 5
            self.pop_t = 0.3
        elif mv == "bsod":
            self.state = "bsod_t"
            self.timer = 1.0
        elif mv == "undo":
            self.state = "undo"
            self.timer = 2.6
            self.rec = (player.x, player.y)
            self.ping_t = 0.8
        else:
            self.state = "compile"
            self.cdur = 4.8 if p1 else 4.0
            self.timer = self.cdur
            self.prog = 0.0
            self.ping_t = 1.2

    def spawn_ping(self, toward=None):
        d = toward if toward is not None else (1 if self.cx < self.x0 + W / 2 else -1)
        air = random.random() < 0.3
        sp = 480.0 if self.phase == 1 else 620.0
        self.pkts.append({"x": self.cx + d * 60.0, "vx": d * sp, "air": air, "tr": []})
        self.muzzle = 0.2
        self.mz_x = self.cx + d * 60.0
        self.game.particles.burst(self.cx + d * 60.0, self.floor_y - (14 if not air else 110), 8,
                                  [(90, 255, 130), (200, 255, 220)], 260, 0.4, 5, 300, 0)

    def spawn_pop(self):
        if len(self.pops) >= 8:
            return
        a = random.uniform(0.5, 1.3) * random.choice((-1, 1))
        sp = 260.0 if self.phase == 1 else 330.0
        self.pops.append({"x": random.uniform(self.x0 + 100, self.x0 + W - 230), "y": 40.0,
                          "vx": sp * math.cos(a) * random.choice((-1, 1)), "vy": sp * 0.8,
                          "w": 130, "h": 84, "ttl": 7.5, "age": 0.0})

    def update(self, dt, player):
        g = self.game
        self.pl = player
        self.t += dt
        self.anim += dt
        self.flash = max(0.0, self.flash - dt)
        self.dmg_cd = max(0.0, self.dmg_cd - dt)
        self.bsod_t = max(0.0, self.bsod_t - dt)
        self.bsod_fx = max(0.0, self.bsod_fx - dt)
        st = self.state
        p1 = (self.phase == 1)

        if st == "intro":
            self.vy += 2600 * dt
            self.yo -= self.vy * dt
            if self.yo <= 0:
                self.yo = 0.0
                self.vy = 0.0
                self.state = "idle"
                self.timer = 1.4
                g.shake(22)
                g.particles.burst(self.cx, self.floor_y, 26, [(235, 245, 255), (150, 200, 250)],
                                  520, 0.8, 8, 900, 220)
        elif st == "idle":
            self.timer -= dt
            if self.timer <= 0:
                self.pick(player)
        elif st == "tab_out":                                 # ALT+TAB: some
            self.timer -= dt
            if self.timer <= 0:
                self.cx = self.tp_to
                g.particles.burst(self.cx, self.floor_y - 140, 16, [(120, 200, 255), (255, 255, 255)],
                                  300, 0.5, 6)
                self.state = "tab_in"
                self.timer = 0.3
        elif st == "tab_in":
            self.timer -= dt
            if self.timer <= 0:
                self.start_move(self.next_move, player)
        elif st == "ping":                                    # PING: sequencia de pacotes
            self.ping_t -= dt
            if self.ping_t <= 0 and self.ping_n > 0:
                self.spawn_ping()
                self.ping_n -= 1
                self.ping_t = 0.8 if p1 else 0.55
            if self.ping_n <= 0 and self.ping_t <= -1.0:
                self.state = "idle"
                self.timer = 1.0 if p1 else 0.7
        elif st == "popup":                                   # POP-UPS: janelas quicando
            self.pop_t -= dt
            if self.pop_t <= 0 and self.pop_n > 0:
                self.spawn_pop()
                self.pop_n -= 1
                self.pop_t = 0.55
            if self.pop_n <= 0 and self.pop_t <= -1.0:
                self.state = "idle"
                self.timer = 1.0 if p1 else 0.7
        elif st == "bsod_t":                                  # TELA AZUL: aviso
            self.timer -= dt
            self.bsod_fx = 0.2
            if self.timer <= 0:
                self.bsod_t = 4.0 if p1 else 5.0
                self.state = "bsod"
                self.timer = self.bsod_t
                self.ping_t = 0.4
                g.shake(14)
        elif st == "bsod":                                    # rajada de pings
            self.timer -= dt
            self.ping_t -= dt
            if self.ping_t <= 0 and self.timer > 0.6:
                self.spawn_ping()
                self.ping_t = 1.0 if p1 else 0.75
            if self.timer <= 0:
                self.state = "idle"
                self.timer = 1.0
        elif st == "undo":                                    # CTRL+Z: marca e depois volta o jogador
            self.timer -= dt
            self.ping_t -= dt
            if self.ping_t <= 0 and self.timer > 0.5:
                self.spawn_ping()
                self.ping_t = 0.9
            if self.timer <= 0:
                if self.rec is not None and not player.dead:
                    g.particles.burst(player.cx, player.y + 30, 14, [(120, 255, 255), (255, 255, 255)],
                                      320, 0.5, 6)
                    player.x, player.y = self.rec
                    player.vx = player.vy = 0.0
                    g.particles.burst(player.cx, player.y + 30, 14, [(120, 255, 255), (255, 255, 255)],
                                      320, 0.5, 6)
                    g.shake(8)
                self.rec = None
                self.state = "idle"
                self.timer = 1.0
        elif st == "compile":                                 # COMPILANDO: bata nele (DASH)!
            self.timer -= dt
            self.prog = clamp(1.0 - self.timer / self.cdur, 0.0, 1.0)
            self.ping_t -= dt
            if self.ping_t <= 0:
                self.spawn_ping(1 if player.cx >= self.cx else -1)
                self.ping_t = 1.3 if p1 else 1.0
            if self.timer <= 0:
                self.state = "deploy"
                self.timer = 2.6
                n = 7 if p1 else 10
                for i in range(n):
                    x = player.cx + random.uniform(-80, 80) if i == 0 else random.uniform(self.x0 + 80, self.x0 + W - 80)
                    self.rain.append({"x": clamp(x, self.x0 + 50, self.x0 + W - 50), "y": -60.0, "vy": 0.0,
                                      "delay": 0.7 + i * 0.2})
                g.shake(16)
        elif st == "deploy":
            self.timer -= dt
            if self.timer <= 0:
                self.state = "idle"
                self.timer = 1.0
        elif st == "crash":                                   # NAO RESPONDENDO: travado
            self.timer -= dt
            if self.timer <= 0:
                self.state = "idle"
                self.timer = 0.9
        elif st == "dying":
            self.timer -= dt
            self.boom_t -= dt
            if self.boom_t <= 0:
                self.boom_t = 0.07
                br = self.body_rect()
                x = random.randint(br.left, br.right)
                y = random.randint(br.top, br.bottom)
                g.particles.burst(x, y, 12, [(255, 255, 255), (255, 200, 80), (255, 110, 60),
                                             (120, 200, 255)], 380, 0.8, 8)
                g.shake(8)
            if self.timer <= 0:
                self.state = "dead"
                g.boss_defeated()

        tgt = self._anim_params()                             # suaviza a animacao do corpo
        if self.ap is None:
            self.ap = list(tgt)
        else:
            kk = min(1.0, dt * 18.0)
            self.ap = [a + (b - a) * kk for a, b in zip(self.ap, tgt)]
        self.muzzle = max(0.0, self.muzzle - dt)

        pl_rect = player.rect
        lo, hi = self.x0 - 60, self.x0 + W + 60

        # pacotes de ping
        keep = []
        for p in self.pkts:
            p["x"] += p["vx"] * dt
            trail_push(p["tr"], p["x"], self.floor_y - (14 if not p["air"] else 110), 9)
            if p["x"] < lo or p["x"] > hi:
                continue
            y = self.floor_y - (28 if not p["air"] else 124)
            r = pygame.Rect(int(p["x"] - 22), int(y), 44, 28)
            if not player.dead and r.colliderect(pl_rect):
                if player.attacking:
                    g.particles.burst(p["x"], y + 14, 8, [(120, 255, 150), (255, 255, 255)], 260, 0.4, 5)
                    continue
                if player.hurt(g, p["x"]):
                    continue
            keep.append(p)
        self.pkts = keep

        # janelas de erro quicando
        keep = []
        for w in self.pops:
            w["ttl"] -= dt
            w["age"] += dt
            w["x"] += w["vx"] * dt
            w["y"] += w["vy"] * dt
            if w["x"] < self.x0 + 8:
                w["x"] = self.x0 + 8.0
                w["vx"] = abs(w["vx"])
            elif w["x"] + w["w"] > self.x0 + W - 8:
                w["x"] = self.x0 + W - 8.0 - w["w"]
                w["vx"] = -abs(w["vx"])
            if w["y"] < 40:
                w["y"] = 40.0
                w["vy"] = abs(w["vy"])
            elif w["y"] + w["h"] > self.floor_y:
                w["y"] = self.floor_y - w["h"]
                w["vy"] = -abs(w["vy"])
            r = pygame.Rect(int(w["x"]), int(w["y"]), w["w"], w["h"])
            dead = w["ttl"] <= 0
            if not dead and not player.dead and r.colliderect(pl_rect):
                if player.attacking:
                    dead = True
                elif player.vy > 0 and pl_rect.bottom < r.top + 26:
                    dead = True
                    player.vy = -640.0
                else:
                    player.hurt(g, r.centerx)
            if dead:
                g.particles.burst(r.centerx, r.centery, 12, [(235, 235, 245), (60, 100, 220), (230, 60, 60)],
                                  320, 0.5, 6, 700, 100)
                continue
            keep.append(w)
        self.pops = keep

        # chuva de bugs (deploy)
        keep = []
        for b in self.rain:
            if b["delay"] > 0:
                b["delay"] -= dt
                keep.append(b)
                continue
            b["vy"] += 2200 * dt
            b["y"] += b["vy"] * dt
            if b["y"] + 36 >= self.floor_y:
                g.particles.burst(b["x"], self.floor_y - 4, 7, [(120, 255, 150), (30, 120, 40)], 240, 0.5, 5, 700, 100)
                continue
            r = pygame.Rect(int(b["x"] - 18), int(b["y"]), 36, 36)
            if not player.dead and r.colliderect(pl_rect) and player.hurt(g, b["x"]):
                continue
            keep.append(b)
        self.rain = keep

        # contato com o corpo
        if player.dead or self.state in ("dying", "dead"):
            return
        br = self.body_rect()
        if br.colliderect(pl_rect):
            if self.vulnerable:
                if player.attacking:
                    if self.hit(2):
                        player.end_dash(0)
                        player.vx = -player.dash_dir * 380.0
                        player.vy = -420.0
                        player.air_dash = True
                elif player.vy > 0 and pl_rect.bottom < br.top + 40:
                    if self.hit(1):
                        player.vy = -760.0
                        player.air_dash = True
            else:
                player.hurt(g, self.cx)

    # ---- animacao do corpo (sprite unico fatiado: pernas fixas, tronco e cabeca se mexem)
    def _anim_params(self):
        """(respiracao, largura, sway, inclinacao, aceno, pulo) conforme o golpe. Inclinacao em px (topo do corpo)."""
        t, st = self.t, self.state
        d = 1 if (self.pl is not None and self.pl.cx >= self.cx) else -1      # olha pro jogador
        br = math.sin(t * 3.2) * 0.018
        wd, sway, lean, nod, hop = 1.0, math.sin(t * 1.7) * 4, 0.0, (math.sin(t * 3.2) + 1) * 1.5, 0.0
        if st == "intro":                                     # caindo: esticado
            br, wd, sway, nod = 0.10, 0.94, 0.0, 0.0
        elif st == "tab_in":                                  # aparece: amassa e estica
            k = clamp(self.timer / 0.3, 0.0, 1.0)
            br, wd = -0.14 * k, 1.0 + 0.12 * k
        elif st in ("ping", "undo"):                          # digitando rapido, olhando pro jogador
            br = math.sin(t * 14) * 0.025
            lean = d * (9 + math.sin(t * 20) * 3)
            nod = abs(math.sin(t * 14)) * 7
            sway = math.sin(t * 5) * 3
            hop = abs(math.sin(t * 7)) * 3
        elif st == "popup":                                   # cabeca balancando (nervoso)
            br = math.sin(t * 9) * 0.02
            sway = math.sin(t * 9) * 7
            lean = math.sin(t * 9 + 1) * 8
            nod = abs(math.sin(t * 9)) * 5
        elif st == "bsod_t":                                  # tremendo antes da tela azul
            lean = math.sin(t * 46) * 8
            sway = math.sin(t * 38) * 4
            br = 0.03 + math.sin(t * 30) * 0.02
        elif st == "bsod":                                    # comemora: sobe e desce
            br = 0.05 + math.sin(t * 8) * 0.03
            lean = -d * 6 + math.sin(t * 6) * 7
            sway = math.sin(t * 6) * 6
            nod = 0.0
            hop = abs(math.sin(t * 6)) * 8
        elif st == "compile":                                 # sentado no notebook, digitando
            dn = -1 if self.cx > self.x0 + W / 2 else 1
            br, wd = -0.08 + math.sin(t * 16) * 0.012, 1.05
            lean = dn * 10 + math.sin(t * 22) * 2
            nod = abs(math.sin(t * 16)) * 6
            sway = 0.0
        elif st == "deploy":                                  # grita: estufa o peito
            br = 0.06 + math.sin(t * 25) * 0.02
            lean = -d * 8 + math.sin(t * 25) * 5
            nod = 0.0
            hop = abs(math.sin(t * 12)) * 6
        elif st == "idle":                                    # respira, balanca, olha pro jogador
            lean = d * 4
        return br, wd, sway, lean, nod, hop

    def _blit_anim(self, surf, body, x, bottom):
        S = self.S
        br, wd, sway, lean, nod, hop = self.ap if self.ap is not None else self._anim_params()
        if abs(wd - 1.0) > 0.001:
            body = pygame.transform.scale(body, (int(body.get_width() * wd), body.get_height()))
        bw, bh = body.get_size()
        waist = 30 * S                                        # daqui pra baixo: pernas (ficam no chao)
        head = 17 * S                                         # daqui pra cima: cabeca
        by = int(bottom - hop)
        legs = body.subsurface((0, waist, bw, bh - waist))
        surf.blit(legs, (x - bw // 2, by - legs.get_height()))
        up_h = max(S, int(waist * (1.0 + br)))
        upper = body.subsurface((0, 0, bw, waist))
        if up_h != waist:
            upper = pygame.transform.scale(upper, (bw, up_h))
        top_y = by - legs.get_height() - up_h
        hh = int(head * (1.0 + br))
        for pass_head in (False, True):                       # tronco primeiro, cabeca por cima
            y = 0
            while y < up_h:
                bh2 = min(S, up_h - y)
                is_head = y < hh
                if is_head == pass_head:
                    w = 1.0 - y / float(up_h)                 # quanto mais alto, mais balanca
                    ox = int((lean + sway) * w)
                    oy = int(nod) if is_head else 0
                    surf.blit(upper, (x - bw // 2 + ox, top_y + y + oy), (0, y, bw, bh2))
                y += bh2

    # ---- desenho
    def draw(self, surf, cam, camy, assets):
        if self.state == "dead":
            return
        S = self.S
        st = self.state
        h = 49 * S
        shake = 0
        if st in ("bsod_t", "deploy"):
            shake = random.randint(-3, 3)
        elif st == "dying":
            shake = random.randint(-8, 8)
        elif st == "crash":
            shake = random.randint(-5, 5)
        cx = self.cx + shake
        bottom = self.floor_y - self.yo

        body = assets.sprite("diogo", S)
        key = ("diogo_rage", S)
        if self.phase == 2:
            if key not in assets.cache:
                assets.cache[key] = add_flash(body, (45, 0, 0))
            body = assets.cache[key]
        if self.flash > 0 or (st == "dying" and int(self.t * 20) % 2 == 0):
            body = add_flash(body, (170, 170, 170))
        elif st == "deploy" and int(self.t * 16) % 2 == 0:
            body = add_flash(body, (140, 0, 0))
        elif st == "crash":
            body = add_flash(body, (0, 0, 70)) if int(self.t * 8) % 2 == 0 else body

        # marca do CTRL+Z
        if st == "undo" and self.rec is not None:
            rx, ry = int(self.rec[0] - cam), int(self.rec[1] - camy)
            pygame.draw.rect(surf, (120, 255, 255), (rx, ry, 40, 62), 3)
            draw_text(surf, assets.font_m, "%d" % (int(self.timer) + 1), rx + 20, ry - 36,
                      (120, 255, 255), center=True)
            draw_text(surf, assets.font_s, "CTRL+Z", rx + 20, ry - 62, (120, 255, 255), center=True)

        if st not in ("tab_out", "dying"):
            draw_shadow(surf, int(cx - cam), self.floor_y - camy - 2, 150, clamp(1.0 - self.yo / 500.0, 0.0, 1.0))
        if st in ("tab_out", "tab_in"):                          # clarao do ALT+TAB
            kk = clamp(self.timer / 0.3, 0.0, 1.0)
            draw_glow(surf, int(cx - cam), int(bottom - h / 2 - camy), 170, (60, 150, 255), 0.35 + 0.5 * (kk if st == "tab_out" else 1 - kk))
        visible = not (st in ("tab_out", "tab_in") and int(self.t * 30) % 2 == 0)
        if visible:
            img = body
            if st not in ("crash", "dying"):
                self._blit_anim(surf, body, int(cx - cam), int(bottom - camy))
            elif st == "crash":
                img = pygame.transform.rotate(body, math.sin(self.t * 9) * 7)
            elif st == "dying":
                img = pygame.transform.rotate(body, math.sin(self.t * 30) * 10)
            if st in ("crash", "dying"):
                surf.blit(img, (int(cx - cam - img.get_width() / 2),
                                int(bottom - h / 2 - img.get_height() / 2 - camy)))

        # notebook + barra de COMPILANDO
        top = bottom - h
        if st in ("compile", "crash"):
            d = -1 if self.cx > self.x0 + W / 2 else 1
            lx = int(cx - cam + d * 80)
            ly = int(self.floor_y - camy)
            scr = (40, 120, 255) if st == "compile" else (230, 50, 50)
            draw_glow(surf, lx, ly - 34, 86, scr, 0.55 + 0.15 * math.sin(self.t * 12))
            pygame.draw.rect(surf, (70, 75, 90), (lx - 40, ly - 8, 80, 8), border_radius=2)
            pygame.draw.rect(surf, (110, 118, 135), (lx - 40, ly - 8, 80, 2))
            pygame.draw.rect(surf, (30, 35, 50), (lx - 32, ly - 54, 64, 46), border_radius=3)
            pygame.draw.rect(surf, scr, (lx - 28, ly - 50, 56, 38))
            if st == "compile":                                   # linhas de codigo rolando na tela
                for r in range(4):
                    ww = 10 + ((int(self.t * 22) + r * 9) % 34)
                    pygame.draw.rect(surf, (200, 230, 255), (lx - 24, ly - 46 + r * 8, ww, 3))
            elif int(self.t * 6) % 2 == 0:
                pygame.draw.line(surf, (255, 255, 255), (lx - 14, ly - 40), (lx + 14, ly - 16), 3)
                pygame.draw.line(surf, (255, 255, 255), (lx + 14, ly - 40), (lx - 14, ly - 16), 3)
        if st == "compile":
            bw = 180
            bx = int(cx - cam - bw / 2)
            by = int(top - 40 - camy)
            pygame.draw.rect(surf, (10, 14, 40), (bx - 3, by - 3, bw + 6, 22), border_radius=4)
            pygame.draw.rect(surf, (40, 60, 110), (bx, by, bw, 16), border_radius=3)
            fw = int(bw * self.prog)
            if fw > 0:
                col = (90, 220, 120) if self.prog < 0.7 else (255, 200, 70) if self.prog < 0.9 else (255, 80, 80)
                pygame.draw.rect(surf, col, (bx, by, fw, 16), border_radius=3)
            draw_text(surf, assets.font_s, "COMPILANDO... %d%%" % int(self.prog * 100), int(cx - cam),
                      by - 30, (200, 235, 255), center=True)
        elif st == "crash":
            if int(self.t * 5) % 2 == 0:
                draw_text(surf, assets.font_m, "NÃO RESPONDENDO", int(cx - cam), int(top - 44 - camy),
                          (255, 110, 120), center=True)
        elif st == "deploy":
            draw_text(surf, assets.font_m, "DEPLOY!!!", int(cx - cam), int(top - 44 - camy),
                      (255, 110, 120), center=True)

        if self.vulnerable:
            for i in range(4):
                a = self.t * 5 + i * math.tau / 4
                sx = cx + math.cos(a) * 70 - cam
                sy = top + 8 + math.sin(a) * 14 - camy
                pygame.draw.polygon(surf, (255, 225, 80), [
                    (sx, sy - 9), (sx + 4, sy - 2), (sx + 10, sy), (sx + 4, sy + 3),
                    (sx, sy + 10), (sx - 4, sy + 3), (sx - 10, sy), (sx - 4, sy - 2)])

        # brilho nas maos ao mandar um ping
        if self.muzzle > 0.01:
            draw_glow(surf, int(self.mz_x - cam), int(self.floor_y - 60 - camy), 70, (90, 255, 140), min(1.0, self.muzzle * 5))
        # pacotes de ping: capsulas de dados com setas, brilho e rastro
        for p in self.pkts:
            y = int(self.floor_y - (28 if not p["air"] else 124) - camy)
            x = int(p["x"] - cam)
            cy = y + 14
            dd = 1 if p["vx"] >= 0 else -1
            draw_trail(surf, p["tr"], cam, camy, (60, 255, 140), 17)
            draw_glow(surf, x, cy, 46, (50, 230, 120), 0.7 + 0.2 * math.sin(self.t * 16))
            pygame.draw.rect(surf, (8, 36, 22), (x - 22, y, 44, 28), border_radius=6)
            pygame.draw.rect(surf, (90, 255, 130), (x - 22, y, 44, 28), 2, border_radius=6)
            for k in range(3):
                ph = (self.t * 6 + k * 0.33) % 1.0
                col = (int(60 + 150 * (1 - ph)), 255, int(110 + 120 * (1 - ph)))
                cxk = x + dd * (k * 10 - 10)
                pygame.draw.lines(surf, col, False, [(cxk - 3 * dd, cy - 7), (cxk + 3 * dd, cy), (cxk - 3 * dd, cy + 7)], 2)
        # janelas de erro: surgem com "pop", brilham e tem sombra
        for w in self.pops:
            k = ease_out_back(clamp(w["age"] / 0.22, 0.0, 1.0))
            if w["ttl"] < 0.6 and int(self.t * 20) % 2 == 0:
                continue
            ww, hh = max(8, int(w["w"] * k)), max(6, int(w["h"] * k))
            x = int(w["x"] - cam + (w["w"] - ww) / 2)
            y = int(w["y"] - camy + (w["h"] - hh) / 2)
            draw_glow(surf, x + ww // 2, y + hh // 2, 96, (255, 60, 70), 0.3 + 0.15 * math.sin(self.t * 10))
            pygame.draw.rect(surf, (10, 14, 40), (x + 6, y + 7, ww, hh), border_radius=4)
            pygame.draw.rect(surf, (225, 225, 235), (x, y, ww, hh), border_radius=4)
            pygame.draw.rect(surf, (30, 70, 170), (x, y, ww, min(20, hh)), border_top_left_radius=4, border_top_right_radius=4)
            pygame.draw.rect(surf, (80, 130, 230), (x, y, ww, 4), border_top_left_radius=4, border_top_right_radius=4)
            if ww > 60:
                pygame.draw.rect(surf, (230, 60, 60) if int(self.t * 4 + w["x"]) % 2 == 0 else (255, 120, 120),
                                 (x + ww - 18, y + 3, 14, 14), border_radius=2)
                pygame.draw.line(surf, (255, 255, 255), (x + ww - 15, y + 6), (x + ww - 8, y + 13), 2)
                pygame.draw.line(surf, (255, 255, 255), (x + ww - 8, y + 6), (x + ww - 15, y + 13), 2)
            pygame.draw.rect(surf, (20, 20, 30), (x, y, ww, hh), 2, border_radius=4)
            if k > 0.9:
                pygame.draw.circle(surf, (210, 40, 40), (x + 22, y + 52), 12)
                draw_text(surf, assets.font_s, "!", x + 22, y + 42, (255, 255, 255), center=True)
                draw_text(surf, assets.font_s, "ERRO 404", x + ww // 2 + 14, y + 36, (200, 30, 30), center=True,
                          shadow=(235, 235, 245))
        # bugs do deploy: besouros brilhantes com patinhas se mexendo
        for b in self.rain:
            x = int(b["x"] - cam)
            if b["delay"] > 0:
                k = 0.5 + 0.5 * math.sin(self.t * 24)
                yy = int(self.floor_y - camy)
                draw_glow(surf, x, yy - 8, 50, (255, 60, 80), 0.35 + 0.4 * k)
                if k > 0.25:
                    pygame.draw.polygon(surf, (255, 90, 110), [(x - 14, yy - 4), (x + 14, yy - 4), (x, yy - 26)])
                    pygame.draw.polygon(surf, (255, 220, 225), [(x - 4, yy - 8), (x + 4, yy - 8), (x, yy - 20)])
            else:
                y = int(b["y"] - camy)
                for j in range(1, 4):
                    draw_glow(surf, x, y + 8 - j * 20, 16, (60, 255, 120), 0.45 - j * 0.1)
                draw_glow(surf, x, y + 20, 38, (60, 255, 120), 0.6)
                pygame.draw.ellipse(surf, (30, 120, 40), (x - 16, y + 6, 32, 26))
                pygame.draw.ellipse(surf, (120, 255, 150), (x - 10, y + 10, 20, 12))
                pygame.draw.rect(surf, (255, 60, 60), (x - 8, y + 12, 4, 4))
                pygame.draw.rect(surf, (255, 60, 60), (x + 4, y + 12, 4, 4))
                for ki, kx in enumerate((-14, 0, 14)):
                    wig = int(math.sin(self.t * 30 + ki * 2.1) * 3)
                    pygame.draw.line(surf, (10, 50, 20), (x + kx, y + 28), (x + int(kx * 1.3) + wig, y + 36), 3)

        # TELA AZUL
        if self.bsod_fx > 0:
            ov = pygame.Surface((W, H))
            ov.fill((0, 60, 190))
            ov.set_alpha(150 if int(self.t * 20) % 2 == 0 else 70)
            surf.blit(ov, (0, 0))
            draw_text(surf, assets.font_l, ":(  TELA AZUL", W // 2, H // 2 - 40, (255, 255, 255), center=True)


Cara = Diogo                                                 # nome antigo (o chefe final do Mundo 2 agora e o DIOGO)


# ---------------------------------------------------------------- chefe final do Mundo 3: FILIPE + GOLEM NEGRO
class GolemNegro(Golem):
    """O CRIO-GOLEM recolorido (preto com detalhes vermelhos) que ALIMENTA o escudo do Filipe.
    O dash nao machuca. A unica forma de derruba-lo e PISAR NA CABECA: ele fica tonto e o escudo cai."""
    name = "GOLEM NEGRO"
    S = 3
    KEEP = 215.0
    SPD1, SPD2 = 120.0, 185.0
    SPR_BODY, SPR_OPEN, SPR_ARM = "golem_negro_corpo", "golem_negro_corpo_aberto", "golem_negro_braco"
    SPR_BALL, SPR_SHARD = "golem_negro_bola", "golem_negro_estilhaco"
    FX_ICE = (255, 70, 60)
    WAVE_COLS = ((255, 60, 50), (200, 30, 40), (40, 30, 40), (200, 36, 48), (255, 120, 110), (255, 90, 80))
    STUN1, STUN2 = 5.0, 4.2          # tempo tonto depois do pisao (fase 1 / fase 2)

    def __init__(self, game, x0, filipe):
        Golem.__init__(self, game, x0)
        self.filipe = filipe
        self.cx = x0 + W * 0.5
        self.clank = 0.0

    def bounds(self):
        m = 57.5 * self.S
        lo, hi = self.x0 + m, self.x0 + W - m
        f = self.filipe
        if f is not None and f.state != "dead":
            gap = 215.0                                     # nao entra no Filipe
            if f.cx > self.x0 + W / 2:
                hi = min(hi, f.cx - gap)
            else:
                lo = max(lo, f.cx + gap)
        return lo, hi

    def after_slam(self):
        self.state = "walk"                                 # a pancada nao deixa ele tonto: so o pisao
        self.timer = 1.1 if self.phase == 1 else 0.8

    def set_phase2(self):
        self.phase = 2
        self.pattern = ["throw", "rain", "slam"]

    def top_y(self):
        return self.floor_y - 86 * self.S - self.yo

    def stomp_zone(self):
        """Cabeca e ombros (onde o pisao vale)."""
        S = self.S
        return pygame.Rect(int(self.cx - 40 * S), int(self.top_y() - 14), int(80 * S), int(24 * S + 14))

    def stun(self):
        self.state = "stunned"
        self.timer = self.STUN1 if self.phase == 1 else self.STUN2
        self.arm = 0.0
        self.balls, self.shards, self.waves = [], [], []

    def update(self, dt, player):
        Golem.update(self, dt, player)
        self.clank = max(0.0, self.clank - dt)
        if self.state != "intro":
            lo, hi = self.bounds()                          # desliza pra fora do caminho se o Filipe trocou de lado
            self.cx = approach(self.cx, clamp(self.cx, lo, hi), 650.0 * dt)

    def contact(self, player, pl_rect):
        g = self.game
        if player.dead or self.state in ("dying", "dead", "intro"):
            return
        S = self.S
        top = self.top_y()
        on_top = (player.vy > 0 and not player.attacking and pl_rect.colliderect(self.stomp_zone())
                  and pl_rect.bottom <= top + 26 * S)
        if on_top:
            if self.state == "stunned":                     # ja esta tonto: so quica
                player.vy = -700.0
                player.air_dash = True
                return
            player.vy = -820.0                              # PISAO NA CABECA!
            player.air_dash = True
            self.stun()
            self.qv = -6.0
            g.shake(22)
            g.particles.burst(self.cx, top + 20, 32, [(255, 255, 255), (255, 80, 70), (255, 200, 120), (70, 70, 80)],
                              520, 0.8, 8)
            self.filipe.on_stomp()
            return
        if self.state == "stunned":
            return                                          # tonto: nao machuca
        if self.body_rect().colliderect(pl_rect):
            if player.attacking:                            # dash nao machuca o golem: "clank"
                if self.clank <= 0:
                    self.clank = 0.35
                    d = sign(player.cx - self.cx) or 1
                    player.end_dash(0)
                    player.vx = d * 380.0
                    player.vy = -380.0
                    player.air_dash = True
                    g.shake(6)
                    g.particles.burst(player.cx, player.y + 20, 10,
                                      [(255, 255, 255), (255, 90, 80), (255, 200, 120)], 360, 0.4, 5)
            else:
                player.hurt(g, self.cx)


class Filipe(object):
    """FILIPE, o cientista (chefe final do Mundo 3). Ele fica atras de um ESCUDO alimentado pelo GOLEM NEGRO
    (o ultimo chefe do Mundo 1, so que preto com detalhes vermelhos) e joga frascos de residuo toxico.
    - O escudo NAO deixa passar nem o dash. Pise na CABECA do golem (use os trampolins) para derruba-lo:
      ele fica tonto, o escudo cai e o Filipe entra em panico.
    - Enquanto o golem esta tonto, corra ate o Filipe e ataque: DASH (J) = 2 de dano, pisao na cabeca = 1.
    - Quando o golem acorda o escudo volta e o Filipe teleporta para o canto oposto ao seu.
    - Fase 2 (vida <= 6): mais frascos, golem mais rapido e com chuva de estalactites."""
    name = "FILIPE"
    S = 3
    SH_RX, SH_RY = 118, 150          # escudo: meia elipse

    def __init__(self, game, x0):
        self.game = game
        self.x0 = x0
        self.floor_y = float(H - 3 * T)
        self.hp = self.max_hp = 12
        self.state = "intro"
        self.t = 0.0
        self.anim = 0.0
        self.flash = 0.0
        self.dmg_cd = 0.0
        self.stagger = 0.0
        self.phase = 1
        self.cx = x0 + W - 150.0
        self.face = -1
        self.timer = 0.0
        self.atk_t = 2.6
        self.n_flasks = 1
        self.flasks, self.puddles = [], []
        self.shield = 0.0
        self.was_exposed = False
        self.boom_t = 0.0
        self.shield_cd = 0.0
        self.hint_t = 9.0
        self.q, self.qv = 0.0, 0.0
        self.new_cx = self.cx
        self.golem = GolemNegro(game, x0, self)
        game.particles.burst(self.cx, self.floor_y - 80, 26, [(150, 255, 90), (220, 255, 160), (90, 200, 60)],
                             360, 0.9, 8, 200, 120)

    # ---- estado
    @property
    def exposed(self):
        return self.golem.state == "stunned" and self.state not in ("intro", "dying", "dead", "tp_out", "tp_in")

    @property
    def vulnerable(self):
        return self.exposed

    def body_rect(self):
        h = 67 * self.S
        return pygame.Rect(int(self.cx - 14 * self.S), int(self.floor_y - h + 4 * self.S), int(28 * self.S),
                           int(h - 4 * self.S))

    def on_stomp(self):
        """O golem foi pisado na cabeca: escudo cai, Filipe entra em panico."""
        g = self.game
        self.atk_t = min(self.atk_t, 0.8)
        g.particles.burst(self.cx, self.floor_y - 120, 30, [(255, 120, 110), (255, 255, 255), (150, 255, 90)],
                          460, 0.8, 7)
        g.shake(14)

    def hit(self, dmg):
        if self.dmg_cd > 0 or not self.vulnerable:
            return False
        g = self.game
        self.hp -= dmg
        self.dmg_cd = 0.5
        self.flash = 0.25
        self.stagger = 0.5
        self.qv = -6.0
        g.shake(14)
        br = self.body_rect()
        g.particles.burst(br.centerx, br.centery - 20, 18, [(255, 255, 255), (150, 255, 90), (255, 210, 90)],
                          440, 0.7, 7)
        if self.hp <= 0:
            self.hp = 0
            self.state = "dying"
            self.timer = 2.8
            self.flasks, self.puddles = [], []
            gl = self.golem
            gl.state, gl.timer = "stunned", 99.0             # o golem desliga junto com o escudo
            gl.balls, gl.shards, gl.waves = [], [], []
            g.shake(20)
            return True
        self.golem.timer = min(self.golem.timer, 1.6)        # a janela fecha logo depois do golpe
        if self.phase == 1 and self.hp <= self.max_hp // 2:
            self.phase = 2
            self.n_flasks = 2
            self.golem.set_phase2()
            g.shake(16)
        return True

    # ---- golpes
    def throw(self, player, spread=0.0):
        d = 1 if player.cx >= self.cx else -1
        bx = self.cx + d * 40
        by = self.floor_y - 67 * self.S * 0.7
        tx = player.cx + spread
        vx = clamp((tx - bx) / 0.95, -620.0, 620.0)
        self.flasks.append({"x": bx, "y": by, "vx": vx, "vy": -520.0, "rot": 0.0, "tr": [], "age": 0.0})
        self.game.particles.burst(bx, by, 8, [(150, 255, 90), (220, 255, 160)], 240, 0.4, 5, 300, 0)

    def begin_tp(self, player):
        mid = self.x0 + W / 2
        side = 1 if player.cx < mid else -1                  # canto mais longe do jogador
        self.new_cx = self.x0 + W - 150.0 if side > 0 else self.x0 + 150.0
        if abs(self.new_cx - self.cx) > 100:
            self.state = "tp_out"
            self.timer = 0.3

    def update(self, dt, player):
        g = self.game
        self.t += dt
        self.anim += dt
        self.flash = max(0.0, self.flash - dt)
        self.dmg_cd = max(0.0, self.dmg_cd - dt)
        self.stagger = max(0.0, self.stagger - dt)
        self.shield_cd = max(0.0, self.shield_cd - dt)
        self.hint_t = max(0.0, self.hint_t - dt) if self.state != "intro" else self.hint_t
        self.q, self.qv = spring(self.q, self.qv, 0.0, dt)
        st = self.state
        gol = self.golem
        if self.t > 1.0:
            gol.update(dt, player)
        exposed = self.exposed
        if exposed and not self.was_exposed:                  # escudo quebrou
            g.particles.burst(self.cx, self.floor_y - 90, 26,
                              [(255, 120, 110), (255, 255, 255), (255, 60, 60)], 480, 0.8, 7)
        if self.was_exposed and not exposed and st not in ("dying", "dead"):
            self.was_exposed = False
            self.begin_tp(player)                             # janela fechou: escudo volta e ele troca de canto
        self.was_exposed = exposed
        st = self.state
        if st not in ("tp_out", "tp_in", "dying", "dead"):
            self.face = 1 if player.cx >= self.cx else -1

        tgt = 1.0
        if exposed or st in ("intro", "dying", "dead") or gol.state == "intro" or self.t <= 1.0:
            tgt = 0.0
        self.shield = approach(self.shield, tgt, dt * (4.0 if tgt else 7.0))

        if st == "intro":
            if self.t >= 1.0:
                self.state = "idle"
        elif st == "idle":
            self.atk_t -= dt
            if self.atk_t <= 0 and gol.state != "intro":
                self.state = "throw"
                self.timer = 0.45
        elif st == "throw":
            self.timer -= dt
            if self.timer <= 0:
                n = self.n_flasks if not exposed else 1
                for i in range(n):
                    self.throw(player, (i - (n - 1) / 2.0) * 170.0 if n > 1 else 0.0)
                self.qv = 3.0
                self.state = "idle"
                if exposed:
                    self.atk_t = 1.1
                else:
                    self.atk_t = 2.4 if self.phase == 1 else 1.8
        elif st == "tp_out":
            self.timer -= dt
            if self.timer <= 0:
                g.particles.burst(self.cx, self.floor_y - 90, 24, [(150, 255, 90), (220, 255, 160), (90, 200, 60)],
                                  360, 0.7, 7, 200, 100)
                self.cx = self.new_cx
                self.state = "tp_in"
                self.timer = 0.3
                g.particles.burst(self.cx, self.floor_y - 90, 24, [(150, 255, 90), (220, 255, 160), (90, 200, 60)],
                                  360, 0.7, 7, 200, 100)
        elif st == "tp_in":
            self.timer -= dt
            if self.timer <= 0:
                self.state = "idle"
                self.atk_t = max(self.atk_t, 1.4)
        elif st == "dying":
            self.timer -= dt
            self.boom_t -= dt
            if self.boom_t <= 0:
                self.boom_t = 0.07
                br = self.body_rect()
                x = random.randint(br.left - 60, br.right + 60)
                y = random.randint(br.top, br.bottom)
                g.particles.burst(x, y, 12, [(255, 255, 255), (150, 255, 90), (255, 110, 60), (255, 60, 60)],
                                  380, 0.8, 8)
                gb = gol.body_rect()
                g.particles.burst(random.randint(gb.left, gb.right), random.randint(gb.top, gb.bottom), 8,
                                  [(255, 255, 255), (255, 90, 70), (255, 200, 120)], 340, 0.7, 7)
                g.shake(8)
            if self.timer <= 0:
                self.state = "dead"
                g.boss_defeated()
                return

        pl_rect = player.rect
        # frascos (arco ate o jogador; quebram no chao e deixam POCA toxica)
        keep = []
        for f in self.flasks:
            f["vy"] += 1500 * dt
            f["x"] += f["vx"] * dt
            f["y"] += f["vy"] * dt
            f["rot"] += f["vx"] * dt * 0.03
            f["age"] += dt
            trail_push(f["tr"], f["x"], f["y"], 8)
            if f["x"] < self.x0 + 10 or f["x"] > self.x0 + W - 10:
                g.particles.burst(f["x"], f["y"], 8, [(150, 255, 90), (220, 255, 160)], 260, 0.5, 5)
                continue
            if f["y"] >= self.floor_y - 16 and f["vy"] > 0:
                g.particles.burst(f["x"], self.floor_y - 6, 14, [(150, 255, 90), (220, 255, 160), (90, 200, 60)],
                                  300, 0.6, 6, 700, 160)
                g.shake(3)
                if len(self.puddles) >= 5:
                    del self.puddles[0]
                self.puddles.append({"x": f["x"], "t": 0.0, "ttl": 4.5 if self.phase == 1 else 6.0})
                continue
            fr = pygame.Rect(int(f["x"] - 15), int(f["y"] - 15), 30, 30)
            if not player.dead and fr.colliderect(pl_rect):
                if player.hurt(g, f["x"]):
                    g.particles.burst(f["x"], f["y"], 12, [(150, 255, 90), (220, 255, 160)], 320, 0.5, 6)
                    continue
            keep.append(f)
        self.flasks = keep
        keep = []
        for pd in self.puddles:
            pd["t"] += dt
            if pd["t"] >= pd["ttl"]:
                continue
            if random.random() < dt * 5:
                g.particles.add(pd["x"] + random.uniform(-40, 40), self.floor_y - 8, random.uniform(-10, 10),
                                random.uniform(-90, -40), 0.7, (150, 255, 90), 4, -60)
            pr = pygame.Rect(int(pd["x"] - 55), int(self.floor_y - 22), 110, 22)
            if not player.dead and pr.colliderect(pl_rect):
                player.hurt(g, pd["x"])
            keep.append(pd)
        self.puddles = keep

        if player.dead or self.state in ("dying", "dead"):
            return
        # escudo: nao deixa passar (nem o dash). Repele sem machucar.
        if self.shield > 0.5:
            rx, ry = self.SH_RX + player.w / 2.0, self.SH_RY + player.h / 2.0
            ex = (player.cx - self.cx) / rx
            ey = (player.y + player.h / 2.0 - self.floor_y) / ry
            if ex * ex + ey * ey < 1.0 and player.y + player.h / 2.0 < self.floor_y + 30:
                d = -1 if self.cx > self.x0 + W / 2 else 1
                if player.attacking:
                    player.end_dash(0)
                player.x = self.cx + d * (self.SH_RX + player.w / 2.0 + 2) - player.w / 2.0
                player.vx = d * 380.0
                player.vy = min(player.vy, -220.0)
                if self.shield_cd <= 0:
                    self.shield_cd = 0.4
                    g.shake(5)
                    g.particles.burst(self.cx + d * self.SH_RX * 0.9, player.y + 20, 12,
                                      [(255, 120, 110), (255, 255, 255), (255, 60, 60)], 380, 0.5, 5)
        # golpes no Filipe (so com o escudo caido)
        if self.exposed:
            br = self.body_rect()
            if br.colliderect(pl_rect):
                if player.attacking:
                    if self.hit(2):
                        player.end_dash(0)
                        player.vx = -player.dash_dir * 380.0
                        player.vy = -420.0
                        player.air_dash = True
                elif player.vy > 0 and pl_rect.bottom < br.top + 40:
                    if self.hit(1):
                        player.vy = -760.0
                        player.air_dash = True

    # ---- desenho
    def _flask_img(self, assets, ang):
        qa = int((ang % 360.0) // 15)
        key = ("filipe_flask", qa)
        img = assets.cache.get(key)
        if img is None:
            base = pygame.Surface((26, 50), pygame.SRCALPHA)
            pygame.draw.rect(base, (150, 175, 195), (6, 4, 14, 42), border_radius=5)
            pygame.draw.rect(base, (90, 255, 40), (8, 18, 10, 26), border_radius=4)
            pygame.draw.rect(base, (215, 255, 140), (9, 19, 3, 22))
            pygame.draw.rect(base, (120, 140, 160), (3, 2, 20, 6), border_radius=2)
            pygame.draw.rect(base, (20, 30, 50), (6, 4, 14, 42), 2, border_radius=5)
            img = pygame.transform.rotate(base, qa * 15)
            assets.cache[key] = img
        return img

    def _dome(self, assets):
        key = ("filipe_dome", self.SH_RX, self.SH_RY)
        s = assets.cache.get(key)
        if s is None:
            rx, ry = self.SH_RX, self.SH_RY
            s = pygame.Surface((2 * rx + 8, ry + 8), pygame.SRCALPHA)
            pygame.draw.ellipse(s, (255, 70, 80, 44), (4, 4, 2 * rx, 2 * ry))
            for k in (0.72, 0.44):                                        # aneis internos (grade do escudo)
                pygame.draw.ellipse(s, (255, 110, 120, 70), (4 + int(rx * (1 - k)), 4 + int(ry * (1 - k)),
                                                              int(2 * rx * k), int(2 * ry * k)), 1)
            for k in (-0.5, 0.0, 0.5):
                pygame.draw.line(s, (255, 110, 120, 60), (4 + rx + int(rx * k), 6 + int(ry * (1 - math.sqrt(max(0.0, 1 - k * k))))),
                                 (4 + rx + int(rx * k), 4 + ry), 1)
            pygame.draw.ellipse(s, (255, 130, 140, 215), (4, 4, 2 * rx, 2 * ry), 3)
            assets.cache[key] = s
        return s

    def draw(self, surf, cam, camy, assets):
        st = self.state
        if st == "dead":
            return
        S = self.S
        gl = self.golem
        # poças toxicas (no chao, atras de tudo)
        for pd in self.puddles:
            k = 1.0 - max(0.0, pd["t"] - (pd["ttl"] - 0.8)) / 0.8 if pd["t"] > pd["ttl"] - 0.8 else 1.0
            x = int(pd["x"] - cam)
            y = int(self.floor_y - camy)
            wob = 3 * math.sin(self.t * 6 + pd["x"])
            draw_glow(surf, x, y - 8, 76, (110, 255, 60), 0.5 * k)
            pygame.draw.ellipse(surf, (30, 110, 30), (x - 56, y - 16, 112, 18))
            pygame.draw.ellipse(surf, (110, 255, 60), (x - 46, int(y - 14 + wob * 0.3), 92, 11))
            pygame.draw.ellipse(surf, (210, 255, 150), (x - 26, y - 12, 34, 5))
        # golem negro (atras do Filipe)
        if self.t > 1.0:
            gl.draw(surf, cam, camy, assets)
        # energia que liga o golem ao escudo
        if self.shield > 0.4 and gl.state not in ("intro", "stunned"):
            gx = gl.cx - cam
            gy = self.floor_y - 60 * S - camy
            fx_ = self.cx - cam - (1 if self.cx > self.x0 + W / 2 else -1) * self.SH_RX * 0.8
            fy_ = self.floor_y - 70 - camy
            rng = random.Random(int(self.t * 18))
            pts = [(gx, gy)]
            for i in range(1, 8):
                f_ = i / 8.0
                pts.append((gx + (fx_ - gx) * f_ + rng.uniform(-10, 10), gy + (fy_ - gy) * f_ + rng.uniform(-14, 14)))
            pts.append((fx_, fy_))
            draw_glow(surf, gx, gy, 46, (255, 60, 50), 0.6 * self.shield)
            pygame.draw.lines(surf, (255, 70, 60), False, pts, 5)
            pygame.draw.lines(surf, (255, 220, 200), False, pts, 2)
        # Filipe
        h = 67 * S
        shake = 0
        if st == "dying":
            shake = random.randint(-8, 8)
        elif self.exposed:
            shake = random.randint(-2, 2)
        elif st == "throw":
            shake = random.randint(-1, 1)
        img = assets.sprite("filipe", S)
        if self.face < 0:
            kf = ("filipe_flip", S)
            if kf not in assets.cache:
                assets.cache[kf] = pygame.transform.flip(img, True, False)
            img = assets.cache[kf]
        if self.flash > 0 or (st == "dying" and int(self.t * 20) % 2 == 0):
            img = add_flash(img, (170, 170, 170))
        bw, bh = img.get_size()
        sw, sh = max(2, int(bw * (1.0 - 0.4 * self.q))), max(2, int(bh * (1.0 + self.q)))
        if (sw, sh) != (bw, bh):
            img = pygame.transform.scale(img, (sw, sh))
        if st in ("tp_out", "tp_in"):
            a = int(255 * (clamp(self.timer / 0.3, 0.0, 1.0) if st == "tp_out" else 1.0 - clamp(self.timer / 0.3, 0.0, 1.0)))
            img = img.copy()
            img.set_alpha(a)
        elif st == "intro":
            img = img.copy()
            img.set_alpha(int(255 * clamp(self.t / 0.8, 0.0, 1.0)))
        bob = int(math.sin(self.anim * 3.0) * 2) if st in ("idle", "throw") else 0
        bx = int(self.cx - cam - sw / 2.0) + shake
        by = int(self.floor_y - sh - camy) + bob
        draw_shadow(surf, int(self.cx - cam), self.floor_y - camy - 2, 120, 1.0 if st != "intro" else clamp(self.t, 0.0, 1.0))
        surf.blit(img, (bx, by))
        # brilho do frasco na mao + bolhinhas
        if st not in ("tp_out", "tp_in", "dying"):
            px_ = 26 if self.face > 0 else 5
            gx_ = bx + int((px_ + 0.5) * S)
            gy_ = by + int(17 * S * (sh / float(bh)))
            draw_glow(surf, gx_, gy_, 40 + int(5 * math.sin(self.t * 7)), (110, 255, 60), 0.55)
            if random.random() < 0.25:
                self.game.particles.add(gx_ + cam + random.uniform(-10, 10), gy_ + camy - 20, 0, -60, 0.8,
                                        (150, 255, 90), 4, 0)
        # panico (escudo caido): estrelinhas + exclamacao
        if self.exposed:
            for i in range(4):
                a = self.t * 5 + i * math.tau / 4
                sx = self.cx + math.cos(a) * 62 - cam
                sy = self.floor_y - h + 6 + math.sin(a) * 12 - camy
                pygame.draw.polygon(surf, (255, 225, 80), [
                    (sx, sy - 9), (sx + 4, sy - 2), (sx + 10, sy), (sx + 4, sy + 3),
                    (sx, sy + 10), (sx - 4, sy + 3), (sx - 10, sy), (sx - 4, sy - 2)])
            if int(self.t * 6) % 2 == 0:
                draw_text(surf, assets.font_m, "!", int(self.cx - cam), int(self.floor_y - h - 50 - camy),
                          (255, 230, 90), center=True)
        # escudo (meia elipse com grade)
        if self.shield > 0.02:
            dome = self._dome(assets)
            dome.set_alpha(int(255 * self.shield * (0.78 + 0.22 * math.sin(self.t * 6))))
            surf.blit(dome, (int(self.cx - cam - self.SH_RX - 4), int(self.floor_y - self.SH_RY - 4 - camy)))
            draw_glow(surf, int(self.cx - cam), int(self.floor_y - 70 - camy), 150, (255, 50, 60), 0.18 * self.shield)
        # frascos no ar
        for f in self.flasks:
            fx_, fy_ = int(f["x"] - cam), int(f["y"] - camy)
            draw_trail(surf, f["tr"], cam, camy, (110, 255, 60), 16)
            draw_glow(surf, fx_, fy_, 46, (110, 255, 60), 0.7)
            fi = self._flask_img(assets, -math.degrees(f["rot"]))
            surf.blit(fi, (fx_ - fi.get_width() // 2, fy_ - fi.get_height() // 2))
        # dicas
        if self.hint_t > 0 and st not in ("dying", "dead") and not self.exposed and self.t > 1.5:
            top = gl.top_y()
            if gl.state not in ("intro", "stunned"):
                ay = int(top - 44 - camy + 6 * math.sin(self.t * 6))
                ax = int(gl.cx - cam)
                pygame.draw.polygon(surf, (255, 70, 60), [(ax - 16, ay), (ax + 16, ay), (ax, ay + 22)])
                pygame.draw.polygon(surf, (255, 220, 210), [(ax - 8, ay + 3), (ax + 8, ay + 3), (ax, ay + 14)])
            if int(self.t * 2) % 2 == 0 or self.hint_t > 6:
                draw_text(surf, assets.font_s, "PISE NA CABEÇA DO GOLEM (USE OS TRAMPOLINS) PARA QUEBRAR O ESCUDO",
                          W // 2, 122, (255, 225, 220), center=True)
        elif self.exposed:
            draw_text(surf, assets.font_s, "ESCUDO CAIU!  CORRA ATÉ O FILIPE E ATAQUE COM J",
                      W // 2, 122, (255, 240, 120), center=True)


# ---------------------------------------------------------------- jogo
class Game:
    def __init__(self, screen, window=None):
        self.screen = screen          # tela virtual 1280x720
        self.window = window          # janela real (tela cheia)
        self.win_size = None
        self.assets = Assets()
        self.clock = pygame.time.Clock()
        self.state = "title"
        self.stage = 0                # fase (0..3) que esta sendo jogada
        self.world_idx = 0            # 0 = Mundo 1 (geleiras) | 1 = Mundo 2 (zona radioativa) | 2 = Mundo 3 (noite)
        self.best_w = [{} for _ in WORLDS]        # melhor pontuacao por fase, de cada mundo
        self.progress_w = [set() for _ in WORLDS]  # fases concluidas, de cada mundo
        self.lives = STAGE_LIVES      # vidas globais: nao reiniciam ao trocar de fase/mundo
        self.music = Music()
        self.load_progress()
        self.worlds = [OverWorld(self.progress_w[i], i) for i in range(len(WORLDS))]
        for ow in self.worlds:
            ow.init_surfaces(pygame)
        self.set_world(0)
        self.map_surf = pygame.Surface((MAP_W, MAP_H)).convert()
        self.map_canvas = pygame.Surface((MAP_W, MAP_H + 20)).convert()
        self.map_go = None            # [fase, tempo] = fade de saida do mapa para a fase
        self.map_fade = 0.0           # fade de entrada no mapa
        self.start_t = 0.0            # >0 = botao START apertado (pequena animacao antes de jogar)
        self.t = 0.0
        self.snow = [[random.uniform(0, W), random.uniform(0, H), random.uniform(40, 140),
                      random.choice((2, 3, 3, 4))] for _ in range(90)]
        self.new_game()

    def new_game(self):
        st = self.stage
        self.assets.theme = self.world_idx                  # 0 = gelo | 1 = toxico (Mundo 2) | 2 = noite (Mundo 3)
        self.level = Level(st, self.world_idx == 1, self.world_idx == 2)
        self.particles = Particles()
        self.player = Player(*STAGE_SPAWNS[st])
        self.cam = 0.0
        self.shake_t = 0.0
        self.shake_mag = 0.0
        self.spawn = STAGE_SPAWNS[st]
        self.boss = None
        self.boss_kind = None         # "drone" (fase 2) ou "golem" (fase 4)
        self.boss_locked = False
        self.quiz_list = []           # perguntas do chefe atual
        self.quiz_delay = 0.0         # >0 = chefe caiu, quiz comeca quando chegar a 0
        self.quiz_after = None
        self.arena_x0 = STAGE_ARENA_COL.get(st, 0) * T
        self.trans = None             # transicao (fade)
        self.phase_t = PHASE_TIME     # tempo restante da fase
        self.deaths = 0
        self.run_time = 0.0
        self.respawn_t = 0.0
        self.banner_t = 3.0
        self.banner_txt = "FASE %d/%d" % (st + 1, NUM_PARTS)
        self.win_t = 0.0
        self.clear_t = 0.0            # >0 = fase concluida (animacao de final)
        self.clear_walk = False
        self.clearing = False         # True durante todo o final (inclui o fade de saida)
        self.celeb = None             # confete/fogos do final
        self.star_done = set()
        self.win_anim = 0.0
        self.score_rows = []
        self.row_done = set()
        self.row_in = set()
        self._blur_img = None         # fundo desfocado do painel de resultado (cache)
        self._blur_n = 0
        self.score_total = 0
        self.prev_best = 0
        self.new_record = False
        self.go_reason = ""
        self.go_t = 0.0              # tempo da animacao de game over
        self.clear_x = 0.0
        self.player_hidden = False
        self.flash_white = 0.0
        self.jump_pressed = False
        self.dash_pressed = False
        self.cam = max(0.0, self.player.cx - W * 0.4)

    # ---- progresso salvo + mapa de fases
    def set_world(self, i):
        """Troca o mundo ativo (os mesmos nomes self.progress / self.best / self.world apontam para ele)."""
        self.world_idx = i
        self.progress = self.progress_w[i]
        self.best = self.best_w[i]
        self.world = self.worlds[i]

    def world_unlocked(self, i):
        """Mundo 1 sempre aberto; cada mundo seguinte so abre depois de concluir a ultima fase (chefe) do anterior."""
        return i == 0 or (NUM_PARTS - 1) in self.progress_w[i - 1]

    def switch_world(self):
        """TAB no mapa: vai para o proximo mundo ABERTO (mundos bloqueados so abrem ao vencer o anterior)."""
        w = self.world
        if self.map_go is not None or w.walk is not None or w.auto_t > 0:
            return
        total = len(WORLDS)
        nxt = (self.world_idx + 1) % total
        if nxt != 0 and not self.world_unlocked(nxt):
            # o proximo mundo esta bloqueado: avisa e volta para o primeiro mundo aberto
            msg = "MUNDO %d BLOQUEADO!  VENCA O MUNDO %d PARA ABRIR" % (nxt + 1, nxt)
        else:
            msg = None
        n = nxt
        for _ in range(total):
            if self.world_unlocked(n):
                break
            n = (n + 1) % total
        if n == self.world_idx:
            w.msg, w.msg_t = msg or "TERMINE ESTE MUNDO PARA ABRIR O PROXIMO!", 2.5
            return
        self.set_world(n)
        self.enter_map()
        if msg:
            self.world.msg, self.world.msg_t = msg, 3.0

    def load_progress(self):
        """Le o save. Mundo 1 usa 'done'/'best' (igual ao save antigo); Mundo 2 usa 'done2'/'best2'; Mundo 3 usa 'done3'/'best3'."""
        if "--liberar" in sys.argv:                 # atalho de teste: libera todas as fases dos 2 mundos
            for p in self.progress_w:
                p.update(range(NUM_PARTS))
            return
        try:
            import json
            with open(SAVE_FILE, "r") as f:
                data = json.load(f)
            self.lives = max(1, min(STAGE_LIVES, int(data.get("lives", STAGE_LIVES))))
            for wi, (kd, kb) in enumerate((("done", "best"), ("done2", "best2"), ("done3", "best3"))):
                self.progress_w[wi].update(int(i) for i in data.get(kd, []) if 0 <= int(i) < NUM_PARTS)
                self.best_w[wi].update({int(k): int(v) for k, v in data.get(kb, {}).items()})
        except Exception:
            pass

    def save_progress(self):
        try:
            import json
            with open(SAVE_FILE, "w") as f:
                json.dump({"done": sorted(self.progress_w[0]),
                           "best": {str(k): v for k, v in self.best_w[0].items()},
                           "done2": sorted(self.progress_w[1]),
                           "best2": {str(k): v for k, v in self.best_w[1].items()},
                           "done3": sorted(self.progress_w[2]),
                           "best3": {str(k): v for k, v in self.best_w[2].items()},
                           "lives": max(1, min(STAGE_LIVES, self.lives))}, f)
        except Exception:
            pass

    def complete_stage(self, idx):
        self.progress.add(idx)
        self.save_progress()

    def enter_map(self, cur=None, completed=None):
        """Abre o mapa de fases (estilo Super Mario World)."""
        self.state = "map"
        self.trans = None
        self.map_go = None
        self.map_fade = 1.0
        pygame.mouse.set_visible(False)
        w = self.world
        auto = completed is not None and (completed + 1) not in w.done
        w.done = set(self.progress)
        w.walk = None
        w.auto_t = 0.0
        w.auto_dst = None
        w.msg_t = 0.0
        w.facing = "down"
        if completed is not None:
            w.complete(completed, auto=auto)
        else:
            w.cur = w.first_open() if cur is None else cur

    def map_enter(self):
        w = self.world
        if w.walk is None and w.auto_t <= 0 and self.map_go is None and w.unlocked(w.cur):
            self.map_go = [w.cur, 0.0]

    def start_stage(self, idx):
        """Comeca a fase idx (0..3) do inicio."""
        self.stage = idx
        self.new_game()
        self.state = "play"
        pygame.mouse.set_visible(False)

    def finish_stage(self):
        """Fase concluida: fade e volta para o mapa."""
        if self.trans is None:
            self.start_transition(self.back_to_map_done)

    def back_to_map_done(self):
        idx = self.stage
        self.complete_stage(idx)
        self.enter_map(completed=idx)

    def update_map(self, dt):
        for s in self.snow:
            s[1] += s[2] * dt
            s[0] += math.sin(self.t + s[2]) * 20 * dt
            if s[1] > H:
                s[0], s[1] = random.uniform(0, W), -10
        self.world.update(dt)
        if self.map_fade > 0:
            self.map_fade = max(0.0, self.map_fade - dt * 2.5)
        if self.map_go is not None:
            self.map_go[1] += dt
            if self.map_go[1] >= 0.4:
                idx = self.map_go[0]
                self.map_go = None
                self.start_stage(idx)

    def draw_map(self, surf):
        a = self.assets
        w = self.world
        w.draw(self.map_surf)
        cv = self.map_canvas
        cv.fill(w.wd["head"])
        cv.blit(self.map_surf, (0, 20))
        pygame.draw.line(cv, w.wd["line"], (0, 19), (MAP_W, 19))
        cv.blit(w.icon, (3, 2))
        surf.blit(pygame.transform.scale(cv, (W, H)), (0, 0))      # 4x, sem suavizar
        self.draw_snow(surf, {0: (240, 248, 255), 1: (170, 255, 90), 2: (200, 222, 255)}[self.world_idx])   # mundo 2: chuva radioativa
        shown = w.cur
        if w.walk is not None:
            shown = w.walk["dst"]
        nome = w.nodes_def[shown]["nome"]
        tag = "CHEFE" if w.nodes_def[shown]["boss"] else "FASE %d" % (shown + 1)
        if not w.unlocked(shown):
            nome = "???"
        draw_text(surf, a.font_m, "%s  -  %s" % (tag, nome), 92, 22, (255, 255, 255))
        cnt = a.font_s.render("VIDAS x%d   MUNDO %d   CONCLUIDAS %d/%d" % (self.lives, self.world_idx + 1, len(w.done), NUM_PARTS), True, (255, 240, 130))
        surf.blit(cnt, (W - cnt.get_width() - 24, 30))
        if w.msg_t > 0:
            draw_text(surf, a.font_m, w.msg, W // 2, H - 110, (255, 240, 130), center=True,
                      alpha=int(255 * min(1.0, w.msg_t / 0.4)))
        hint = "SETAS mover   |   ENTER entrar na fase   |   TAB trocar de mundo   |   ESC sair"
        draw_text(surf, a.font_s, hint, W // 2, H - 44, (255, 255, 255), center=True)
        k = 0.0
        if self.map_go is not None:
            k = min(1.0, self.map_go[1] / 0.4)
        elif self.map_fade > 0:
            k = self.map_fade
        if k > 0:
            ov = pygame.Surface((W, H))
            ov.fill((10, 20, 60))
            ov.set_alpha(int(255 * k))
            surf.blit(ov, (0, 0))

    # ---- efeitos
    def shake(self, mag):
        self.shake_mag = max(self.shake_mag, mag)
        self.shake_t = 0.3

    def break_ice(self, ice):
        if not ice["alive"]:
            return
        ice["alive"] = False
        self.level.rebuild()
        r = ice["rect"]
        self.particles.burst(r.centerx, r.centery, 14,
                             [(235, 250, 255), (150, 210, 255), (100, 170, 240)], 420, 0.7, 8)
        self.shake(5)

    def kill_player(self):
        if self.respawn_t > 0 or self.state != "play":
            return
        pl = self.player
        pl.dead = True
        self.deaths += 1
        self.lives -= 1
        self.go_reason = "O TEMPO ACABOU!" if self.phase_t <= 0 else "VOCÊ CONGELOU!"
        if self.lives > 0:
            self.save_progress()
        self.respawn_t = 0.9 if self.lives > 0 else 1.3
        self.shake(14)
        self.particles.burst(pl.cx, pl.y + 30, 24,
                             [(255, 255, 255), (60, 70, 130), (230, 130, 40), (210, 80, 100)],
                             480, 0.9, 7)

    def respawn(self):
        self.player = Player(*self.spawn)
        self.respawn_t = 0.0
        if self.boss is not None and self.boss.state != "dead":
            self.boss = self.make_boss()
        if not self.boss_locked:
            self.phase_t = PHASE_TIME       # morreu: a fase recomeça com o tempo cheio
        self.banner_t = 1.4
        self.banner_txt = "ÚLTIMA VIDA!" if self.lives == 1 else "VIDAS: %d" % self.lives

    # ---- game over
    def start_gameover(self):
        """Acabaram as vidas: iris fecha no pinguim, GAME OVER cai letra por letra, pinguim congela."""
        self.state = "gameover"
        # perdeu as 5 vidas: o progresso de TODOS os mundos volta do zero (recordes de pontuacao sao mantidos)
        for pr in self.progress_w:
            pr.clear()
        self.lives = STAGE_LIVES
        self.save_progress()
        self.go_t = 0.0
        self.banner_t = 0.0
        self.shake_t = 0.0
        self.shake_mag = 0.0
        pl = self.player
        self.go_pos = (int(clamp(pl.cx - self.cam, 90, W - 90)), int(clamp(pl.y + 30, 110, H - 110)))
        self.go_parts = Particles()
        self.go_shake = 0.0
        # fundo escuro em degrade (o "buraco" da iris e aberto sobre ele)
        bg = pygame.Surface((W, H), pygame.SRCALPHA)
        for y in range(H):
            k = y / float(H)
            pygame.draw.line(bg, (int(14 - 6 * k), int(30 - 14 * k), int(88 - 40 * k), 255), (0, y), (W, y))
        self.go_bg = bg
        # letras de GAME OVER
        font = pygame.font.Font(None, 200)
        self.go_glyphs = []
        for ch in "GAME OVER":
            if ch == " ":
                self.go_glyphs.append(None)
            else:
                self.go_glyphs.append(outlined_text(font, ch, (238, 249, 255), (70, 30, 0), (10, 20, 70), 6))
        gap = -6
        tot = sum((g.get_width() if g else 56) + gap for g in self.go_glyphs) - gap
        x = (W - tot) // 2
        self.go_letters = []          # [glifo, x, tempo de inicio, ja pousou]
        k = 0
        for g in self.go_glyphs:
            if g is None:
                x += 56 + gap
                continue
            self.go_letters.append([g, x, 1.0 + k * 0.11, False])
            x += g.get_width() + gap
            k += 1
        # cristais de gelo crescendo pelas bordas da tela
        self.go_frost = []
        for _ in range(70):
            edge = random.choice((0, 0, 1, 2, 3))
            span = W if edge in (0, 1) else H
            self.go_frost.append((edge, random.uniform(0, span), random.uniform(60, 200) if edge < 2
                                  else random.uniform(40, 130), random.uniform(14, 34),
                                  random.uniform(-14, 14), random.uniform(0.6, 2.6)))
        self.go_stars = [(random.uniform(0, W), random.uniform(0, H), random.uniform(0, 6.28))
                         for _ in range(26)]

    def update_gameover(self, dt):
        self.go_t += dt
        self.particles.update(dt)
        self.go_parts.update(dt)
        self.go_shake = max(0.0, self.go_shake - dt)
        for s in self.snow:
            s[1] += s[2] * 0.6 * dt
            s[0] += math.sin(self.t + s[2]) * 20 * dt
            if s[1] > H:
                s[0], s[1] = random.uniform(0, W), -10
        for lt in self.go_letters:                     # quando a letra bate no "chao"
            p = (self.go_t - lt[2]) / 0.7
            if p >= 0.36 and not lt[3]:
                lt[3] = True
                self.go_shake = 0.22
                cx, cy = lt[1] + lt[0].get_width() // 2, 150 + 130
                self.go_parts.burst(cx, cy, 12, [(235, 250, 255), (150, 210, 255), (100, 170, 240)],
                                    300, 0.7, 8, 900, 260)

    def make_boss(self):
        if self.boss_kind == "drone":
            return Boss(self, self.arena_x0)
        if self.boss_kind == "slime":
            return Slime(self, self.arena_x0)
        if self.boss_kind == "cara":
            return Cara(self, self.arena_x0)
        if self.boss_kind == "filipe":
            return Filipe(self, self.arena_x0)
        return Golem(self, self.arena_x0)

    def boss_defeated(self):
        self.flash_white = 1.0
        # primeiro o QUIZ; so depois a acao original (vitoria ou tela de resultado)
        self.quiz_delay = 1.0
        if self.boss_kind in ("golem", "cara", "filipe"):
            self.quiz_after = lambda: setattr(self, "win_t", 1.6)      # chefe final: vitoria
        else:
            self.quiz_after = lambda: self.start_clear(walk=False)     # CRIO-DRONE: fase 2 concluida

    # ---- quiz
    def start_quiz(self):
        self.state = "quiz"
        pool = QUIZ_BANCO.get(self.boss_kind) or QUIZ_BANCO["drone"]
        self.quiz_list = random.sample(pool, min(QUIZ_POR_CHEFE, len(pool)))
        self.quiz_i = 0
        self.quiz_score = 0
        self.quiz_t = 0.0
        self.flash_white = 0.0
        self.quiz_new_question()

    def quiz_new_question(self):
        q, opts, ok = self.quiz_list[self.quiz_i]
        order = list(range(len(opts)))
        random.shuffle(order)
        self.quiz_opts = [opts[i] for i in order]
        self.quiz_ok = order.index(ok)
        self.quiz_pick = None          # None = ainda nao respondeu
        self.quiz_sel = 0
        self.quiz_qt = 0.0

    def quiz_answer(self, idx):
        if self.quiz_pick is not None or self.quiz_qt < 0.35:
            return
        self.quiz_pick = idx
        self.quiz_qt = 0.0
        if idx == self.quiz_ok:
            self.quiz_score += 1
            self.particles.burst(W // 2, 360, 24, [(255, 240, 130), (150, 230, 255), (130, 255, 190)],
                                 420, 0.9, 7, 700, 250)

    def quiz_next(self):
        if self.quiz_pick is None or self.quiz_qt < 0.3:
            return
        self.quiz_i += 1
        if self.quiz_i >= len(self.quiz_list):
            self.state = "play"
            after, self.quiz_after = self.quiz_after, None
            if after:
                after()
        else:
            self.quiz_new_question()

    def quiz_key(self, key):
        n = len(self.quiz_opts)
        if self.quiz_pick is None:
            if key in QUIZ_KEYS and QUIZ_KEYS[key] < n:
                self.quiz_sel = QUIZ_KEYS[key]
                self.quiz_answer(self.quiz_sel)
            elif key in (pygame.K_w, pygame.K_UP, pygame.K_LEFT):
                self.quiz_sel = (self.quiz_sel - 1) % n
            elif key in (pygame.K_s, pygame.K_DOWN, pygame.K_RIGHT):
                self.quiz_sel = (self.quiz_sel + 1) % n
            elif key in (pygame.K_j, pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE):
                self.quiz_answer(self.quiz_sel)
        elif key in (pygame.K_j, pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE):
            self.quiz_next()

    def quiz_option_rect(self, i):
        return pygame.Rect(150, 300 + i * 82, W - 300, 70)

    def wrap_text(self, font, text, maxw):
        lines, cur = [], ""
        for w in text.split(" "):
            t = (cur + " " + w).strip()
            if font.size(t)[0] <= maxw or not cur:
                cur = t
            else:
                lines.append(cur)
                cur = w
        lines.append(cur)
        return lines

    def draw_quiz(self, surf):
        a = self.assets
        ov = pygame.Surface((W, H))
        ov.fill((8, 18, 66))
        ov.set_alpha(215)
        surf.blit(ov, (0, 0))
        q = self.quiz_list[self.quiz_i][0]
        draw_text(surf, a.font_s, "QUIZ DO CHEFE" if len(self.quiz_list) == 1 else "QUIZ DO CHEFE   -   PERGUNTA %d/%d" % (self.quiz_i + 1, len(self.quiz_list)),
                  W // 2, 56, (150, 220, 255), center=True)
        # barra de progresso (bolinhas)
        for i in range(len(self.quiz_list)):
            col = (255, 240, 130) if i < self.quiz_i or (i == self.quiz_i and self.quiz_pick is not None) \
                else (70, 90, 150)
            pygame.draw.rect(surf, col, (W // 2 - len(self.quiz_list) * 16 + 5 + i * 32, 90, 22, 10), border_radius=4)
        y = 130
        for ln in self.wrap_text(a.font_m, q, W - 260):
            draw_text(surf, a.font_m, ln, W // 2, y, (255, 255, 255), center=True)
            y += 46
        for i, opt in enumerate(self.quiz_opts):
            r = self.quiz_option_rect(i)
            slide = int(40 * (1 - smoothstep((self.quiz_qt - 0.06 * i) / 0.3)))
            r = r.move(slide, 0)
            if self.quiz_pick is None:
                bg, bd = ((60, 110, 190), (235, 248, 255)) if i == self.quiz_sel else ((30, 55, 120), (110, 150, 220))
            elif i == self.quiz_ok:
                bg, bd = (40, 150, 90), (190, 255, 210)
            elif i == self.quiz_pick:
                bg, bd = (170, 55, 70), (255, 190, 195)
            else:
                bg, bd = (28, 40, 90), (70, 90, 150)
            pygame.draw.rect(surf, bg, r, border_radius=14)
            pygame.draw.rect(surf, bd, r, 4, border_radius=14)
            draw_text(surf, a.font_m, "ABCD"[i], r.x + 36, r.y + 18, (255, 240, 130))
            txt = opt
            font = a.font_m if a.font_m.size(txt)[0] < r.w - 130 else a.font_s
            draw_text(surf, font, txt, r.x + 84, r.y + (18 if font is a.font_m else 22))
        if self.quiz_pick is not None:
            ok = self.quiz_pick == self.quiz_ok
            msg = "CORRETO!" if ok else "NÃO FOI DESSA VEZ!"
            draw_text(surf, a.font_m, msg, W // 2, 640, (130, 255, 190) if ok else (255, 150, 160), center=True)
            if int(self.t * 2.5) % 2 == 0:
                last = self.quiz_i == len(self.quiz_list) - 1
                draw_text(surf, a.font_s, "J  " + ("continuar" if last else "próxima pergunta"),
                          W // 2, 684, (255, 255, 255), center=True)
        else:
            draw_text(surf, a.font_s, "W / S ou SETAS para escolher   -   J para responder", W // 2, 684,
                      (150, 180, 230), center=True)
        self.particles.draw(surf, 0, 0)

    def start_clear(self, walk):
        """Final da fase: o pinguim entra no iglu (ou o chefe cai), confete e tela de resultado."""
        if self.clear_t > 0:
            return
        self.clear_t = CLEAR_TIME
        self.clearing = True
        self.clear_walk = walk
        self.banner_t = 0.0
        self.celeb = Celebration(fireworks=False)
        self.celeb.burst_conf(W // 2, H - 40, 34, self.CLEAN_CONF)
        self._blur_img, self._blur_n = None, 0
        self.star_done = set()
        self.compute_score()
        cores = [(255, 240, 130), (150, 230, 255), (255, 255, 255), (255, 120, 140), (130, 255, 190)]
        if walk:
            self.clear_x = float(self.level.goal_door.centerx)
            self.shake(5)
            g = self.level.goal
            self.particles.burst(g.centerx, g.top + 20, 40, cores, 560, 1.3, 8, 700, 250)
        else:
            self.particles.burst(self.player.cx, self.player.y, 40, cores, 560, 1.3, 8, 700, 250)

    # ---- fases / arenas
    def start_transition(self, action):
        self.trans = [0.0, action, False]

    def update_transition(self, dt):
        tr = self.trans
        tr[0] += dt
        if tr[0] >= 0.45 and not tr[2]:
            tr[2] = True
            tr[1]()
        if tr[0] >= 0.9:
            self.trans = None

    def win(self):
        self.complete_stage(self.stage)
        self.state = "win"
        self.win_anim = 0.0
        self.shake_t = 0.0
        self.shake_mag = 0.0
        self.star_done = set()
        self.celeb = Celebration(fireworks=False)
        self.celeb.burst_conf(W // 2, H - 40, 46, self.CLEAN_CONF)
        self.compute_score()

    # ---- painel de resultado (final de fase e vitoria)
    def stars_earned(self):
        return 3 if self.deaths == 0 else (2 if self.deaths <= 2 else 1)

    def star_pos(self, i):
        return W // 2 + (i - 1) * 130, 348

    def compute_score(self):
        """Pontuacao do final: conclusao + tempo restante + vidas + bonus sem mortes. Guarda o recorde."""
        secs = int(max(0.0, self.phase_t))
        lives = max(0, self.lives)
        self.score_rows = [
            ("CONCLUSÃO", 1000),
            ("TEMPO (%ds)" % secs, secs * 100),
            ("VIDAS (x%d)" % lives, lives * 500),
            ("SEM MORTES" if self.deaths == 0 else "MORTES (%d)" % self.deaths,
             1000 if self.deaths == 0 else 0),
        ]
        self.score_total = sum(v for _, v in self.score_rows)
        prev = self.best.get(self.stage, 0)
        self.prev_best = prev
        self.new_record = self.score_total > prev
        if self.new_record:
            self.best[self.stage] = self.score_total
            self.save_progress()
        self.row_done = set()
        self.row_in = set()

    # tempos (s) da animacao do painel LIMPO: titulo -> estrelas -> linhas -> total
    STAR_T0, STAR_GAP = 1.3, 0.35
    ROW_T0, ROW_GAP, ROW_DUR = 2.0, 0.5, 0.45
    TOTAL_T0 = 4.1                            # = ROW_T0 + 4 * ROW_GAP + 0.1
    TOTAL_DUR = 0.9                           # termina em 5.0 = CLEAR_SKIP
    COL_HALF = 240                            # meia-largura da coluna do placar (px)
    CLEAN_CONF = [(255, 240, 130), (255, 255, 255), (170, 225, 255)]   # confete discreto: dourado, branco, gelo
    RES_GOLD = (255, 228, 120)
    RES_LABEL = (178, 208, 246)
    RES_DIM = (104, 134, 188)

    @staticmethod
    def fmt_pts(v):
        return "{:,}".format(int(v)).replace(",", ".")

    def star_pos(self, i):
        return W // 2 + (i - 1) * 104, 252

    def row_y(self, i):
        return 350 + i * 44

    def result_update(self, dt, el):
        """Atualiza o confete discreto e dispara o brilho nas estrelas e no recorde."""
        if self.celeb is None:
            return
        self.celeb.update(dt, rain=False)
        for i in range(self.stars_earned()):
            if i not in self.star_done and el >= self.STAR_T0 + i * self.STAR_GAP + 0.12:
                self.star_done.add(i)
                x, y = self.star_pos(i)
                self.celeb.sparkle(x, y, 8)
        if getattr(self, "score_rows", None) and "total" not in self.row_done \
                and el >= self.TOTAL_T0 + self.TOTAL_DUR:
            self.row_done.add("total")
            if self.new_record:
                self.celeb.sparkle(W // 2, 640, 12)

    def title_img(self, text):
        cache = self.__dict__.setdefault("_title_cache", {})
        if text not in cache:
            cache[text] = outlined_text(self.assets.font_xl, text, (255, 240, 130), (0, 42, 92))
        return cache[text]

    def res_line(self, surf, cx, y, w, col, alpha):
        """Linha fina de 2 px, crescendo a partir do centro (superficie translucida em cache)."""
        cache = self.__dict__.setdefault("_line_cache", {})
        key = (col, alpha)
        if key not in cache:
            sf = pygame.Surface((W, 2), pygame.SRCALPHA)
            sf.fill(col + (alpha,))
            cache[key] = sf
        w = int(clamp(w, 0, W))
        if w > 0:
            surf.blit(cache[key], (cx - w // 2, y), pygame.Rect(0, 0, w, 2))

    @staticmethod
    def res_text(surf, font, text, x, y, color, alpha=255, right=False, center=False):
        """Texto com sombra curta (2 px); alinhado a esquerda, direita ou centro."""
        img = font.render(text, True, color)
        sh = font.render(text, True, (8, 16, 52))
        if right:
            x -= img.get_width()
        elif center:
            x -= img.get_width() // 2
        if alpha < 255:
            img.set_alpha(alpha)
            sh.set_alpha(int(alpha * 0.8))
        surf.blit(sh, (x + 2, y + 2))
        surf.blit(img, (x, y))

    def draw_result(self, surf, title, el, prompt=None):
        """Painel LIMPO: titulo, estrelas e uma coluna de linhas finas com os pontos (sem faixas nem riscos)."""
        a = self.assets
        cx = W // 2
        half = self.COL_HALF
        left, right = cx - half, cx + half
        # titulo: entra com um pop e um unico brilho passa por ele
        p = (el - 0.35) / 0.75
        if p > 0:
            base = self.title_img(title)
            sc = max(0.05, ease_out_back(p))
            img = pygame.transform.smoothscale(base, (max(1, int(base.get_width() * sc)),
                                                      max(1, int(base.get_height() * sc))))
            ph = (el - 1.1) / 0.9
            if 0.0 <= ph <= 1.0:
                x0 = int(-90 + ph * (img.get_width() + 180))
                r = pygame.Rect(x0, 0, 80, img.get_height()).clip(img.get_rect())
                if r.w > 0:
                    img.subsurface(r).fill((130, 130, 130, 0), special_flags=pygame.BLEND_RGB_ADD)
            surf.blit(img, (cx - img.get_width() // 2, 130 - img.get_height() // 2))
        if smoothstep((el - 0.8) / 0.5) < 1.0:
            return
        # estrelas
        earned = self.stars_earned()
        for i in range(3):
            q = (el - (self.STAR_T0 + i * self.STAR_GAP)) / 0.4
            x, y = self.star_pos(i)
            if q <= 0 or i >= earned:
                draw_star(surf, x, y, 36, (22, 40, 100), (80, 110, 180) if q > 0 else (56, 84, 150))
            else:
                sc = ease_out_back(q)
                draw_star(surf, x, y, 44 * sc, (255, 214, 64), (140, 80, 10), (255, 244, 170))
        t_r = self.STAR_T0 + earned * self.STAR_GAP - 0.1
        if el > t_r:
            msg = ("PERFEITO!", "MUITO BEM!", "BOA!")[3 - earned]
            q = clamp((el - t_r) / 0.4, 0.0, 1.0)
            self.res_text(surf, a.font_s, msg, cx, 304, self.RES_GOLD, int(255 * q), center=True)
        # linhas do placar: rotulo a esquerda, pontos a direita, divisoria fina embaixo
        rows = getattr(self, "score_rows", [])
        for i, (label, v) in enumerate(rows):
            t0 = self.ROW_T0 + i * self.ROW_GAP
            q = (el - t0) / 0.3
            if q <= 0:
                continue
            e = smoothstep(q)
            al = int(255 * e)
            y = self.row_y(i) + int((1.0 - e) * 10)
            cnt = smoothstep((el - t0) / self.ROW_DUR)
            shown = int(round(v * cnt))
            done = cnt >= 1.0
            dim = v == 0
            self.res_line(surf, cx, self.row_y(i) + 38, 2 * half * e, (150, 190, 245), 70)
            self.res_text(surf, a.font_m, label, left, y, self.RES_DIM if dim else self.RES_LABEL, al)
            vs = ("+" + self.fmt_pts(shown)) if v > 0 else "0"
            col = self.RES_DIM if dim else (self.RES_GOLD if done else (240, 248, 255))
            self.res_text(surf, a.font_m, vs, right, y, col, al, right=True)
        # total: linha dourada, rotulo e numero grande
        if rows and el >= self.TOTAL_T0 - 0.15:
            lq = smoothstep((el - (self.TOTAL_T0 - 0.15)) / 0.35)
            self.res_line(surf, cx, 534, 2 * half * lq, self.RES_GOLD, 210)
        if el >= self.TOTAL_T0:
            k = smoothstep((el - self.TOTAL_T0) / self.TOTAL_DUR)
            fin = k >= 1.0
            val = self.fmt_pts(self.score_total * k)
            pulse = 1.0 + (0.08 * math.sin(clamp((el - self.TOTAL_T0 - self.TOTAL_DUR) / 0.4, 0, 1) * math.pi)
                           if fin else 0.0)
            img = a.font_l.render(val, True, self.RES_GOLD if fin else (255, 255, 255))
            sh = a.font_l.render(val, True, (8, 16, 52))
            if pulse != 1.0:
                sz = (int(img.get_width() * pulse), int(img.get_height() * pulse))
                img, sh = pygame.transform.smoothscale(img, sz), pygame.transform.smoothscale(sh, sz)
            vx, vy = right - img.get_width(), 548 + (58 - img.get_height()) // 2
            surf.blit(sh, (vx + 3, vy + 3))
            surf.blit(img, (vx, vy))
            lh = a.font_l.size("0")[1]                    # "TOTAL" centrado na vertical com o numero grande
            ty = 548 + (58 - lh) // 2 + (lh - a.font_m.size("TOTAL")[1]) // 2 + 2
            self.res_text(surf, a.font_m, "TOTAL", left, ty, (255, 255, 255), int(255 * min(1.0, k * 3)))
            if fin:
                if self.new_record:                       # selo discreto, pulsando devagar (sem piscar)
                    pul = 0.5 + 0.5 * math.sin(self.t * 3.0)
                    col = tuple(int(self.RES_GOLD[c] + (255 - self.RES_GOLD[c]) * 0.55 * pul) for c in range(3))
                    img = a.font_s.render("NOVO RECORDE", True, col)
                    box = pygame.Rect(0, 0, img.get_width() + 36, img.get_height() + 12)
                    box.center = (cx, 636)
                    pygame.draw.rect(surf, col, box, 2, border_radius=16)
                    surf.blit(img, (box.centerx - img.get_width() // 2, box.centery - img.get_height() // 2))
                elif self.prev_best > 0:
                    self.res_text(surf, a.font_s, "recorde %s" % self.fmt_pts(self.prev_best), cx, 626,
                                  self.RES_DIM, center=True)
        if prompt and el >= CLEAR_SKIP:
            al = int(150 + 105 * (0.5 + 0.5 * math.sin(self.t * 3.0)))
            self.res_text(surf, a.font_s, prompt, cx, 676, (225, 238, 255), al, center=True)

    def blurred_bg(self, surf):
        """Copia desfocada da cena (reduz e amplia com suavizacao); refeita a cada 4 quadros."""
        n = getattr(self, "_blur_n", 0)
        if getattr(self, "_blur_img", None) is None or n % 4 == 0:
            try:
                small = pygame.transform.smoothscale(surf, (W // 10, H // 10))
                self._blur_img = pygame.transform.smoothscale(small, (W, H))
            except Exception:
                self._blur_img = False
        self._blur_n = n + 1
        return self._blur_img or None

    def draw_clear(self, surf):
        if not self.clearing:
            return
        el = CLEAR_TIME - max(0.0, self.clear_t)
        k = smoothstep((el - 0.2) / 0.6)
        if k > 0:
            bl = self.blurred_bg(surf)                    # cena ao fundo desfocada: o painel fica em primeiro plano
            if bl is not None:
                bl.set_alpha(int(255 * k))
                surf.blit(bl, (0, 0))
            ov = pygame.Surface((W, H))
            ov.fill((8, 18, 60))
            ov.set_alpha(int(165 * k))
            surf.blit(ov, (0, 0))
        if self.celeb is not None:
            self.celeb.draw(surf)
        self.draw_result(surf, "FASE CONCLUÍDA!" if self.clear_walk else "CHEFE DERROTADO!", el,
                         "ENTER  continuar")

    # ---- loop principal
    def update_music(self):
        """Escolhe a trilha: chefe = musica frenetica; gameover = silencio; resto = musica arcade."""
        st = self.state
        boss = getattr(self, "boss", None)
        if st == "gameover":
            want = None
        elif (st in ("play", "pause") and self.boss_locked and boss is not None
              and boss.state != "dead" and self.clear_t <= 0 and self.win_t <= 0):
            want = "boss"
        else:
            want = "fase"
        self.music.play(want)
        self.music.set_scale(0.35 if st == "pause" else 1.0)

    def run(self):
        while True:
            dt = min(self.clock.tick(FPS) / 1000.0, 1.0 / 30.0)
            self.t += dt
            for e in pygame.event.get():
                if e.type == pygame.QUIT:
                    return
                if e.type == pygame.MOUSEBUTTONDOWN and e.button == 1 and self.state == "title":
                    if self.start_rect().collidepoint(self.mouse_virtual()):
                        self.press_start()
                if e.type == pygame.KEYDOWN:
                    if e.key == pygame.K_ESCAPE:
                        return
                    if e.key == pygame.K_n:                      # N liga/desliga a musica
                        self.music.toggle()
                        continue
                    if self.state == "title" and e.key in (pygame.K_RETURN, pygame.K_SPACE, pygame.K_KP_ENTER):
                        self.press_start()
                        continue
                    if self.state == "map":
                        if e.key == pygame.K_TAB:
                            self.switch_world()
                        elif e.key in (pygame.K_RETURN, pygame.K_SPACE, pygame.K_KP_ENTER, pygame.K_j, pygame.K_k):
                            self.map_enter()
                        else:
                            nm = {pygame.K_LEFT: "left", pygame.K_a: "left", pygame.K_RIGHT: "right",
                                  pygame.K_d: "right", pygame.K_UP: "up", pygame.K_w: "up",
                                  pygame.K_DOWN: "down", pygame.K_s: "down"}.get(e.key)
                            if nm and self.map_go is None:
                                self.world.key(nm)
                        continue
                    if self.state == "quiz":
                        self.quiz_key(e.key)
                        continue
                    if self.state == "win" and e.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                        if self.win_anim < CLEAR_SKIP:
                            self.win_anim = CLEAR_SKIP                 # adianta o placar
                        elif (self.stage == NUM_PARTS - 1 and self.world_idx + 1 < len(WORLDS)
                              and self.world_unlocked(self.world_idx + 1)
                              and not self.progress_w[self.world_idx + 1]):   # 1a vez que vence o chefe final do mundo
                            nw = self.world_idx + 1
                            self.set_world(nw)
                            self.enter_map(cur=0)
                            self.world.msg, self.world.msg_t = "BEM-VINDO AO MUNDO %d!  (TAB TROCA DE MUNDO)" % (nw + 1), 3.0
                        else:
                            self.enter_map(cur=self.stage)
                        continue
                    if self.state == "gameover":
                        if self.go_t > 2.6:
                            if e.key in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE, pygame.K_r):
                                self.set_world(0)
                                self.start_stage(0)                   # recomeca da fase 1 do mundo 1
                            elif e.key == pygame.K_m:
                                self.set_world(0)
                                self.enter_map(cur=0)
                        continue
                    if (self.state == "play" and self.clear_t > 0 and CLEAR_TIME - self.clear_t > 0.8
                            and e.key in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE, pygame.K_j)):
                        if CLEAR_TIME - self.clear_t < CLEAR_SKIP:     # 1o toque: adianta o placar
                            self.clear_t = CLEAR_TIME - CLEAR_SKIP
                        else:                                          # 2o toque: sai
                            self.clear_t = 0.001
                        continue
                    if self.state in ("play", "pause") and e.key == pygame.K_m:
                        self.enter_map(cur=self.stage)
                        continue
                    if self.state in ("play", "pause") and e.key == pygame.K_p:
                        self.state = "pause" if self.state == "play" else "play"
                        continue
                    if self.state in ("play", "pause") and e.key == pygame.K_r:
                        self.start_stage(self.stage)
                        continue
                    if e.key in JUMP_KEYS:
                        self.jump_pressed = True
                    if e.key == pygame.K_j:
                        self.dash_pressed = True
            self.update_music()
            if self.state == "title":
                pygame.mouse.set_visible(True)
                self.update_title(dt)
            elif self.state == "map":
                self.update_map(dt)
            elif self.state == "play":
                self.update_play(dt)
            elif self.state == "quiz":
                self.quiz_qt += dt
                self.particles.update(dt)
            elif self.state == "gameover":
                self.update_gameover(dt)
            elif self.state == "win":
                self.win_anim += dt
                self.particles.update(dt)
                self.result_update(dt, self.win_anim)
            self.jump_pressed = False
            self.dash_pressed = False
            self.draw()
            self.present()

    # ---- menu inicial
    def mouse_virtual(self):
        """Posicao do mouse convertida para a tela virtual 1280x720."""
        mx, my = pygame.mouse.get_pos()
        win = self.window
        if win is None:
            return mx, my
        ww, wh = win.get_size()
        k = min(ww / float(W), wh / float(H))
        ox, oy = (ww - W * k) / 2.0, (wh - H * k) / 2.0
        return int((mx - ox) / k), int((my - oy) / k)

    def start_rect(self):
        w, h = 360, 96
        return pygame.Rect(W // 2 - w // 2, 520, w, h)

    def press_start(self):
        if self.start_t <= 0:
            self.start_t = 0.22

    def update_title(self, dt):
        for s in self.snow:
            s[1] += s[2] * dt
            s[0] += math.sin(self.t + s[2]) * 20 * dt
            if s[1] > H:
                s[0], s[1] = random.uniform(0, W), -10
        if self.start_t > 0:
            self.start_t -= dt
            if self.start_t <= 0:
                self.start_t = 0.0
                pygame.mouse.set_visible(False)
                self.enter_map()

    def present(self):
        """Escala a tela virtual para a resolucao do PC (mantendo proporcao)."""
        win = self.window
        if win is None:
            pygame.display.flip()
            return
        ww, wh = win.get_size()
        if self.win_size != (ww, wh):
            self.win_size = (ww, wh)
            win.fill((0, 0, 0))
        k = min(ww / float(W), wh / float(H))
        nw, nh = int(W * k), int(H * k)
        if (nw, nh) == (W, H):
            win.blit(self.screen, ((ww - W) // 2, (wh - H) // 2))
        else:
            win.blit(pygame.transform.scale(self.screen, (nw, nh)), ((ww - nw) // 2, (wh - nh) // 2))
        pygame.display.flip()

    # ---- atualizacao da fase
    def get_input(self):
        k = pygame.key.get_pressed()
        d = int(bool(k[pygame.K_RIGHT] or k[pygame.K_d])) - int(bool(k[pygame.K_LEFT] or k[pygame.K_a]))
        held = bool(k[pygame.K_SPACE] or k[pygame.K_UP] or k[pygame.K_w] or k[pygame.K_k])
        return {"dir": d, "jump_held": held,
                "jump_down": self.jump_pressed, "dash_down": self.dash_pressed}

    def update_play(self, dt):
        lvl = self.level
        pl = self.player
        self.run_time += dt if (self.win_t <= 0 and not self.clearing) else 0.0
        self.banner_t = max(0.0, self.banner_t - dt)
        self.flash_white = max(0.0, self.flash_white - dt * 0.6)
        if self.shake_t > 0:
            self.shake_t -= dt
            if self.shake_t <= 0:
                self.shake_mag = 0.0

        # neve
        for s in self.snow:
            s[1] += s[2] * dt
            s[0] += 30 * dt
            if s[1] > H:
                s[1] = -5
                s[0] = random.uniform(0, W)
            if s[0] > W:
                s[0] = 0

        if self.trans is not None:                 # fade entre arenas: jogo congelado
            self.update_transition(dt)
            self.particles.update(dt)
            if self.clearing:
                self.result_update(dt, CLEAR_TIME)
            return
        pl = self.player
        if self.respawn_t > 0:
            self.respawn_t -= dt
            if self.respawn_t <= 0:
                if self.lives <= 0:
                    self.start_gameover()
                    return
                self.respawn()
        else:
            inp = self.get_input()
            if self.boss is not None and self.clear_t <= 0 and hasattr(self.boss, "mod_input"):
                inp = self.boss.mod_input(inp, pl)             # efeitos dos chefes nos controles (grude)
            if self.clear_t > 0:                   # final da fase: sem controle
                inp = {"dir": 0, "jump_held": False, "jump_down": False, "dash_down": False}
                if self.clear_walk and not self.player_hidden:
                    dxg = self.clear_x - pl.cx
                    inp["dir"] = 1 if dxg > 8 else (-1 if dxg < -8 else 0)
                    if abs(dxg) <= 12 or self.clear_t < CLEAR_TIME - 1.1:
                        self.player_hidden = True
                        self.particles.burst(self.clear_x, pl.y + 30, 18,
                                             [(255, 255, 255), (170, 225, 255)], 380, 0.8, 6)
            pl.update(dt, inp, lvl, self)
            if self.boss is not None and hasattr(self.boss, "post_player"):
                self.boss.post_player(pl)
            if self.clear_t <= 0:
                self.check_world(dt)
            # tempo da fase (nao conta durante as lutas de chefe)
            if not self.boss_locked and self.win_t <= 0 and self.clear_t <= 0 and not self.player.dead:
                self.phase_t -= dt
                if self.phase_t <= 0:
                    self.phase_t = 0.0
                    self.banner_t = 2.0
                    self.banner_txt = "TEMPO ESGOTADO!"
                    self.kill_player()

        lvl.update(dt, self)
        if self.boss is not None:
            self.boss.update(dt, self.player)
        self.particles.update(dt)

        if self.clear_t > 0:                       # fase concluida -> fade -> mapa
            self.result_update(dt, CLEAR_TIME - self.clear_t)
            self.clear_t -= dt
            if self.clear_t <= 0:
                self.clear_t = 0.0
                self.finish_stage()
                return

        if self.quiz_delay > 0:
            self.quiz_delay -= dt
            if self.quiz_delay <= 0:
                self.quiz_delay = 0.0
                self.start_quiz()
                return

        if self.win_t > 0:
            self.win_t -= dt
            if self.win_t <= 0:
                self.win()

        # camera
        if self.boss_locked:
            target = float(self.arena_x0)
        else:
            target = pl.cx - W * 0.42 + pl.facing * 90
        target = clamp(target, 0.0, lvl.width - W)
        self.cam = lerp(self.cam, target, 1.0 - math.exp(-dt * 7.0))
        if self.boss_locked:
            self.cam = lerp(self.cam, float(self.arena_x0), 0.2)

    def check_world(self, dt):
        lvl = self.level
        pl = self.player
        pr = pl.rect

        # queda no abismo
        if pl.y > H + 120:
            self.particles.burst(pl.cx, H - 10, 14, [(150, 210, 255), (230, 245, 255)], 400, 0.8, 7, 900, 300)
            self.kill_player()
            return

        # fim da fase: iglu de chegada (fases 1 e 3) ou arena do chefe (fases 2 e 4)
        if not self.boss_locked:
            if lvl.goal_door is not None and pr.colliderect(lvl.goal_door):
                self.start_clear(walk=True)
                return
            if (stage_boss(self.stage, self.world_idx) is not None and pl.cx > self.arena_x0 + 170
                    and self.boss is None):
                self.start_boss()

        # espinhos
        for s in lvl.spikes:
            if pr.colliderect(s):
                pl.hurt(self, s.centerx, force=True)
                pl.vy = -520.0
                break

        # trampolins de gelo
        for sp in lvl.springs:
            if (sp["t"] <= 0 and not pl.dead and not pl.attacking and pl.vy >= 0
                    and pr.colliderect(sp["rect"].inflate(-10, 0))):
                sp["t"] = 0.32
                pl.vy = -1250.0
                pl.on_ground = False
                pl.coyote = 0.0
                pl.spring_t = 0.7
                self.shake(4)
                self.particles.burst(sp["rect"].centerx, sp["rect"].top, 10,
                                     [(235, 245, 255), (150, 225, 255)], 300, 0.5, 6, 500, 200)

        # estalactites
        for ic in lvl.icicles:
            if ic["alive"] and ic["state"] == "fall" and pr.colliderect(lvl.icicle_rect(ic)):
                ic["alive"] = False
                self.particles.burst(ic["x"], ic["top"] + 60, 8, [(220, 240, 255), (150, 200, 250)], 260, 0.5, 5)
                pl.hurt(self, ic["x"], force=True)

    def start_boss(self):
        self.boss_locked = True
        lvl = self.level
        x0 = self.arena_x0
        lvl.solids.append(pygame.Rect(x0 - 80, -400, 80, H + 1200))
        lvl.solids.append(pygame.Rect(x0 + W, -400, 80, H + 1200))
        lvl.rebuild()
        self.spawn = (x0 + 140, H - 3 * T)
        self.boss_kind = stage_boss(self.stage, self.world_idx)
        if self.boss_kind == "filipe":                    # Mundo 3: dois trampolins na arena para alcancar a cabeca do golem
            for sx in (x0 + 300, x0 + W - 300 - T):
                lvl.springs.append({"rect": pygame.Rect(int(sx), int(H - 3 * T - 20), T, 20), "t": 0.0})
        self.boss = self.make_boss()
        self.banner_t = 3.0
        self.banner_txt = {"drone": "CHEFE: CRIO-DRONE", "slime": "CHEFE: GELEIA GIGANTE", "cara": "CHEFE FINAL: DIOGO",
                           "filipe": "CHEFE FINAL: FILIPE"}.get(self.boss_kind, "CHEFE FINAL: CRIO-GOLEM")
        self.player.hp = self.player.max_hp
        self.shake(10)

    # ---- desenho
    def draw_background(self, surf, cam):
        off = cam * 0.15
        i0 = int(off // W)
        tox = self.assets.theme == 1 and self.state != "title"
        night = self.assets.theme == 2 and self.state != "title"
        for i in (i0, i0 + 1):
            if tox:
                img = self.assets.bg_t if i % 2 == 0 else self.assets.bg_t_flip
            elif night:
                img = self.assets.bg_n if i % 2 == 0 else self.assets.bg_n_flip
            else:
                img = self.assets.bg if i % 2 == 0 else self.assets.bg_flip
            surf.blit(img, (int(i * W - off), 0))
        if night:
            self.draw_night_fx(surf, off, i0)
        if tox:
            # bolhas de residuo toxico subindo do lago + brilho pulsando
            for k in range(16):
                ph = (self.t * (0.10 + 0.012 * (k % 5)) + k * 0.137) % 1.0
                bx = (k * 211 + 90 - cam * (0.28 + 0.02 * (k % 4))) % (W + 80) - 40
                by = 600 - ph * 330
                r = 3 + (k % 3) * 2
                al = int(150 * math.sin(ph * math.pi))
                if al > 8:
                    bub = pygame.Surface((r * 2 + 4, r * 2 + 4), pygame.SRCALPHA)
                    pygame.draw.circle(bub, (190, 255, 110, al), (r + 2, r + 2), r, 2)
                    surf.blit(bub, (bx - r - 2, by - r - 2))
            glow = pygame.Surface((W, 120), pygame.SRCALPHA)
            ga = int(26 + 14 * math.sin(self.t * 1.6))
            for j in range(6):
                pygame.draw.rect(glow, (120, 255, 60, max(0, ga - j * 4)), (0, 120 - 20 * (j + 1), W, 20))
            surf.blit(glow, (0, H - 120))

    # luzes vermelhas da fortaleza (x, y no fundo de 1280x720)
    NIGHT_LIGHTS = ((1118, 345), (965, 490), (1245, 385), (1145, 522), (875, 540), (930, 505), (1100, 430))

    def draw_night_fx(self, surf, off, i0):
        """Mundo 3: aurora ondulando, estrelas piscando e luzes de aviso da fortaleza."""
        t = self.t
        # aurora: faixas verticais translucidas que ondulam (soma de luz)
        aur = pygame.Surface((W, 330))                      # fundo preto + BLEND_ADD = so soma luz
        for k in range(14):
            x = (k * 97 + math.sin(t * 0.35 + k) * 40 - off * 0.35) % (W + 120) - 60
            wd = 46 + 26 * math.sin(t * 0.5 + k * 1.3)
            al = (10 + 8 * math.sin(t * 0.8 + k * 0.9)) / 255.0
            base = (60, 230, 200) if k % 3 else (170, 90, 255)
            col = tuple(int(c * al * 3) for c in base)
            pygame.draw.rect(aur, col, (int(x), 0, int(wd), 300))
        surf.blit(aur, (0, 0), special_flags=pygame.BLEND_ADD)
        # estrelas piscando
        for k in range(26):
            sx = (k * 149 + 37 - off * 0.05) % W
            sy = 14 + (k * 83) % 250
            tw = 0.5 + 0.5 * math.sin(t * 2.1 + k * 1.7)
            if tw > 0.55:
                c = int(150 + 105 * tw)
                pygame.draw.rect(surf, (c, c, 255), (int(sx) - 1, int(sy), 3, 1))
                pygame.draw.rect(surf, (c, c, 255), (int(sx), int(sy) - 1, 1, 3))
        # luzes de aviso da fortaleza (acompanham o fundo; o tile espelhado inverte o x)
        for i in (i0, i0 + 1):
            ox = int(i * W - off)
            for n, (lx, ly) in enumerate(self.NIGHT_LIGHTS):
                x = lx if i % 2 == 0 else W - lx
                ph = (t * 1.4 + n * 0.37) % 1.0
                a = 0.25 + 0.75 * max(0.0, math.sin(ph * math.pi)) ** 2
                glow = pygame.Surface((40, 40))
                pygame.draw.circle(glow, (int(70 * a), int(10 * a), int(16 * a)), (20, 20), 18)
                pygame.draw.circle(glow, (int(130 * a), int(30 * a), int(40 * a)), (20, 20), 9)
                surf.blit(glow, (ox + x - 20, ly - 20), special_flags=pygame.BLEND_ADD)

    def draw_world(self, surf, cam, camy):
        a = self.assets
        lvl = self.level
        tox = lvl.toxic
        view = pygame.Rect(int(cam) - 100, -200, W + 200, H + 400)

        for r in lvl.grounds:
            if not r.colliderect(view):
                continue
            hh = H - r.top
            col = r.left // T
            ice = (self.stage == 1)                                  # fase 2 = gelo
            s = a.ground_surface(r.width, hh, r.left, ice)
            surf.blit(s, (r.left - GROUND_MARGIN - cam, r.top - camy))
        for r in lvl.oneways:
            if r.colliderect(view):
                surf.blit(a.platform_surface(r.width),
                          (r.left - PLAT_MARGIN - cam, r.top - camy))
        # decoracao (pinheiros, pedras, cercas)
        for nm, k, dx, dy in lvl.decor:
            if -200 < dx - cam < W + 200:
                surf.blit(a.sprite(nm, k), (dx - cam, dy - camy))
                if nm == "farol":                                # luz vermelha piscando
                    ph = (self.t * 1.6 + dx * 0.013) % 1.0
                    al = 0.2 + 0.8 * max(0.0, math.sin(ph * math.pi)) ** 2
                    gl = pygame.Surface((60, 60))
                    pygame.draw.circle(gl, (int(60 * al), int(10 * al), int(16 * al)), (30, 30), 28)
                    pygame.draw.circle(gl, (int(140 * al), int(36 * al), int(40 * al)), (30, 30), 12)
                    surf.blit(gl, (dx - cam + 12 - 30, dy - camy + 9 - 30), special_flags=pygame.BLEND_ADD)
        # trampolins
        for sp in lvl.springs:
            r = sp["rect"]
            if not -80 < r.left - cam < W + 80:
                continue
            ext = 10 * sp["t"] / 0.32
            sx, by = r.left - cam, r.bottom - camy
            topy = by - 14 - ext
            c_base, c_coil, c_coil2, c_pad, c_padhi, c_padlo = (
                ((70, 50, 40), (150, 120, 60), (230, 210, 90), (120, 235, 60), (225, 255, 150), (30, 90, 20)) if tox else
                ((40, 80, 170), (90, 140, 230), (200, 235, 255), (120, 210, 255), (235, 250, 255), (30, 60, 140)))
            pygame.draw.rect(surf, c_base, (sx + 3, by - 6, T - 6, 6), border_radius=2)
            n = 5
            pts = [(sx + 10 if i % 2 == 0 else sx + T - 10, by - 6 - (by - 6 - (topy + 6)) * i / n)
                   for i in range(n + 1)]
            pygame.draw.lines(surf, c_coil, False, pts, 4)
            pygame.draw.lines(surf, c_coil2, False, pts, 2)
            pygame.draw.rect(surf, c_pad, (sx, topy, T, 8), border_radius=4)
            pygame.draw.rect(surf, c_padhi, (sx + 4, topy + 1, T - 8, 3), border_radius=2)
            pygame.draw.rect(surf, c_padlo, (sx, topy, T, 8), 2, border_radius=4)
        # gelo
        ice_img = a.ice_surface()
        for ice in lvl.ice:
            if ice["alive"] and ice["rect"].colliderect(view):
                surf.blit(ice_img, (ice["rect"].left - cam, ice["rect"].top - camy))
        # espinhos: aglomerado de cristais (assets/espinho.raw, versao t_espinho.raw no Mundo 2)
        spk = a.sprite("espinho", 3)                       # 16x16 -> 48x48 (1 tile)
        spk_h = spk.get_height()
        fkey = ("spk_flip", a.theme)                       # versao espelhada (tiles alternados: sem cara de "pente")
        spk_f = a.cache.get(fkey)
        if spk_f is None:
            spk_f = a.cache[fkey] = pygame.transform.flip(spk, True, False)
        for s in lvl.spikes:
            if not s.colliderect(view):
                continue
            n = max(1, round((s.width + 12) / T))
            base = s.bottom - camy
            for i in range(n):
                wx = s.left - 6 + i * T                    # x no mundo (fase do brilho nao depende da camera)
                x0 = wx - cam
                flip = (int(wx) // T) % 2 == 1
                surf.blit(spk_f if flip else spk, (x0, base - spk_h + 6))   # o monte da base afunda 6 px no chao
                tipx, tipy = x0 + (22 if flip else 25), base - spk_h + 6 + 2
                if tox:                                    # cristal toxico: nucleo verde pulsando
                    pul = 0.5 + 0.5 * math.sin(self.t * 3.2 + wx * 0.021)
                    draw_glow(surf, tipx, tipy + 22, 26, (110, 255, 60), 0.18 + 0.22 * pul)
                else:                                      # gelo: brilho que cintila na ponta, de tempos em tempos
                    ph = (self.t * 0.8 + wx * 0.0137) % 3.2
                    if ph < 0.4:
                        q = math.sin(math.pi * ph / 0.4)   # 0 -> 1 -> 0
                        L = int(4 + 9 * q)
                        pygame.draw.rect(surf, (255, 255, 255), (tipx - 1, tipy - L, 3, L * 2))
                        pygame.draw.rect(surf, (255, 255, 255), (tipx - L, tipy - 1, L * 2, 3))
                        pygame.draw.rect(surf, (200, 240, 255), (tipx - 3, tipy - 3, 7, 7))
        # iglu de chegada + bandeira
        g = lvl.goal
        if g is not None and g.right > cam - 200 and g.left < cam + W + 200:
            gx, gy = g.left - cam, g.top - camy
            if self.clear_t > 0 and self.clear_walk:    # brilho pulsando saindo da porta
                gl = pygame.Surface((520, 520), pygame.SRCALPHA)
                pul = 0.75 + 0.25 * math.sin(self.t * 7)
                for i in range(7):
                    rr = int((250 - i * 32) * pul)
                    pygame.draw.circle(gl, (255, 244, 170, 20 + i * 6), (260, 260), rr)
                surf.blit(gl, (g.centerx - cam - 260, g.bottom - camy - 80 - 260))
            surf.blit(a.sprite("iglu", 4), (gx, gy))
            fl = a.sprite("bandeira_on" if self.clear_t > 0 else "bandeira_off", 3)
            surf.blit(fl, (gx - 96, g.bottom - camy - fl.get_height()))
            if self.clear_t <= 0:                       # seta piscando em cima do iglu
                ay = gy - 26 + math.sin(self.t * 6) * 6
                ax = gx + GOAL_W // 2
                pygame.draw.polygon(surf, (255, 240, 130), [(ax - 16, ay), (ax + 16, ay), (ax, ay + 24)])
                pygame.draw.polygon(surf, (10, 24, 70), [(ax - 16, ay), (ax + 16, ay), (ax, ay + 24)], 3)
        # estalactites
        for ic in lvl.icicles:
            if not ic["alive"] or not (-60 < ic["x"] - cam < W + 60):
                continue
            ox = random.randint(-3, 3) if ic["state"] == "shake" else 0
            x = ic["x"] - cam + ox
            top = ic["top"] - camy
            ic1, ic2, ic3, ic4 = ((110, 220, 40), (190, 255, 110), (60, 160, 30), (150, 250, 70)) if tox else \
                ((200, 228, 255), (140, 190, 245), (150, 200, 250), (230, 246, 255))
            if ic["state"] != "fall":
                pygame.draw.rect(surf, ic1, (x - 36, top - 20, 72, 32), border_radius=10)
                pygame.draw.rect(surf, ic3 if tox else ic2, (x - 36, top + 4, 72, 8), border_radius=4)
            pygame.draw.polygon(surf, ic3, [(x - 13, top + 14), (x + 13, top + 14), (x, top + 78)])
            pygame.draw.polygon(surf, ic2 if tox else ic4, [(x - 7, top + 14), (x + 7, top + 14), (x, top + 62)])
        if self.boss is not None:
            self.boss.draw(surf, cam, camy, a)
        if not self.player_hidden:
            self.player.draw(surf, cam, camy, a, self.t)
        self.particles.draw(surf, cam, camy)

    def draw_heart(self, surf, x, y, full):
        pat = ["..##.##..", ".#######.", ".#######.", "..#####..", "...###...", "....#...."]
        col = (230, 60, 90) if full else (50, 60, 100)
        for ry, row in enumerate(pat):
            for rx, ch in enumerate(row):
                if ch == "#":
                    pygame.draw.rect(surf, col, (x + rx * 4, y + ry * 4, 4, 4))

    def draw_hud(self, surf):
        a = self.assets
        pl = self.player
        for i in range(pl.max_hp):
            self.draw_heart(surf, 20 + i * 44, 18, i < pl.hp)
        # recarga do dash
        ready = pl.dash_cd <= 0
        frac = 1.0 if ready else 1.0 - pl.dash_cd / DASH_COOLDOWN
        pygame.draw.rect(surf, (20, 28, 70), (20, 64, 150, 14), border_radius=6)
        col = (150, 235, 255) if ready else (90, 150, 230)
        if frac > 0:
            pygame.draw.rect(surf, col, (20, 64, int(150 * frac), 14), border_radius=6)
        pygame.draw.rect(surf, (235, 245, 255) if ready else (140, 170, 225),
                         (20, 64, 150, 14), 2, border_radius=6)
        draw_text(surf, a.font_s, "DASH", 180, 60, (235, 245, 255) if ready else (150, 175, 225))
        # tempo e parte
        tm = self.run_time
        draw_text(surf, a.font_m, "%02d:%05.2f" % (int(tm // 60), tm % 60), W - 20 - 150, 18)
        label = "FASE %d/%d" % (self.stage + 1, NUM_PARTS) if not self.boss_locked else "CHEFE"
        draw_text(surf, a.font_s, label, W - 20 - 150, 56, (190, 225, 255))
        # contagem regressiva da fase (1 minuto)
        if not self.boss_locked:
            pt = max(0.0, self.phase_t)
            low = pt <= 10.0
            col = (255, 90, 100) if low and int(self.t * 4) % 2 == 0 else (
                (255, 200, 120) if low else (255, 255, 255))
            draw_text(surf, a.font_l, "%d:%02d" % (int(pt // 60), int(pt % 60)), W // 2, 14, col, center=True)
            draw_text(surf, a.font_s, "TEMPO DA FASE", W // 2, 78, (190, 225, 255), center=True)
        # tutorial (fase 1): painel de controles no inicio, some devagar
        if self.stage == 0 and self.run_time < 20 and not self.boss_locked and self.state != "pause":
            fade = 255 if self.run_time < 18 else int(255 * (20 - self.run_time) / 2)
            self.draw_controls(surf, W // 2, 108, compact=True, alpha=max(0, fade))
            draw_text(surf, a.font_s, "J + ESPAÇO juntos = SUPER DASH (cruza buracos grandes)   |   1 minuto por fase!",
                      W // 2, 176, (255, 255, 255), center=True, alpha=max(0, fade))
        # barra do chefe
        b = self.boss
        if b is not None and b.state not in ("dead",):
            bw = 640
            x = W // 2 - bw // 2
            pygame.draw.rect(surf, (10, 14, 40), (x - 4, 22, bw + 8, 30), border_radius=6)
            pygame.draw.rect(surf, (70, 20, 40), (x, 26, bw, 22), border_radius=4)
            fw = int(bw * max(0, b.hp) / b.max_hp)
            if fw > 0:
                pygame.draw.rect(surf, (240, 70, 90), (x, 26, fw, 22), border_radius=4)
                pygame.draw.rect(surf, (255, 150, 160), (x, 26, fw, 7), border_radius=4)
            draw_text(surf, a.font_s, b.name, W // 2, 56, (255, 220, 225), center=True)
            if b.vulnerable:
                draw_text(surf, a.font_m, "ATAQUE COM J!", W // 2, 84, (255, 240, 120), center=True)
        # vidas
        surf.blit(a.life_icon, (20, 92))
        draw_text(surf, a.font_m, "x %d" % max(0, self.lives), 60, 94,
                  (255, 120, 140) if self.lives <= 1 else (255, 255, 255))
        # banner
        if self.banner_t > 0:
            al = int(255 * min(1.0, self.banner_t / 0.6))
            draw_text(surf, a.font_l, self.banner_txt, W // 2, H // 2 - 130, center=True, alpha=al)

    def draw_snow(self, surf, col=(240, 248, 255)):
        for s in self.snow:
            pygame.draw.rect(surf, col, (int(s[0]), int(s[1]), s[3], s[3]))

    def draw(self):
        a = self.assets
        surf = self.screen
        if self.state == "title":
            self.draw_background(surf, self.t * 60)
            self.draw_title(surf)
            return
        if self.state == "map":
            self.draw_map(surf)
            return
        cam = self.cam
        camy = 0
        if self.shake_t > 0 and self.shake_mag > 0:
            cam += random.uniform(-self.shake_mag, self.shake_mag)
            camy = random.uniform(-self.shake_mag, self.shake_mag) * 0.7
        self.draw_background(surf, cam)
        self.draw_world(surf, cam, camy)
        self.draw_snow(surf, {0: (240, 248, 255), 1: (170, 255, 90), 2: (200, 222, 255)}[self.world_idx])
        self.draw_hud(surf)
        self.draw_clear(surf)
        if self.respawn_t > 0 and self.lives > 0:
            ov = pygame.Surface((W, H))
            ov.fill((10, 20, 60))
            ov.set_alpha(int(180 * (1 - self.respawn_t / 0.9)))
            surf.blit(ov, (0, 0))
        if self.trans is not None:
            t = self.trans[0]
            k = t / 0.45 if t < 0.45 else max(0.0, 1.0 - (t - 0.45) / 0.45)
            ov = pygame.Surface((W, H))
            ov.fill((10, 20, 60))
            ov.set_alpha(int(255 * min(1.0, k)))
            surf.blit(ov, (0, 0))
        if self.flash_white > 0:
            ov = pygame.Surface((W, H))
            ov.fill((255, 255, 255))
            ov.set_alpha(int(255 * min(1.0, self.flash_white)))
            surf.blit(ov, (0, 0))
        if self.state == "pause":
            ov = pygame.Surface((W, H))
            ov.fill((10, 20, 60))
            ov.set_alpha(150)
            surf.blit(ov, (0, 0))
            draw_text(surf, a.font_l, "PAUSADO", W // 2, H // 2 - 50, center=True)
            draw_text(surf, a.font_s, "P continuar   |   R reiniciar fase   |   M mapa   |   ESC sair", W // 2, H // 2 + 30, center=True)
            self.draw_controls(surf, W // 2, H // 2 + 85)
        if self.state == "quiz":
            self.draw_quiz(surf)
        if self.state == "win":
            self.draw_win(surf)
        if self.state == "gameover":
            self.draw_gameover(surf)

    def draw_gameover(self, surf):
        """GAME OVER: iris fecha no pinguim -> gelo cresce pelas bordas -> letras caem -> pinguim congela."""
        a = self.assets
        if self.state != "gameover":
            return
        el = self.go_t
        cx, cy = self.go_pos
        # 1) iris
        e = smoothstep(el / 1.0)
        maxr = math.hypot(W, H)
        r = int(maxr * (1.0 - e))
        ov = self.go_bg.copy()
        if r > 0:
            pygame.draw.circle(ov, (0, 0, 0, 0), (cx, cy), r)
        surf.blit(ov, (0, 0))
        if 0 < r < maxr * 0.98:
            pygame.draw.circle(surf, (170, 222, 255), (cx, cy), r, 5)
        # estrelinhas de fundo + neve
        if el > 0.8:
            q = clamp((el - 0.8) / 0.6, 0.0, 1.0)
            for x, y, ph in self.go_stars:
                s = 2 + int(2 * (0.5 + 0.5 * math.sin(self.t * 2.5 + ph)))
                pygame.draw.rect(surf, (int(120 * q), int(170 * q), int(240 * q)), (int(x), int(y), s, s))
        self.draw_snow(surf)
        # 2) gelo crescendo pelas bordas
        if el > 0.5:
            fr = pygame.Surface((W, H), pygame.SRCALPHA)
            for edge, pos, ln, hw, skew, dl in self.go_frost:
                p = ease_out_back(clamp((el - 0.5 - dl * 0.35) / 1.1, 0.0, 1.0))
                if p <= 0:
                    continue
                L = ln * p
                if edge == 0:     base, tan, dr = (pos, H), (1, 0), (0, -1)
                elif edge == 1:   base, tan, dr = (pos, 0), (1, 0), (0, 1)
                elif edge == 2:   base, tan, dr = (0, pos), (0, 1), (1, 0)
                else:             base, tan, dr = (W, pos), (0, 1), (-1, 0)
                bx, by = base
                tip = (bx + dr[0] * L + tan[0] * skew, by + dr[1] * L + tan[1] * skew)
                pygame.draw.polygon(fr, (120, 185, 245, 210),
                                    [(bx - tan[0] * hw, by - tan[1] * hw), (bx + tan[0] * hw, by + tan[1] * hw), tip])
                tip2 = (bx + dr[0] * L * 0.62 + tan[0] * skew * 0.6, by + dr[1] * L * 0.62 + tan[1] * skew * 0.6)
                pygame.draw.polygon(fr, (225, 245, 255, 230),
                                    [(bx - tan[0] * hw * 0.45, by - tan[1] * hw * 0.45),
                                     (bx + tan[0] * hw * 0.45, by + tan[1] * hw * 0.45), tip2])
            surf.blit(fr, (0, 0))
        # 3) letras de GAME OVER (caem e quicam)
        sx = random.randint(-5, 5) if self.go_shake > 0 else 0
        sy = random.randint(-4, 4) if self.go_shake > 0 else 0
        for g, x, t0, _ in self.go_letters:
            p = (el - t0) / 0.7
            if p <= 0:
                continue
            y = lerp(-260, 150, ease_out_bounce(p))
            if p > 1.0:
                y += math.sin(el * 2.2 + x * 0.01) * 3        # balancinho leve depois de pousar
            surf.blit(g, (x + sx, y + sy))
        self.go_parts.draw(surf, 0, 0)
        # 4) motivo + pinguim congelado
        t_end = 1.0 + 9 * 0.11 + 0.7
        if el > t_end - 0.2:
            q = clamp((el - (t_end - 0.2)) / 0.5, 0.0, 1.0)
            draw_text(surf, a.font_m, self.go_reason, W // 2, 330, (190, 225, 255), center=True, alpha=int(255 * q))
        t_ice = t_end + 0.1
        if el > t_ice:
            q = (el - t_ice) / 0.7
            sc = max(0.01, ease_out_back(q))
            bw, bh = int(200 * sc), int(230 * sc)
            bx0, by0 = W // 2 - bw // 2, 398 + (230 - bh) // 2 + int(math.sin(el * 1.8) * 4)
            blk = pygame.Surface((max(2, bw), max(2, bh)), pygame.SRCALPHA)
            # pinguim dentro do bloco
            pen = a.pen_frozen
            if sc > 0.2:
                pp = pygame.transform.scale(pen, (int(pen.get_width() * sc), int(pen.get_height() * sc)))
                blk.blit(pp, (blk.get_width() // 2 - pp.get_width() // 2, blk.get_height() // 2 - pp.get_height() // 2 + 6))
            # vidro do gelo por cima
            glass = pygame.Surface(blk.get_size(), pygame.SRCALPHA)
            pygame.draw.rect(glass, (140, 205, 255, 120), glass.get_rect(), border_radius=int(16 * sc))
            blk.blit(glass, (0, 0))
            pygame.draw.rect(blk, (215, 240, 255, 255), blk.get_rect(), max(2, int(5 * sc)), border_radius=int(16 * sc))
            pygame.draw.rect(blk, (90, 150, 230, 255), blk.get_rect().inflate(-int(16 * sc), -int(16 * sc)),
                             2, border_radius=int(12 * sc))
            # reflexos diagonais
            pygame.draw.line(blk, (255, 255, 255, 230), (int(26 * sc), int(58 * sc)), (int(60 * sc), int(18 * sc)), max(2, int(6 * sc)))
            pygame.draw.line(blk, (255, 255, 255, 200), (int(44 * sc), int(66 * sc)), (int(70 * sc), int(36 * sc)), max(1, int(3 * sc)))
            # brilho que passa
            ph = ((el - t_ice) % 2.4) / 0.8
            if 0 <= ph <= 1 and sc > 0.9:
                gx = int(-30 + ph * (blk.get_width() + 60))
                pygame.draw.line(blk, (255, 255, 255, 140), (gx, blk.get_height()), (gx + 50, 0), 14)
            # sombra + bloco
            pygame.draw.ellipse(surf, (4, 8, 30), (bx0 - 10, by0 + bh - 14, bw + 20, 26))
            surf.blit(blk, (bx0, by0))
            # brilhos piscando em volta
            if q >= 1.0:
                for i in range(5):
                    ang = i * 1.3 + 0.4
                    px = W // 2 + math.cos(ang) * 130
                    py = 515 + math.sin(ang) * 120
                    k = 0.5 + 0.5 * math.sin(self.t * 4 + i * 1.9)
                    L = 4 + 9 * k
                    c = (230, 247, 255)
                    pygame.draw.polygon(surf, c, [(px, py - L), (px + L * 0.35, py), (px, py + L), (px - L * 0.35, py)])
                    pygame.draw.polygon(surf, c, [(px - L, py), (px, py - L * 0.35), (px + L, py), (px, py + L * 0.35)])
        # 5) estatisticas e opcoes
        if el > t_ice + 0.9:
            q = clamp((el - (t_ice + 0.9)) / 0.5, 0.0, 1.0)
            tm = self.run_time
            draw_text(surf, a.font_s, "Tempo: %02d:%05.2f     Mortes: %d" % (int(tm // 60), tm % 60, self.deaths),
                      W // 2, 648, (190, 225, 255), center=True, alpha=int(255 * q))
            draw_text(surf, a.font_s, "SUAS 5 VIDAS ACABARAM: O PROGRESSO VOLTOU PARA A FASE 1",
                      W // 2, 616, (255, 200, 120), center=True, alpha=int(255 * q))
        if el > 2.6 and int(self.t * 2.5) % 2 == 0:
            draw_text(surf, a.font_m, "ENTER  recomecar (fase 1)     M  mapa", W // 2, 676, center=True)

    # ---- painel de CONTROLES (titulo, pausa e tutorial da fase 1).
    # As teclas acendem (douradas) enquanto voce as segura, entao serve tambem de teste de teclado.
    def draw_controls(self, surf, cx, y, compact=False, alpha=255):
        a = self.assets
        fk = a.font_xs if compact else a.font_s          # fonte das teclas e dos rotulos
        kh = 28 if compact else 40                       # altura das teclas
        pad = 6 if compact else 14
        gap_key = 4
        plus_w = 18 if compact else 26
        head_h = 0 if compact else 30
        keys = pygame.key.get_pressed()
        down = {
            "L": bool(keys[pygame.K_LEFT] or keys[pygame.K_a]),
            "R": bool(keys[pygame.K_RIGHT] or keys[pygame.K_d]),
            "ESPAÇO": bool(keys[pygame.K_SPACE]),
            "J": bool(keys[pygame.K_j]),
        }
        # cada coluna: (teclas, rotulo). Teclas: ("arrow", -1/+1) | ("key", texto) | ("plus", "")
        cols = [
            ([("arrow", -1), ("arrow", 1)], "Andar"),
            ([("key", "ESPAÇO")], "Pular"),
            ([("key", "J")], "Dash (só no chão)"),
            ([("key", "J"), ("plus", ""), ("key", "ESPAÇO")], "SUPER DASH (juntos)"),
        ]

        def wid(w):
            if w[0] == "arrow":
                return kh
            if w[0] == "plus":
                return plus_w
            return max(kh, fk.size(w[1])[0] + 24)

        def keys_w(ws):
            return sum(wid(w) for w in ws) + gap_key * (len(ws) - 1)

        col_w = [max(keys_w(ws), fk.size(lab)[0]) for ws, lab in cols]
        gap = 40 if compact else 52
        gap = max(14, min(gap, (W - 40 - 2 * pad - sum(col_w)) // (len(cols) - 1)))
        pw = sum(col_w) + gap * (len(cols) - 1) + 2 * pad
        ph = pad + head_h + kh + 3 + fk.get_height() + pad

        p = pygame.Surface((pw, ph), pygame.SRCALPHA)
        pygame.draw.rect(p, (8, 20, 64, 215), (0, 0, pw, ph), border_radius=14)
        pygame.draw.rect(p, (150, 205, 250, 255), (0, 0, pw, ph), 2, border_radius=14)
        if not compact:
            draw_text(p, a.font_s, "CONTROLES", pw // 2, pad - 2, (255, 240, 130), center=True)

        def draw_key(x0, w, kind, label, hot, combo):
            r = pygame.Rect(x0, pad + head_h, w, kh)
            pygame.draw.rect(p, (10, 24, 70), r.move(0, 3), border_radius=7)
            pygame.draw.rect(p, (255, 255, 255), r, border_radius=7)
            if hot:
                face = (255, 226, 110)                     # tecla apertada agora
            elif combo:
                face = (255, 206, 150)                     # teclas do super dash
            else:
                face = (170, 220, 255)
            pygame.draw.rect(p, face, r.inflate(-6, -6), border_radius=5)
            ink = (14, 30, 90)
            if kind == "arrow":
                s_ = max(5, kh // 5)
                mx, my = r.centerx, r.centery
                if label < 0:
                    pts = [(mx + s_ - 1, my - s_), (mx + s_ - 1, my + s_), (mx - s_ - 1, my)]
                else:
                    pts = [(mx - s_ + 1, my - s_), (mx - s_ + 1, my + s_), (mx + s_ + 1, my)]
                pygame.draw.polygon(p, ink, pts)
            else:
                img = fk.render(label, True, ink)
                p.blit(img, (r.centerx - img.get_width() // 2, r.centery - img.get_height() // 2))

        x = pad
        for i, (ws, lab) in enumerate(cols):
            kx = x + (col_w[i] - keys_w(ws)) // 2           # centraliza as teclas na coluna
            combo = len(ws) > 1
            for w in ws:
                ww = wid(w)
                if w[0] == "plus":
                    draw_text(p, fk, "+", kx + ww // 2, pad + head_h + (kh - fk.get_height()) // 2,
                              (255, 255, 255), center=True)
                elif w[0] == "arrow":
                    draw_key(kx, ww, "arrow", w[1], down["L" if w[1] < 0 else "R"], False)
                else:
                    draw_key(kx, ww, "key", w[1], down[w[1]], combo)
                kx += ww + gap_key
            col = (255, 226, 110) if combo else (255, 255, 255)
            draw_text(p, fk, lab, x + col_w[i] // 2, pad + head_h + kh + 3, col, center=True)
            x += col_w[i] + gap
        if alpha < 255:
            p.set_alpha(alpha)
        surf.blit(p, (cx - pw // 2, y))

    def draw_title(self, surf):
        a = self.assets
        # escurece o cenario e cria um "vinheta" azul nas bordas
        ov = pygame.Surface((W, H))
        ov.fill((8, 22, 70))
        ov.set_alpha(95)
        surf.blit(ov, (0, 0))
        vg = pygame.Surface((W, H), pygame.SRCALPHA)
        for i in range(8):
            pygame.draw.rect(vg, (6, 14, 50, 14), (i * 14, i * 8, W - i * 28, H - i * 16), 14)
        surf.blit(vg, (0, 0))
        self.draw_snow(surf)

        # logo (flutuando devagar)
        lg = a.logo
        bob = math.sin(self.t * 2.0) * 7
        surf.blit(lg, (W // 2 - lg.get_width() // 2, 60 + bob))

        # botao START
        r = self.start_rect()
        hover = r.collidepoint(self.mouse_virtual())
        pressed = self.start_t > 0
        pulse = 0.5 + 0.5 * math.sin(self.t * 4.0)
        grow = 6 if (hover or pressed) else int(pulse * 4)
        r = r.inflate(grow * 2, grow * 2)
        if pressed:
            r.y += 5
        # sombra
        pygame.draw.rect(surf, (6, 16, 56), r.move(0, 8), border_radius=14)
        # contorno escuro + branco (mesmo estilo do logo)
        pygame.draw.rect(surf, (10, 24, 70), r.inflate(12, 12), border_radius=18)
        pygame.draw.rect(surf, (255, 255, 255), r.inflate(6, 6), border_radius=16)
        base = (140, 205, 250) if not (hover or pressed) else (185, 232, 255)
        pygame.draw.rect(surf, base, r, border_radius=14)
        # parte de baixo mais escura (volume)
        low = pygame.Rect(r.x, r.centery + 6, r.w, r.h // 2 - 6)
        pygame.draw.rect(surf, (96, 168, 238), low, border_bottom_left_radius=14, border_bottom_right_radius=14)
        # neve no topo
        cap = pygame.Rect(r.x, r.y, r.w, 22)
        pygame.draw.rect(surf, (245, 252, 255), cap, border_top_left_radius=14, border_top_right_radius=14)
        for i, dx in enumerate((40, 105, 190, 250, 305)):
            hgt = 10 + (i * 7) % 14
            pygame.draw.rect(surf, (245, 252, 255), (r.x + dx - 11, r.y + 18, 22, hgt), border_radius=8)
        # brilho
        pygame.draw.rect(surf, (255, 255, 255), (r.x + 18, r.y + 34, 60, 5), border_radius=2)
        # texto
        draw_text(surf, a.font_l, "START", r.centerx, r.centery - 18, (255, 255, 255),
                  shadow=(20, 60, 130), center=True)
        # setas piscando nos lados
        if hover or int(self.t * 3) % 2 == 0:
            off = int(abs(math.sin(self.t * 5)) * 8)
            cy = r.centery
            pygame.draw.polygon(surf, (255, 240, 130),
                                [(r.x - 34 - off, cy - 16), (r.x - 34 - off, cy + 16), (r.x - 12 - off, cy)])
            pygame.draw.polygon(surf, (255, 240, 130),
                                [(r.right + 34 + off, cy - 16), (r.right + 34 + off, cy + 16), (r.right + 12 + off, cy)])
        self.draw_controls(surf, W // 2, 656, compact=True)

    def draw_win(self, surf):
        a = self.assets
        el = self.win_anim
        ov = pygame.Surface((W, H))
        ov.fill((10, 25, 80))
        ov.set_alpha(int(200 * smoothstep(el / 0.8)))
        surf.blit(ov, (0, 0))
        if self.celeb is not None:
            self.celeb.draw(surf)
        self.draw_result(surf, "VITÓRIA!", el)
        # dois pinguins pulando de alegria nos cantos
        for i, bx in enumerate((190, W - 190)):
            ph = el * 5.0 + i * 1.6
            hop = abs(math.sin(ph)) * 80
            img = a.pen["jump" if math.cos(ph) * (1 if math.sin(ph) > 0 else -1) > 0 else "fall"][int(el * 8) % 3][0 if i == 0 else 1]
            img = pygame.transform.scale(img, (img.get_width() * 2, img.get_height() * 2))
            gy = 650
            pygame.draw.ellipse(surf, (225, 240, 255), (bx - 90, gy - 6, 180, 22))
            surf.blit(img, (bx - img.get_width() // 2, gy - img.get_height() + 8 - hop))
        if el > CLEAR_SKIP and int(self.t * 2.5) % 2 == 0:
            draw_text(surf, a.font_s, "ENTER voltar ao mapa   |   ESC sair", W // 2, 676, center=True)


class Music:
    """Trilhas em loop: 'fase' (arcade alegre) e 'boss' (tensa e frenetica). Se nao houver audio, fica mudo sem erro."""
    VOL = 0.55

    def __init__(self):
        self.ok = False
        self.tracks = {}
        self.cur = None
        self.muted = False
        self.scale = 1.0
        try:
            if not pygame.mixer.get_init():
                pygame.mixer.init()
            for k, f in (("fase", "musica_fase.ogg"), ("boss", "musica_boss.ogg")):
                path = os.path.join(ASSETS, f)
                if os.path.exists(path):
                    self.tracks[k] = pygame.mixer.Sound(path)
            self.ok = bool(self.tracks)
        except Exception:
            self.ok = False

    def _vol(self):
        return 0.0 if self.muted else self.VOL * self.scale

    def play(self, name):
        if not self.ok or name == self.cur:
            return
        old = self.tracks.get(self.cur)
        if old is not None:
            old.fadeout(500)
        self.cur = name
        snd = self.tracks.get(name)
        if snd is not None:
            snd.set_volume(self._vol())
            snd.play(-1, fade_ms=500)

    def set_scale(self, k):
        if self.ok and k != self.scale:
            self.scale = k
            snd = self.tracks.get(self.cur)
            if snd is not None:
                snd.set_volume(self._vol())

    def toggle(self):
        self.muted = not self.muted
        snd = self.tracks.get(self.cur)
        if snd is not None:
            snd.set_volume(self._vol())


def main():
    pygame.init()
    pygame.display.set_caption("GLACIER SHAPES")
    try:
        window = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
    except Exception:
        window = pygame.display.set_mode((W, H))
    pygame.mouse.set_visible(False)
    canvas = pygame.Surface((W, H)).convert()
    game = Game(canvas, window)
    game.run()
    pygame.quit()
    sys.exit()


if __name__ == "__main__":
    main()
